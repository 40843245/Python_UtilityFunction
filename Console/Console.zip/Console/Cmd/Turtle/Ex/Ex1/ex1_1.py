import turtle

if __name__ == '__main__' :
    screen = turtle.Screen()
    skk = turtle.Turtle()
    skk.forward(100)
    turtle.done()
    
