from typing import List, Union
typehinting1 = List[Union[str, int]]
def Func1(list1:typehinting1):
    return any(list1)
if __name__ == '__main__':
   r = Func1([True])
   print("r:")
   print(r)