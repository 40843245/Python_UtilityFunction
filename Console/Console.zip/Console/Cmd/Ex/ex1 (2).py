import os
import cmd, sys
import tkinter
import turtle

class TurtleShell(cmd.Cmd):
    intro = 'Welcome to the turtle shell.   Type help or ? to list commands.\n'
    prompt = '(turtle) '
    file = None
        
    def __init__(self):
        super().__init__()
        self.Open(os.getcwd()+"\Output.txt")
        
    def Open(self,arg):
        self.file = open(arg,'w')
    # ----- basic turtle commands -----
    def do_forward(self, arg):
        'Move the turtle forward by the specified distance:  FORWARD 10'
        turtle.forward(*parse(arg))
    def do_right(self, arg):
        'Turn turtle right by given number of degrees:  RIGHT 20'
        turtle.right(*parse(arg))
    def do_left(self, arg):
        'Turn turtle left by given number of degrees:  LEFT 90'
        turtle.left(*parse(arg))
    def do_goto(self, arg):
        'Move turtle to an absolute position with changing orientation.  GOTO 100 200'
        turtle.goto(*parse(arg))
    def do_home(self, arg):
        'Return turtle to the home position:  HOME'
        turtle.home()
    def do_circle(self, arg):
        'Draw circle with given radius an options extent and steps:  CIRCLE 50'
        turtle.circle(*parse(arg))
    def do_position(self, arg):
        'Print the current turtle position:  POSITION'
        print('Current position is %d %d\n' % turtle.position())
    def do_heading(self, arg):
        'Print the current turtle heading in degrees:  HEADING'
        print('Current heading is %d\n' % (turtle.heading(),))
    def do_color(self, arg):
        'Set the color:  COLOR BLUE'
        turtle.color(arg.lower())
    def do_undo(self, arg):
        'Undo (repeatedly) the last turtle action(s):  UNDO'
        turtle.undo()
    def do_reset(self, arg):
        'Clear the screen and return turtle to center:  RESET'
        turtle.reset()
    def do_bye(self, arg):
        'Stop recording, close the turtle window, and exit:  BYE'
        print('Thank you for using Turtle')
        self.close()
        turtle.bye()
        return True

    # ----- record and playback -----
    def do_record(self, arg):
        'Save future commands to filename:  RECORD rose.cmd'
        self.Open(arg)
    def do_playback(self, arg):
        'Playback commands from a file:  PLAYBACK rose.cmd'
        self.close()
        with open(arg) as f:
            self.cmdqueue.extend(f.read().splitlines())
            
    # ----- open a turtle screen -----
    def do_openscreen(self,arg):
        'Open a turtle screen.'
        screen = turtle.Screen()
        skk = turtle.Turtle()
        skk.forward(100)
        turtle.begin_fill()
        turtle.left(20)
        turtle.forward(300)
        turtle.end_fill()
        turtle.done()
        turtle.TurtleScreen._RUNNING = True
        
        
    
    # ----- preset command -----
    def precmd(self, line):
        if self.file and 'playback' not in line:
            print("(turtle) "+line, file=self.file)
        return line
    
    # ----- close -----
    def close(self):
        if self.file:
            self.file.close()
            self.file = None
            
            

def parse(arg):
    'Convert a series of zero or more numbers to an argument tuple'
    print("parsing...")
    argsList = arg.split()
    r = tuple(map(int, ( argsList[0] , ) ) )

    return r

if __name__ == '__main__':
    TurtleShell().cmdloop()