import os
import cmd, sys
import tkinter
import turtle

class TurtleShell(cmd.Cmd):
    intro = 'Welcome to the turtle shell.   Type help or ? to list commands.\n'
    prompt = '(turtle) '
    file = None
    screen = None
    canOpenScreen = False
    filename = ''
    prefixes = prompt
    originalPos = (0,0)
    oldPos = originalPos
    currPos = originalPos
    pathsInfos = list()
    
    def __init__(self):
        super().__init__()
        self.canOpenScreen = True
        self.screen = None
        self.filename = os.getcwd()+"\Output.txt"
        self.ClearContent(self.filename)
        
    def ClearPath(self):
        self.pathsInfos.clear()
    
    def ClearContent(self,arg):
        self.file = open(arg,'w')
        self.file.write('')
        
    def AddPath(self,info):
        if not info is None:
            self.pathsInfos.append(info)
            
    def Open(self,arg):
        self.file = open(arg,'a')
        
    def DrawPaths(self):
        numOfPaths = len(self.pathsInfos)
        turtle.pendown()
        
        turtle.begin_fill()
        for i in range(0,numOfPaths,1):
            path = self.pathsInfos[i]
            direction = path.get('direction')
            position = path.get('position')
            if not position is None:
                turtle.setposition(position)
        turtle.end_fill()
        turtle.done()
        
            
    # ----- basic turtle commands -----
    def do_forward(self, arg):
        'Move the turtle forward by the specified distance:  FORWARD 10'
        turtle.forward(*parse(arg))
    def do_right(self, arg):
        'Turn turtle right by given number of degrees:  RIGHT 20'
        turtle.right(*parse(arg))
    def do_left(self, arg):
        'Turn turtle left by given number of degrees:  LEFT 90'
        turtle.left(*parse(arg))
    
    def do_backward(self, arg):
        'Move the turtle forward by the specified distance:  FORWARD 10'
        turtle.backward(*parse(arg))
        
    def do_goto(self, arg):
        'Move turtle to an absolute position with changing orientation.  GOTO 100 200'
        turtle.goto(*parse(arg))
        
    def do_home(self, arg):
        'Return turtle to the home position:  HOME'
        turtle.home()
    def do_circle(self, arg):
        'Draw circle with given radius an options extent and steps:  CIRCLE 50'
        turtle.circle(*parse(arg))
    def do_position(self, arg):
        'Print the current turtle position:  POSITION'
        print('Current position is %d %d\n' % turtle.position())
    def do_heading(self, arg):
        'Print the current turtle heading in degrees:  HEADING'
        print('Current heading is %d\n' % (turtle.heading(),))
    def do_color(self, arg):
        'Set the color:  COLOR BLUE'
        turtle.color(arg.lower())
    def do_undo(self, arg):
        'Undo (repeatedly) the last turtle action(s):  UNDO'
        turtle.undo()
    def do_reset(self, arg):
        'Clear the screen and return turtle to center:  RESET'
        turtle.reset()
    def do_bye(self, arg):
        'Stop recording, close the turtle window, and exit:  BYE'
        print('Thank you for using Turtle')
        self.close()
        turtle.bye()
        return True

    # ----- clear the path (stored in self.pathsInfos)-----      
    def do_clearpaths(self,arg):
        'Clear all info about paths:'
        self.ClearPath()
        
    # ----- update current position -----
    def set_currPos(self,pos:(tuple | None) = None ) :
        if pos is None:
            pos = turtle.position()
        self.currPos = pos
    
    # ----- update current position -----
    def set_oldPos(self,pos:(tuple | None) = None ) :
        if pos is None:
            pos = self.currPos
        self.oldPos = pos
        
    # ----- record  -----
    def do_record(self, arg = None):
        'Save future commands to filename:  RECORD rose.cmd'
        if arg is None or len(arg) <= 0:
            arg = self.filename
            self.Open(arg)
    
    # ----- playback -----   
    def do_playback(self, arg):
        'Playback commands from a file:  PLAYBACK rose.cmd'
        self.close()
        if arg is None or len(arg) <= 0:
            arg = self.filename
        with open(arg) as f:
            lines = f.read().splitlines()
            lines = [elem.removeprefix(self.prefixes) for elem in lines]
            self.cmdqueue.extend(lines)
        
    # ----- open a turtle screen -----
    def do_openscreen(self,arg):
        'Open a turtle screen:'
        self.canOpenScreen = True
        if self.screen is None and self.canOpenScreen == True:
            self.screen = turtle.Screen()
            self.DrawPaths()
            self.canOpenScreen = False
        turtle.TurtleScreen._RUNNING = True

    # ----- close the opened turtle screen -----      
    def do_closescreen(self,arg):
        'Close the opened turtle screen:'
        if not self.screen is None:
            self.canOpenScreen = False
            self.screen = None
        self.close()
            
    # ----- close the opened turtle screen -----      
    def do_exit(self,arg):
        'exit the cmd:'
        self.close()
            
    # ----- hide turn -----        
    def do_hideturtle(self,arg):
        'Hide turtle:'
        turtle.hideturtle()
    
    # ----- open a turtle screen -----
    def do_shapesize(self,arg):
        'Get or set the shape size of turtle:'
        turtle.shapesize(*parse(arg))
    
    # ----- open a turtle screen -----
    def do_getcurrPos(self,arg):
        'Print current position (named self.currPos):'
        print("current position:"+str(self.currPos))
        
    # ----- get all infos of recorded paths. -----
    def do_getpaths(self,arg):
        'Get all infos of recorded paths:'
        numOfPaths = len(self.pathsInfos)
        for i in range(0,numOfPaths,1):
            path = self.pathsInfos[i]
            print(str(path))
        
    # ----- open a turtle screen -----
    def do_getoldPos(self,arg):
        'Print old position (named self.oldPos):'
        print("old position:"+str(self.oldPos))
        
    # ----- update command before execution of command -----
    def precmd(self, line):
        self.set_currPos()
        if self.file and 'playback' not in line:
            print(self.prefixes+line, file=self.file)
        if 'record' in line:
            self.set_oldPos()
        return line
    
    # ----- update command after execution of command -----
    def postcmd(self, stop, line):
        if 'record' in line:
            self.set_oldPos()
        self.do_record()
            
        items = ['forward','backward','left','right']
        
        item = [elem for elem in items if elem in line]
        if len(item) == 1 :
            item = item[0]
            d = {
                    'direction':item,
                    'position':turtle.position(),
            }
            self.AddPath(d)

    # ----- close -----
    def close(self):
        print("closing...")
        if self.file:
            self.file.close()
            self.file = None
        sys.exit()
            
def parse(arg):
    'Convert a series of zero or more numbers to an argument tuple'
    print("parsing...")
    argsList = arg.split()
    r = tuple(map(int, ( argsList[0] , ) ) )
    return r

if __name__ == '__main__':
    TurtleShell().cmdloop()