import os
import cmd
import sys
import tkinter
import turtle


class TurtleShell(cmd.Cmd):
    intro = 'Welcome to the turtle shell.   Type help or ? to list commands.\n'
    prompt = '(turtle) '
    file = None
    screen = None
    canOpenScreen = False
    filename = ''
    prefixes = prompt
    originalPos = (0, 0)
    oldPos = originalPos
    currPos = originalPos
    pathsInfos = list()

    def __init__(self):
        super().__init__()
        print("__init__ method was called.")
        self.canOpenScreen = True
        self.screen = None
        self.filename = os.getcwd()+"\Output.txt"
        self.ClearContent(self.filename)

    # -- My defined method --
    def ClearPath(self):
        print("ClearPath method was called.")
        self.pathsInfos.clear()

    def ClearContent(self, arg):
        print("ClearContent method was called.")
        self.file = open(arg, 'w')
        self.file.write('')

    def AddPath(self, info):
        print("AddPath method was called.")
        if not info is None:
            self.pathsInfos.append(info)

    def Open(self, arg):
        print("Open method was called.")
        self.file = open(arg, 'a')

    def CloseScreen(self) -> bool :
        if not hasattr(self,'screen') or\
            not self.screen is None:
           del self.screen
           return True
        return False
    
    
    def DrawPaths(self):
        print("DrawPaths method was called.")
        numOfPaths = len(self.pathsInfos)
        self.screen.pendown()

        self.screen.begin_fill()
        for i in range(0, numOfPaths, 1):
            path = self.pathsInfos[i]
            position = path.get('position')
            if not position is None:
                self.screen.setposition(position)
        self.screen.end_fill()
        self.screen.penup()
        self.screen.screen.mainloop()
    
    def __dict__(self):
        result = dict()
        screenDict = dict()
        if hasattr(self,'screen'):
            screenDict.update({'screen':self.screen})
            screenDict.update({'hasScreen': not self.screen is None})
        result.update(screenDict)
        return result
    
    # ----- basic turtle commands -----

    def do_forward(self, arg):
        'Move the turtle forward by the specified distance:  FORWARD 10'
        print("do_forward method was called.")
        turtle.forward(*parse(arg))

    def do_right(self, arg):
        'Turn turtle right by given number of degrees:  RIGHT 20'
        print("do_right method was called.")
        turtle.right(*parse(arg))

    def do_left(self, arg):
        'Turn turtle left by given number of degrees:  LEFT 90'
        print("do_left method was called.")
        turtle.left(*parse(arg))

    def do_backward(self, arg):
        'Move the turtle forward by the specified distance:  FORWARD 10'
        print("do_backward method was called.")
        turtle.backward(*parse(arg))

    def do_goto(self, arg):
        'Move turtle to an absolute position with changing orientation.  GOTO 100 200'
        print("do_goto method was called.")
        turtle.goto(*parse(arg))

    def do_home(self, arg):
        'Return turtle to the home position:  HOME'
        print("do_home method was called.")
        turtle.home()

    def do_circle(self, arg):
        'Draw circle with given radius an options extent and steps:  CIRCLE 50'
        print("do_circle method was called.")
        turtle.circle(*parse(arg))

    def do_position(self, arg):
        'Print the current turtle position:  POSITION'
        print("do_position method was called.")
        print('Current position is %d %d\n' % turtle.position())

    def do_heading(self, arg):
        'Print the current turtle heading in degrees:  HEADING'
        print("do_heading method was called.")
        print('Current heading is %d\n' % (turtle.heading(),))

    def do_color(self, arg):
        'Set the color:  COLOR BLUE'
        print("do_color method was called.")
        turtle.color(arg.lower())

    def do_undo(self, arg):
        'Undo (repeatedly) the last turtle action(s):  UNDO'
        print("do_undo method was called.")
        turtle.undo()

    def do_reset(self, arg):
        'Clear the screen and return turtle to center:  RESET'
        print("do_reset method was called.")
        turtle.reset()

    def do_bye(self, arg):
        'Stop recording, close the turtle window, and exit:  BYE'
        print("do_bye method was called.")
        print('Thank you for using Turtle')
        self.close()
        turtle.bye()
        return True

    # ----- clear the path (stored in self.pathsInfos)-----
    def do_clearpaths(self, arg):
        'Clear all info about paths:'
        print("do_clearpaths method was called.")
        self.ClearPath()

    # ----- update current position -----
    def set_currPos(self, pos: (tuple | None) = None):
        print("set_currPos method was called.")
        if pos is None:
            pos = turtle.position()
        self.currPos = pos

    # ----- update current position -----
    def set_oldPos(self, pos: (tuple | None) = None):
        print("set_oldPos method was called.")
        if pos is None:
            pos = self.currPos
        self.oldPos = pos

    # ----- record  -----
    def do_record(self, arg=None):
        'Save future commands to filename:  RECORD rose.cmd'
        print("do_record method was called.")
        if arg is None or len(arg) <= 0:
            arg = self.filename
            self.Open(arg)

    # ----- playback -----
    def do_playback(self, arg):
        'Playback commands from a file:  PLAYBACK rose.cmd'
        print("do_playback method was called.")
        self.close()
        if arg is None or len(arg) <= 0:
            arg = self.filename
        with open(arg) as f:
            lines = f.read().splitlines()
            lines = [elem.removeprefix(self.prefixes) for elem in lines]
            self.cmdqueue.extend(lines)

    
    # ----- open a turtle screen -----
    def do_openscreen(self, arg):
        'Open a turtle screen:'
        print("do_openscreen method was called.")
        self.canOpenScreen = True
        if self.screen is None and self.canOpenScreen == True:
            self.screen = turtle.Turtle()
            self.DrawPaths()
            self.canOpenScreen = False

        
        ## turtle.TurtleScreen._RUNNING = True 
    
    
    # ----- close the opened turtle screen -----
    def do_closescreen(self, arg):
        'Close the opened turtle screen:'
        print("do_closescreen method was called.")
        self.do_bye(arg)

    # ----- close the opened turtle screen -----
    def do_exit(self, arg):
        'exit the cmd:'
        print("do_exit method was called.")
        self.do_bye(arg)

    # ----- hide turn -----
    def do_hideturtle(self, arg):
        'Hide turtle:'
        print("do_hideturtle method was called.")
        turtle.hideturtle()

    # ----- open a turtle screen -----
    def do_shapesize(self, arg):
        'Get or set the shape size of turtle:'
        print("do_shapesize method was called.")
        turtle.shapesize(*parse(arg))

    # ----- open a turtle screen -----
    def do_getcurrPos(self, arg):
        'Print current position (named self.currPos):'
        print("do_getcurrPos method was called.")
        print("current position:"+str(self.currPos))

    # ----- get all infos of recorded paths. -----
    def do_getpaths(self, arg):
        'Get all infos of recorded paths:'
        print("do_getpaths method was called.")
        numOfPaths = len(self.pathsInfos)
        for i in range(0, numOfPaths, 1):
            path = self.pathsInfos[i]
            print(str(path))

    # ----- open a turtle screen -----
    def do_getoldPos(self, arg):
        'Print old position (named self.oldPos):'
        print("do_getoldPos method was called.")
        print("old position:"+str(self.oldPos))

    # ----- update command before execution of command -----
    def precmd(self, line):
        print("precmd method was called.")
        self.set_currPos()
        """
        if self.file and 'playback' not in line:
            print(self.prefixes+line, file=self.file)
        if 'record' in line:
            self.set_oldPos()
        """
        
        return line

    # ----- update command after execution of command -----
    def postcmd(self, stop, line):
        print("postcmd method was called.")
        """
        if 'record' in line:
            self.set_oldPos()

        items = ['forward', 'backward', 'left', 'right']

        item = [elem for elem in items if elem in line]
        if len(item) == 1:
            item = item[0]
            d = {
                'direction': item,
                'position': turtle.position(),
            }
            self.AddPath(d)
        """
        print(self.__dict__())
    # ----- close -----
    def close(self):
        print("close method was called.")
        if self.file:
            self.file.close()
            self.file = None
        self.CloseScreen()
        sys.exit()



def parse(arg):
    'Convert a series of zero or more numbers to an argument tuple'
    print("parsing...")
    argsList = arg.split()
    r = tuple(map(int, (argsList[0], )))
    return r


if __name__ == '__main__':
    TurtleShell().cmdloop()
