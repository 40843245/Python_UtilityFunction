import os
import shutil
import configparser

from LoopHandler import LoopHandler
from WindowsHandler import WindowsHandler
from CoroutineHandler import CoroutineHandler

class DirectoryHandler():
    def __init__(self,fullpath):
        self.fullpath = fullpath
        self.Update()
    def Update(self):
        ( self.headingPath , self.tailingPath ) = os.path.split(self.fullpath)
        self.CD()
    def CD(self):
        cmd = "cd "+ '"'+self.headingPath+'"'
        os.system(cmd)
    
        
class InIHandler():
    def __init__(self,fullpath):
        self.fullpath = fullpath
    def ReadInI(self):
        self.file = open(self.fullpath,'r')
        self.configparser = configparser.ConfigParser(allow_no_value= True)
        self.configparser.read_file(self.file)
        return self.configparser
        
        
class AnacondaHandler():
    class Spyder():
        class AutoSave():
            def __init__(self,spyder):
                self.spyder = spyder
            def Reset(self):
                self.autosave_fullpath = os.path.join( self.spyder.userPath , self.spyder.autosave_path) 
            def ListFiles(self):
                files = os.listdir(self.autosave_fullpath)
                files = [ os.path.join(self.autosave_fullpath,elem) for elem in files ]
                return files
            
        def __init__(self):
            self.drive = "C:"
            self.slash = "\\"
            self.users = "Users"
            self.spyderPath = ".spyder-py3"
            self.history = "history.py"
            self.historyinternal = "history_internal.py"
            self.template = "template.py"
            self.autosave_path = "autosave"
            self.langconfig = "langconfig"
            self.config = 'config'
            self.spyderini = 'spyder.ini'
            self.transient = 'transient.ini'
            self.ownbackups = 'ownbackups'
        
            self.SetUser('40843')
            self.TransientInI()
        
        def Update(self):
            self.transientPath = os.path.join(self.userPath ,self.config, self.transient)
            self.transientPath_ownbackups = os.path.join(self.userPath ,self.config, self.ownbackups ,self.transient)
            
        def SetUser(self,username : str) :
            self.username = username 
            self.userPath = os.path.join( self.drive + self.slash , self.users , self.username , self.spyderPath  )
            self.Update()
           
        def GetHistory(self):       
            path = os.path.join( self.userPath , self.history ) 
            if os.path.exists(path) != True:
                raise Exception("path does not exist.")
            file = open(path,'r',errors = 'replace')
            content = file.read()
            file.close()
            return content
        
        def GetHistoryInternal(self):
            path = os.path.join( self.userPath , self.historyinternal ) 
            if os.path.exists(path) != True:
                raise Exception("path does not exist.")
            file = open(path,'r',errors = 'replace')
            content = file.read()
            file.close()
            return content
        
        def GetTemplate(self):
            path = os.path.join( self.userPath , self.template ) 
            if os.path.exists(path) != True:
                raise Exception("path does not exist.")
            file = open(path,'r',errors = 'replace')
            content = file.read()
            file.close()
            return content
        
        def GetLang(self):
            path = os.path.join( self.userPath , self.langconfig ) 
            if os.path.exists(path) != True:
                raise Exception("path does not exist.")
            file = open(path,'r',errors = 'replace')
            content = file.read()
            file.close()
            return content
        
        def SpyderInI(self):
            self.spyderiniPath = os.path.join(self.userPath , self.config,self.spyderini)
            return self.spyderiniPath
        
        def TransientInI(self):
            self.transientInI = InIHandler(self.transientPath)
            self.transientConfig = self.transientInI.ReadInI()
            return self.transientConfig
        
        def TransientInI_ownbackups(self):
            self.transientInI= InIHandler(self.transientPath_ownbackups)
            self.transientConfig = self.transientInI.ReadInI()
            return self.transientConfig
        
        def GetBreakpoints(self):
            #self.TransientInI()
            self.TransientInI_ownbackups()
            self.breakpoints = self.transientConfig['run']['breakpoints']
            return self.breakpoints
        
        def SetBreakpoints(self,breakpoints):
            self.breakpoints = breakpoints
            self.transientConfig['run']['breakpoints'] = str(self.breakpoints)
        
        def WriteTransientInI(self):
            try:
                with open(self.transientPath_ownbackups,'w') as f:
                    self.transientConfig.write(f)
            except Exception as ex:
                print("In WriteTransientInI method,")
                print("ex:")
                print(ex)
                
        async def WriteTransientInIAsync(self):
            try:
                with open(self.transientPath_ownbackups,'w') as f:
                    self.transientConfig.write(f)
            except Exception as ex:
                print("In WriteTransientInIAsync method,")
                print("ex:")
                print(ex)
            
        def Save(self):
                self.WriteTransientInI()
                print("Done to Save!!!")             
        async def SaveAsync(self):
            try:
                await WindowsHandler.JustClosed('Spyder') 
                await self.WriteTransientInIAsync()
                print("Done to SaveAsync!!!") 
            except Exception as ex:
                print("In Save method,")
                print("ex:")
                print(ex)
            
        def Restore(self):
            shutil.copy(self.transientPath_ownbackups,self.transientPath)    
        
    class JupyterNotebook():            
        def __init__(self):
            self.drive = "C:"
            self.slash = "\\"
            self.users = "Users"
            self.jupyter = ".jupyter"
            self.jupyter_notebook_config = "jupyter_notebook_config.py"
            
        def SetUser(self,username : str) :
            self.username = username 
            self.userPath = os.path.join( self.drive + self.slash , self.users , self.username , self.jupyter  )
            
        def GetConfig(self):   
            path = os.path.join( self.userPath , self.jupyter_notebook_config ) 
            if os.path.exists(path) != True:
                raise Exception("path does not exist.")
            file = open(path,'r',errors = 'replace')
            content = file.read()
            file.close()
            return content
   
            
            
class Loop():
    async def main():
        print("AnacondaHandler!!!")
        
        
if __name__ == '__main__' :
    
   
    breakpoints = {
        'c:\\users\\40843\\onedrive\\utility\\classhandler\\classmerger\\contenthandler\\commentshandler.py': [], 
        'c:\\users\\40843\\onedrive\\utility\\classhandler\\classmerger\\contenthandler\\test13.py': [], 'c:\\users\\40843\\onedrive\\utility\\classhandler\\classmerger\\contenthandler\\test17.py': [(8, None)] , 
    }
    spyder = AnacondaHandler.Spyder()
    jupyter = AnacondaHandler.JupyterNotebook()
    
    spyder.SetUser("40843")
    jupyter.SetUser("40843")
    
    
    spyder.GetBreakpoints()
    print(spyder.breakpoints)
    
    spyder.SetBreakpoints(breakpoints)
    
    spyder.GetBreakpoints()
    
    print(spyder.breakpoints)

    """
    # 1th way:
    # Without async (use atexit module).
    async def DoneAsync(): 
        await spyder.Save()
        print("DoneAsync!!!")
        
    LoopHandler.GetRunningLoopAfterComplete( DoneAsync )
    """
    
    """
    # 2th way:
    # Without async (use atexit module).
    import atexit
    atexit.register(spyder.Save)
    """
    
    
    # 3th way:
    # Without async, normally call it.
    spyder.Save()
    
    spyder.Restore()
    