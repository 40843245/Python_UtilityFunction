import functools

dummy = None

class CoroutineHandler():
    @staticmethod
    def Execute(prefix,callback):
        print("Searching prefix:{}".format(prefix)) 
        counter = 0 
        while True: 
            name = (yield) 
            if prefix in name: 
                func = functools.partial(CoroutineHandler.ExecuteCallback,callback, [counter,name], {})
                func()
                counter += 1
            
    @staticmethod
    def ExecuteCallback(callback,*argv,**kwargv):       
        callback(*argv,**kwargv)
        

if __name__  == '__main__':
    def Print(*argv,**kwargv):
        print("counter:%d" % (argv[0][0]) )
        print("name:%s" % (str(argv[0][1]) ) )         
        
    # calling coroutine, nothing will happen 
    corou = CoroutineHandler.Execute("Dear", Print)
    
    # This will start execution of coroutine and 
    # Prints first line "Searching prefix..." 
    # and advance execution to the first yield expression 
    corou.__next__() 
    
    # sending inputs 
    corou.send("Atul") 
    corou.send("Dear Fuck") 
    corou.send("Dear Shit") 
