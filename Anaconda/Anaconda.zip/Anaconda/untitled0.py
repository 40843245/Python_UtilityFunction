import atexit
def main():
    return "main"


def goodbye():
    print('You are now leaving the Python sector.')
    
atexit.register(goodbye)

if __name__ == '__main__':
    main()

