import os 

r = os.path.get_env_dir()
print(r)