import asyncio

if __name__ == '__main__':
    tasks = asyncio.all_tasks()
    tasks = list(tasks)
    print(tasks)
    for i in range(0,len(tasks),1):
        task = tasks[i]
        isDone = task.done()
        print("isDone:")
        print(isDone)