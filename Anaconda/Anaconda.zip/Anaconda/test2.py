from LoopHandler import LoopHandler

if __name__ == '__main__':
    async def main():
        print("x")
    def DoneCallback():
        print("123")
    LoopHandler.GetRunningLoopAfterComplete(lambda t:DoneCallback() )
    