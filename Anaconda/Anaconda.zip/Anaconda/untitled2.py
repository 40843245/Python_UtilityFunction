
import atexit

@atexit.register
def goodbye():
    print('You are now leaving the Python sector.')