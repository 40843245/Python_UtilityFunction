import IPython
if __name__ == '__main__':
    
    cmd = """code_wrap"""
    shell = IPython.core.interactiveshell.InteractiveShell()
    shell.ev(cmd)