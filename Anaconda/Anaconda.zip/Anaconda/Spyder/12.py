# -*- coding: utf-8 -*-
"""
Created on Fri Nov 17 10:20:57 2023

@author: 40843
"""

