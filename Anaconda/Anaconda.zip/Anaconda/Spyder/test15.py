import prompt_toolkit
from prompt_toolkit.application.current import get_app
from prompt_toolkit.filters import Condition



is_searching = Condition(lambda: get_app().is_searching)

from prompt_toolkit.key_binding import KeyBindings

kb = KeyBindings()

@kb.add('c-t', filter=is_searching)
def Control(event):
    # Do, something, but only when searching.
    print("Control t is pressed.")
    
text = prompt_toolkit.prompt("What's your name?")
print(text)
