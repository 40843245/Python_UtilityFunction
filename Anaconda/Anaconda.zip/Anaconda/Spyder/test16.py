from prompt_toolkit import Application

app = Application(full_screen=True)
app.run()