import time
import keyboard
  
def Demo():
    MAX_SIZE = 1000
    cnt = 0 
    
    onKeyPressedEvent = lambda key : print('{0} pressed'.format(key))
    onKeyReleasedEvent = lambda key : print('{0} release'.format(key))
    
    while True:
        if cnt > MAX_SIZE:
            break
        
        keyboard.on_press(onKeyPressedEvent)
    
        keyboard.on_release(onKeyReleasedEvent)
        
        cnt += 1
        
        time.sleep(4/MAX_SIZE)
    
    
if __name__ == '__main__':
    Demo()
    