import psutil

class ProcessHandler():
    def __init__(self):
        self.Init()
        
    def Init(self):
        self.pid = None
        self.process = None
        
    def SetPid(self,processName):
        if isinstance(processName, str):
            self.pid = ProcessHandler.GetPid(processName)
        elif isinstance(processName, int):
            if processName > 0 :
                self.pid = processName
            else:
                raise Exception("The given pid must be a positive integer. Instead, it is a non-positive integer.")
        else:
            raise Exception("The given pid is neither a int or string.")

    def UpdateProcessInfo(self):
        if self.pid == None:
            raise Exception("Invoke SetProcess Failed since self.pid is set to be None.")
        self.process = psutil.Process(self.pid)
 
    @staticmethod
    def GetPid(processName):    
       for proc in psutil.process_iter():
           if proc.name() == processName:
              return proc.pid
if __name__ == '__main__':
    processName = "SnippingTool.exe"
    
    processHandler = ProcessHandler()
    processHandler.SetPid(processName)
    processHandler.UpdateProcessInfo()