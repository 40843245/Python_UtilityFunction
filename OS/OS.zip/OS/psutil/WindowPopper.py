import psutil

import keyboard

import time

import sys
from PySide6.QtWidgets import QWidget
from PySide6.QtWidgets import QLayout, QBoxLayout, QHBoxLayout, QVBoxLayout
from PySide6.QtWidgets import QApplication
from PySide6.QtCore import QRect

import random

class Widget(QWidget):
    def __init__(self):
        super().__init__()
        self.Create()
    def Create(self):
        mainLayout = QHBoxLayout()
        self.mainLayout = mainLayout
        
class WindowPopper():
    def __init__(self):
        pass

class KeyboardHandler():
    def __init__(self):
        self.Init()
        self.OnPressEvent()
        self.OnReleaseEvent()
    def Init(self):
        self.keyPressed = False
        self.keyReleased = False
    def OnPressEvent(self):
        self.onPressEvent = lambda key : ( print(str(key)+" is pressed.")  )
        self.keyPressed = True
    def OnReleaseEvent(self):
        self.onReleaseEvent = lambda key : ( print(str(key)+" is release.") )
        self.keyReleased = True 
    


if __name__ == '__main__':
    
    app = QApplication.instance()
    if app == None:
        app = QApplication(sys.argv)
    
    MAX_SIZE = 2
    MAX_TIME = 1000
    SECOND = 1
    cnt = 0

    
    keyboardHandler = KeyboardHandler()
    
    widgetList = list()
    for i in range(0,MAX_SIZE,1):
        widget = Widget()
        widget.setGeometry(QRect(0,0,random.randint(200,500),random.randint(200,500)))
        widget.setLayout(widget.mainLayout)
        widgetList.append(widget)
        del widget
    for i in range(0,MAX_SIZE,1):
        widgetList[i].show()

    #keyboard.on_press(keyboardHandler.onPressEvent,suppress = False)
    #keyboard.on_release(keyboardHandler.onReleaseEvent,suppress = False)
    
    while True:
        if QApplication.allWidgets() == None:
            break
        if cnt > MAX_TIME :
            break
        time.sleep(SECOND/MAX_TIME)
        cnt += 1
    keyboard.unhook_all()
    
    print("YA!!!")
    sys.exit(app.exec())
