import psutil

import keyboard

import time

import sys
from PySide6.QtWidgets import QWidget
from PySide6.QtWidgets import QLayout, QBoxLayout, QHBoxLayout, QVBoxLayout
from PySide6.QtWidgets import QApplication
from PySide6.QtCore import QRect

import random

class Widget(QWidget):
    def __init__(self):
        super().__init__()
        self.Create()
    def Create(self):
        mainLayout = QHBoxLayout()
        self.mainLayout = mainLayout
        
class WindowPopper():
    def __init__(self):
        pass

class KeyboardHandler():
    def __init__(self):
        self.Init()
        self.OnPressEvent()
        self.OnReleaseEvent()
    def Init(self):
        self.keyPressed = False
        self.keyReleased = False
    def OnPressEvent(self):
        self.onPressEvent = lambda key : ( print(str(key)+" is pressed.")  )
        self.keyPressed = True
    def OnReleaseEvent(self):
        self.onReleaseEvent = lambda key : ( print(str(key)+" is release.") )
        self.keyReleased = True 
    
class ProcessHandler():
    def __init__(self):
        self.Init()
        
    def Init(self):
        self.pid = None
        self.process = None
        
    def SetPid(self,processName):
        if isinstance(processName, str):
            self.pid = ProcessHandler.GetPid(processName)
        elif isinstance(processName, int):
            if processName > 0 :
                self.pid = processName
            else:
                raise Exception("The given pid must be a positive integer. Instead, it is a non-positive integer.")
        else:
            raise Exception("The given pid is neither a int or string.")

    def UpdateProcessInfo(self):
        if self.pid == None:
            raise Exception("Invoke SetProcess Failed since self.pid is set to be None.")
        self.process = psutil.Process(self.pid)
 
    @staticmethod
    def GetPid(processName):    
       for proc in psutil.process_iter():
           if proc.name() == processName:
              return proc.pid

if __name__ == '__main__':
    
    app = QApplication.instance()
    if app == None:
        app = QApplication(sys.argv)
    
    MAX_SIZE = 2
    MAX_TIME = 1000
    SECOND = 1
    cnt = 0
    processName = "SnippingTool.exe"
    
    processHandler = ProcessHandler()
    processHandler.SetPid(processName)
    processHandler.UpdateProcessInfo()
    
    keyboardHandler = KeyboardHandler()
    
    widgetList = list()
    for i in range(0,MAX_SIZE,1):
        widget = Widget()
        widget.setGeometry(QRect(0,0,random.randint(200,500),random.randint(200,500)))
        widget.setLayout(widget.mainLayout)
        widgetList.append(widget)
        del widget
    for i in range(0,MAX_SIZE,1):
        widgetList[i].show()
    
    
    #processHandler.process.suspend()
    
    #keyboard.on_press(keyboardHandler.onPressEvent,suppress = False)
    #keyboard.on_release(keyboardHandler.onReleaseEvent,suppress = False)
    
    while True:
        
        
        if QApplication.allWidgets() == None:
            break
        
       
        time.sleep(SECOND/MAX_TIME)
        cnt += 1
    keyboard.unhook_all()
    #processHandler.process.resume()
    
    print("YA!!!")
    sys.exit(app.exec())
