from multiprocessing import Process
import time

def f(name):
    print('hello', name)

if __name__ == '__main__':
    MAX_SIZE = 10
    for i in range(0,MAX_SIZE,1):
        p = Process(target=f, args=('bob',))
        p.start()
        p.join()