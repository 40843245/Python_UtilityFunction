import threading

def f(l, i):
    print("Hello World!!!")
    print("l:"+str(l)+",i:"+str(i))

if __name__ == '__main__':
    thread = threading.Thread(target = f , args= [1,2])
    print(thread)
    print(type(thread))
    print(dir(thread))
    thread.run()
    for num in range(10):
        pass