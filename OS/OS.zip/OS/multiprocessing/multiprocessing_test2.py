from multiprocessing import Process, Lock

def f(l, i):
   
    l.acquire()
    try:
        print('hello world', i)
    finally:
        print(l.locked())
        l.release()

if __name__ == '__main__':
    lock = Lock()
    print(lock)
    print(type(lock))
    print(dir(lock))
    for num in range(10):
        Process(target=f, args=(lock, num)).start()