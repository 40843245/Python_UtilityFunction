import functools
from prompt_toolkit import prompt


class DOSCommandHandler():
    class DOSCommandPrompt():
        """
        Intro:
            First prompt. After that, perform some callback (such as print the response).
        Parameter:
            1. promptText: text to prompt.
            2. responseEvent: callback that will be executed after you type text and press Enter key.
            3. responseText: 
                
                
        Returned Value:
            None
        """
        @staticmethod
        def Prompt(promptText: (str|None) = None, responseEvent = None , responseText : (str|None) =  None ):
            if promptText is None:
                promptText = 'Give me some input: '
            if responseText is None:
                responseText = 'You said:'
            if responseEvent is None:
                responseEvent = print
            text = prompt(promptText)            
            text = responseText + text
            func = functools.partial(responseEvent,text)
            func()

if __name__ == '__main__':
    """
        Execute the code in Windows 11 DOS cmd prompt.
        Then it does prompt with text 'Give me some input: '
        After you type text and press Enter key. It will print 'You said:'+{text}.
        where 
            {text} is the text you typed.
    """
    DOSCommandHandler.DOSCommandPrompt.Prompt()
                       
