import ObjectHandler 

class MaxProductOfSumDigitHandler():
    def __init__(self):
        self.Clear()
    """
    Intro:
    Given a positive integer n, get the maximum among these product numbers which sum of each element is equal to n.
    Examples:
    Example 1:
    Input:
        5
    Output:
        6
    """
    def GetMaxProductOfSumDigit(self,number:int):
        if number <= 0 :
            raise Exception("It must be a positive integer in method call GetMaxProductOfSumDigit.")
        self.Clear()
    """
    Intro:
    Given a positive integer n, get a list containing all possibles that sum of each element is equal to n.
    Examples:
    Example 1:
    Input:
        5
    Output:
        [[1,4],[1,1,3],[1,1,1,2],[1,1,1,1,1],[2,3]]
    """
    def SplitNumber(self,number : int):
        if number <= 0 :
            raise Exception("It must be a positive integer in method call SplitNumber.")
        if number == 1:
            return [1]
        if number == 2:
            return [1,1]         
        for i in range(2,(number+1)//2+1,1):
            number1 = self.SplitNumber(i)
            number2 = self.SplitNumber(number-i)
            numberList = [number1,number2]
            self.digitsList.append(numberList)
        # Should never reached 
        # ERROR
        r = ObjectHandler.ObjectHandler.flatten(self.digitsList)
        r = sum(r)
        return r
        
    def Clear(self):
        self.digitsList = list()

if __name__ == '__main__':
    handler = MaxProductOfSumDigitHandler()
    
    handler.SplitNumber(5)
    r = handler.digitsList
    print(r)
    