from PIL import ImageFile

class ImageParser():
    
    @staticmethod
    def ParseImage(filepathname):
        with open(filepathname, "rb") as fp:
            p = ImageFile.Parser()
            while True:
                s = fp.read(1024)
                if not s:
                    break
                p.feed(s)

            im = p.close()
            return im
