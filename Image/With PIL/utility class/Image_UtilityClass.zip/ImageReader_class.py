from PIL import Image

class ImageReader():
    
    @staticmethod
    def ReadDataFromBuffer(im
                           ,mode
                           ,data
                           ,decoder_name='raw'
                           ,*args
                           ):
        result=im.frombuffer(mode=mode
                      ,data=data
                      ,decoder_name=decoder_name
                      ,*args
                      )
        return result
    
    @staticmethod
    def ReadDataFromBytes(im
                           ,mode
                           ,size
                           ,decoder_name='raw'
                           ,*args
                           ):
        result=im.frombytes(mode=mode
                      ,size=size
                      ,decoder_name=decoder_name
                      ,*args
                      )
        return result
    
    @staticmethod
    def ReadDataFromArray(im
                           ,obj
                           ,mode=None
                           ):
        result=im.fromarray(obj=obj
                      ,mode=mode
                      )
        return result
    