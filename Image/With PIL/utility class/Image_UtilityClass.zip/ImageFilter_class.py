from PIL import Image, ImageFilter

class ImageFilters():
    
    @staticmethod
    def BoxBlur(im,radius):
        return im.BoxBlur(radius=radius)
    
    @staticmethod
    def GaussianBlur(im,radius=2):
        return im.GaussianBlur(radius=radius)
    
    @staticmethod
    def UnsharpMask(im
                    ,radius=2
                    ,percent=150
                    ,threshold=3
                    ):
        return im.UnsharpMask(radius=radius
                              ,percent=percent
                              ,threshold=threshold
                              )
    
    @staticmethod
    def Kernel(im
                     ,size
                     ,kernel
                     ,scale=None
                     ,offset=0
                     ):
        return im.Kernel(size=size
                         , kernel=kernel
                         , scale=scale
                         , offset=offset
                         )
    
    @staticmethod
    def RankFilter(im
                   ,size
                   , rank
                   ):
        return im.RankFilter(size=size
                               , rank=rank
                             )
    
    @staticmethod
    def GaussianBlur(im,radius=2):
        return im.GaussianBlur(radius=radius)
    
    @staticmethod
    def MedianFilter(im,size=3):
        return im.MedianFilter(size=size)
    
    @staticmethod
    def MinFilter(im,size=3):
        return im.MinFilter(size=size)
    
    @staticmethod
    def MaxFilter(im,size=3):
        return im.MaxFilter(size=size)
    
    @staticmethod
    def ModeFilter(im,size=3):
        return im.ModeFilter(size=size)
    
    @staticmethod
    def Filter(im,im2,filt):
        im_filter=ImageFilter.Filter(im)
        result=im_filter.filter(image=im2)
        return result
    
    @staticmethod
    def MultibandFilter(im,im2,filt):
        im_filter=ImageFilter.MultibandFilter(im)
        result=im_filter.filter(image=im2)
        return result