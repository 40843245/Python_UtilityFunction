import PIL
class _ColorOperation():
    
    @staticmethod
    def GetRGBColor(im,color):
        try:
            result=im.getrgb(color)
        except:
            print("ERROR!!! unknown error while getting a RGB color.")
            return im
        return result
    
    @staticmethod
    def GetColor(im,color,mode):
        try:
            result=im.getcolor(color,mode)
        except:
            print("ERROR!!! unknown error while getting a RGB color.")
            return im
        return result
    
    @staticmethod
    def GetColor(im,maxcolor):
        if maxcolor>256:
            return im
        if maxcolor<=0:
            return im
        
        try:
            result=im.getcolors(maxcolor=maxcolor)
        except:
            print("ERROR!!! unknown error while getting a RGB color.")
            return im
        return result
    
    @staticmethod
    def GetPalette(im,rawmode='RGB'):
        try:
            result=im.getpalette(rawmode=rawmode)
        except:
            print("ERROR!!! unknown error while getting the palette.")
            return im
        return result
    
    
    
    

