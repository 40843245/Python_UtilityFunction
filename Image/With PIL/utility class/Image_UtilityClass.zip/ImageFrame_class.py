from PIL import Image

from ImageHandlingError_ENUM_class import ImageHandlingError_ENUM
    
class ImageFrame():
         
    @staticmethod
    def Seek(im,frame):
        try:
            result=im.seek(frame=frame)
        except:
            print("ERROR!!! unknown error occurs while seeking the image.")
            return im
        return result
    
    @staticmethod
    def Tell(im,frame):
        try:
            result=im.tell()
        except:
            print("ERROR!!! unknown error occurs while telling the image.")
            return ImageHandlingError_ENUM.FrameError
        return result
    