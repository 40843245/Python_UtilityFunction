class ImageHandlingError_ENUM:
    FrameError=-1