import PIL
from PIL import ImageFont, ImageDraw

class FontImage():
    
    @staticmethod
    def Load(im
                      ,filename
                      ):
        draw=PIL.ImageDraw.Draw(im)
        font=draw.ImageFont.load(filename)
        return font
    
    @staticmethod
    def LoadTruetype(im
                     ,font=None
                     , size=10
                     , index=0
                     , encoding=''
                     , layout_engine=None
                     ):
        draw=PIL.ImageDraw.Draw(im)
        font=draw.ImageFont.truetype(font=font
                                     ,size=size
                                     ,index=index
                                     ,encoding=encoding
                                     ,layout_engine=layout_engine
                                     )
        return font
    
    @staticmethod
    def LoadPath(im
                      ,filename
                      ):
        draw=PIL.ImageDraw.Draw(im)
        font=draw.ImageFont.load_path(filename)
        return font
    
    @staticmethod
    def LoadDefault(im        
                    ):
        draw=PIL.ImageDraw.Draw(im)
        font=draw.ImageFont.load_default()
        return font
        

    

