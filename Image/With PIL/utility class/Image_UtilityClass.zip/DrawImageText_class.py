import sys
import PIL

from PIL import ImageDraw

class DrawImageText():
    
    @staticmethod
    def GetFill(draw):
        return draw.fill
    
    @staticmethod
    def GetFont(draw):
        return draw.font
    
    @staticmethod
    def GetFontmode(draw):
        return draw.fontmode
    
    @staticmethod
    def GetInk(draw):
        return draw.ink
    
    
    @staticmethod
    def DrawText(filepathname:str
                 ,xy
                 ,text
                 ,fill=None
                 ,font=None
                 ,anchor=None
                 ,spacing=4
                 ,align='left'
                 ,direction=None
                 ,features=None
                 ,language=None
                 ,stroke_width=0
                 ,stroke_fill=None
                 ,embedded_color=False
                 ):
        with PIL.Image.open(filepathname) as im:
            draw=PIL.ImageDraw.Draw(im)
            draw.text(xy=xy
                      ,text=text
                      ,fill=fill
                      , font=font
                      , anchor=anchor
                      , spacing=spacing
                      , align=align
                      , direction=direction
                      , features=features
                      , language=language
                      , stroke_width=stroke_width
                      , stroke_fill=stroke_fill
                      , embedded_color=embedded_color
                      )            
            return im
        
    @staticmethod
    def DrawMultilineText(filepathname
                ,xy
                , text
                , fill=None
                , font=None
                , anchor=None
                , spacing=4
                , align='left'
                , direction=None
                , features=None
                , language=None
                , stroke_width=0
                , stroke_fill=None
                , embedded_color=False
            ):
            
            with PIL.Image.open(filepathname) as im:
                draw=PIL.ImageDraw.Draw(im)
                draw.multiline_text(xy=xy
                                    , text=text
                                    , fill=fill
                                    , font=font
                                    , anchor=anchor
                                    , spacing=spacing
                                    , align=align
                                    , direction=direction
                                    , features=features
                                    , language=language
                                    , stroke_width=stroke_width
                                    , stroke_fill=stroke_fill
                                    , embedded_color=embedded_color
                                    )  
                return im
        
    @staticmethod
    def DrawTextsize(filepathname
                     ,text
                     , font=None
                     , spacing=4
                     , direction=None
                     , features=None
                     , language=None
                     , stroke_width=0
                     ):
        with PIL.Image.open(filepathname) as im:
            draw=PIL.ImageDraw.Draw(im)
            draw.textsize(text=text
                          , font=font
                          , spacing=spacing
                          , direction=direction
                          , features=features
                          , language=language
                          , stroke_width=stroke_width
                          )
            return im
        
    @staticmethod
    def DrawTextlength(filepathname
                       ,text
                       , font=None
                       , direction=None
                       , features=None
                       , language=None
                       , embedded_color=False
                       ):
        with PIL.Image.open(filepathname) as im:
            draw=PIL.ImageDraw.Draw(im)
            draw.textlength(text=text
                            , font=font
                            , direction=direction
                            , features=features
                            , language=language
                            , embedded_color=embedded_color
                            )
            return im
    
    @staticmethod
    def DrawTextbbox(filepathname
                     ,xy
                     , text
                     , font=None
                     , anchor=None
                     , spacing=4
                     , align='left'
                     , direction=None
                     , features=None
                     , language=None
                     , stroke_width=0
                     , embedded_color=False
                     ):
        with PIL.Image.open(filepathname) as im:
            draw=PIL.ImageDraw.Draw(im)
            draw.textbbox(xy=xy
                          , text=text
                          , font=font
                          , anchor=anchor
                          , spacing=spacing
                          , align=align
                          , direction=direction
                          , features=features
                          , language=language
                          , stroke_width=stroke_width
                          , embedded_color=embedded_color
                          )
            return im
    
    @staticmethod
    def DrawMultilineTextbox(filepathname
                             ,xy
                             , text
                             , font=None
                             , anchor=None
                             , spacing=4
                             , align='left'
                             , direction=None
                             , features=None
                             , language=None
                             , stroke_width=0
                             , embedded_color=False
                             ):
        with PIL.Image.open(filepathname) as im:
            draw=PIL.ImageDraw.Draw(im)
            draw.multiline_textbbox(xy=xy
                                    , text=text
                                    , font=font
                                    , anchor=anchor
                                    , spacing=spacing
                                    , align=align
                                    , direction=direction
                                    , features=features
                                    , language=language
                                    , stroke_width=stroke_width
                                    , embedded_color=embedded_color
                                    )
            return im

