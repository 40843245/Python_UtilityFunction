import PIL
from PIL import ImageGrab

class ImageGrabber():
    @staticmethod
    def Grab(im
             ,bbox=None
             , include_layered_windows=False
             , all_screens=False
             , xdisplay=None
             ):
        imageGrab=PIL.ImageGrab(im)
        im=imageGrab.grab(bbox=bbox
                   ,include_layered_windows=include_layered_windows
                   ,all_screens=all_screens
                   ,xdisplay=xdisplay
                   )
        return im  
    
    @staticmethod
    def Grabclipboard(im
             ):
        imageGrab=PIL.ImageGrab(im)
        filepathname_list=imageGrab.grabclipboard()
        return filepathname_list
        
        
    

