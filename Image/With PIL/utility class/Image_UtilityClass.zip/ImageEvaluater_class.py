import PIL
from PIL import Image, ImageMath

class ImageEvaluater():
    
    @staticmethod
    def EvaluateImageWithFunc(im
                      ,im2
                      ,func
                      ):
        
        out = im.eval(im2,func)
        return out
    
    # DON'T use 
    # Experimental
    
    @staticmethod
    def EvaluateImageWithMath(expr:str
                      ,para1
                      ,para2
                      ,im1
                      ,im2
                      ):
        
        out = PILImageMath.eval(expr, para1=im1, para2=im2)
        return out