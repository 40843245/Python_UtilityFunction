from PIL import ImageEnhance

# NOT complete yet.
class ImageEnhancer():
    pass
