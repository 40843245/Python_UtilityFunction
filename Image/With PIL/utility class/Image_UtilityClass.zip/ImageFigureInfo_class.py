from PIL import Image

class ImageFigureInfo():
    
    @staticmethod
    def GetHistogramData(im,mask=None,extrema=None):
        return im.histogram(mask=mask,extrema=extrema)
    

