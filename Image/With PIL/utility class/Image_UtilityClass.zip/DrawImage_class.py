import sys
import PIL

from PIL import ImageDraw

class DrawImage():
    
    @staticmethod
    def DrawLine(filepathname
                 ,xy
                 , fill
                 , width
                 , joint
                 ):
        with PIL.Image.open(filepathname) as im:
            draw=ImageDraw.Draw(im)
            draw.line(xy=xy
                      , fill=fill
                      , width=width
                      , joint=joint
                      )
            return im
    
    @staticmethod
    def DrawLines(filepathname:str
                  ,points:list
                  ,fill
                  ):
        for point in points:
            DrawImage.DrawALine(filepathname=filepathname
                                ,point=point
                                ,fill=fill
                                )
            
    @staticmethod
    def DrawPartialOpacityText(filepathname
                               ,fill
                               ,rgba
                               ,msg
                               ):
        with PIL.Image.open(filepathname).convert("RGBA") as im:
            txt=PIL.Image.new("RGBA",im.size,rgba)
            useFont="Pillow/Tests/fonts/FreeMono.ttf"
            fnt=PIL.ImageFont.truetype(useFont,40)
            d=PIL.ImageDraw.Draw(txt)
            d.text((10,10),msg,font=fnt,fill=fill)
            out=PIL.Image.alpha_composite(im, txt)
            return out
    
    @staticmethod
    def DrawAnArc(filepathname
                  ,xy:list
                  ,start
                  ,end
                  ,fill=None
                  ,width=0
                  ):
        with PIL.Image.open(filepathname) as im:
            draw=PIL.ImageDraw.Draw(im)
            draw.arc(xy=xy
                     , start=start
                     , end=end
                     , fill=fill
                     , width=width
                     )
            return im
        
    # Err
    @staticmethod
    def DrawBitmap(filepathname
                   ,xy:list
                   ,bitmap_s:str
                   ,fill=None
                   ):
        with PIL.Image.open(filepathname) as im:
            im_bitmap = im.convert(bitmap_s)
            draw=PIL.ImageDraw.Draw(im)
            draw.bitmap(xy=xy
                        , bitmap=im_bitmap
                        , fill=fill
                        )
            return im
        
        
    @staticmethod
    def DrawChord(filepathname
                  ,xy:list
                        ,start
                        ,end
                        ,fill=None
                        ,outline=None
                        ,width=1
                        ):
        with PIL.Image.open(filepathname) as im:
            draw=PIL.ImageDraw.Draw(im)
            draw.chord(xy=xy
                       , start=start
                       , end=end
                       , fill=fill
                       , outline=outline
                       , width=width
                       )
            return im
        
    
    @staticmethod
    def DrawEllipse(filepathname
                    ,xy:list
                    ,fill=None
                    ,outline=None
                    ,width=1
                    ):
        with PIL.Image.open(filepathname) as im:
            draw=PIL.ImageDraw.Draw(im)
            draw.ellipse(xy=xy
                         , fill=fill
                         , outline=outline
                         , width=width
                         )
            return im
        
    
    @staticmethod
    def DrawPieslice(filepathname
                     ,xy
                     ,start
                     ,end
                     ,fill=None
                     ,outline=None
                     ,width=1
                     ):
        with PIL.Image.open(filepathname) as im:
            draw=PIL.ImageDraw.Draw(im)
            draw.pieslice(xy=xy
                          , start=start
                          , end=end
                          , fill=fill
                          , outline=outline
                          , width=width
                          )
            return im
    
    @staticmethod
    def DrawRectangle(filepathname
                      ,xy
                      ,fill=None
                      ,outline=None
                      ,width=1
                      ):
        with PIL.Image.open(filepathname) as im:
            draw=PIL.ImageDraw.Draw(im)
            draw.rectangle(xy=xy
                           , fill=fill
                           , outline=outline
                           , width=width
                           )
            return im
        
    @staticmethod
    def DrawRoundedRectangle(filepathname
                              ,xy         
                              ,radius
                              ,fill=None
                              ,outline=None
                              ,width=1
                              ):
         with PIL.Image.open(filepathname) as im:
             draw=PIL.ImageDraw.Draw(im)
             draw.rounded_rectangle(xy=xy
                                    , radius=radius
                                    , fill=fill
                                    , outline=outline
                                    , width=width
                                    )
             return im
         

    @staticmethod
    def DrawPolygon(filepathname
                    ,xy
                    ,fill=None
                    ,outline=None
                    ,width=1
                    ):
        
        with PIL.Image.open(filepathname) as im:
            draw=PIL.ImageDraw.Draw(im)
            draw.polygon(xy=xy
                         , fill=fill
                         , outline=outline
                         , width=width
                         )
            return im
        
    @staticmethod
    def DrawRegularPolygon(filepathname
                    ,bounding_circle
                    ,n_sides
                    ,rotation=0
                    ,fill=None
                    ,outline=None
                    ):
        
        with PIL.Image.open(filepathname) as im:
            draw=PIL.ImageDraw.Draw(im)
            draw.regular_polygon(bounding_circle=bounding_circle
                                 ,n_sides=n_sides
                                 ,rotation=rotation
                                 ,fill=fill
                                 ,outline=outline
                                 )
            return im
    