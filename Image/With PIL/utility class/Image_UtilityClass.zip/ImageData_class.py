from PIL import Image

class ImageData():

    class GetImageData():
        @staticmethod
        def GetSize(im):
            return im.size()
        
        @staticmethod
        def GetInfo(im):
            return im.info
        
        @staticmethod
        def GetFormat(im):
            return im.format
    
        @staticmethod
        def GetData(im,band=None):
            return im.getdata(band=band)
    
        @staticmethod
        def GetChannel(im,channel):
            return im.getchannel(channel=channel)
    
        @staticmethod
        def GetBands(im):
            return im.getbands()
    
        @staticmethod
        def GetBoundingBox(im):
            return im.getbbox()
    
        @staticmethod
        def GetExtrema(im):
            return im.getextrema()
    
        @staticmethod
        def GetExif(im):
            return im.getexif()
    
        @staticmethod
        def GetPixel(im,xy):
            return im.getpixel(xy=xy)

        @staticmethod
        def GetProjection(im):
            return im.getprojection()
    
    class PutImageData():
        
        @staticmethod
        def PutPalette(im,data,rawmode='RGB'):
            try:
                result=im.putpalette(data=data,rawmode=rawmode)
            except:
                print("ERROR!!! unknown error while putting the palette.")
                return im
            return result
        
        @staticmethod
        def PutPixel(im,xy,value):
            try:
                result=im.putpixel(xy=xy,value=value)
            except:
                print("ERROR!!! unknown error while putting the pixels.")
                return im
            return result
