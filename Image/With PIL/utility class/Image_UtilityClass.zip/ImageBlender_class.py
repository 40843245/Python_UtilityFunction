from PIL import Image

class ImageBlender():
    
    @staticmethod
    def Blend(im,im1,im2,alpha):
        return im.blend(im1=im1,im2=im2,alpha=alpha)
    
    @staticmethod
    def Composite(im,im1,im2,mask):
        return im.composite(image1=im1,image2=im2,mask=mask)
    
    