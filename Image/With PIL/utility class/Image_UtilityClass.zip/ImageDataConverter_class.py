from PIL import Image

class ImageDataConverter():
    
    @staticmethod
    def ToBitmap(im,name='image'):
        try:
            result=im.tobitmap(name=name)
        except:
            print("ERROR!!! unknown error occurs while converting data of the image.")
            return im
        return result
    
    @staticmethod
    def ToBytes(im,encoder_name='raw',*args):
        try:
            result=im.tobytes(encoder_name=encoder_name,*args)
        except:
            print("ERROR!!! unknown error occurs while converting data of the image.")
            return im
        return result