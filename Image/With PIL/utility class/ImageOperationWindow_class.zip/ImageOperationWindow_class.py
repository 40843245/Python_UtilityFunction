
import PySimpleGUI as sg

from ImageOperator_class import ImageOperator

from ImagesOperator_class import ImagesOperator,MergeDirection_ENUM

class ImageOperationWindow():
    def __init__(self):
        self.MainWindow()
        
    def MainWindow(self):
        
        src_img=ImageOperator(filepathname=None
                              ,need_check_filepathname_exists=False
                              ,need_prehandling_filepathname=False)
        dest_img=ImageOperator(filepathname=None
                              ,need_check_filepathname_exists=False
                              ,need_prehandling_filepathname=False)
        defaultpath=r"C:\Users\user"
        imgs=ImagesOperator(img_src=src_img,img_dest=dest_img,filepathname=defaultpath)
        
        BROWSE = "Browse"
        OPEN = "Open"
        RESIZE = "Resize"
        TRANSPOSE="Transpose"
        ROTATE = "Rotate"
        ROLL = "Roll"
        
        MERGE = "Merge"
        
        
        image1Filepathname_key="-- Image 1 File Path Name--"
        image2Filepathname_key="-- Image 2 File Path Name--"
        image3Filepathname_key="-- Image 3 File Path Name--"
        
        browseButton1="Browse Button 1"
        browseButton2="Browse Button 2"
        browseButton3="Browse Button 3"
        
        openImageButton1="Open Image Button 1"
        openImageButton2="Open Image Button 2"
        
        resizeImageButton1="Resize Image Button 1"
        resizeImageButton2="Resize Image Button 2"
        
        transposeImageButton1="Transpose Image Button 1"
        transposeImageButton2="Transpose Image Button 2"
        
        rotateImageButton1="Rotate Image Button 1"
        rotateImageButton2="Rotate Image Button 2"
        
        rollImageButton1="Roll Image Button 1"
        rollImageButton2="Roll Image Button 2"
        
        flipImageButton1="Flip Image Button 1"
        flipImageButton2="Flip Image Button 2"
        
        scaleImageCombo1_key="--Scale Combo 1--"
        scaleImageCombo2_key="--Scale Combo 2--"
        
        transposeImageCombo1_key="--Transpose Combo 1--"
        transposeImageCombo2_key="--Transpose Combo 2--"
        
        rotateImageCombo1_key="--Rotate Combo 1--"
        rotateImageCombo2_key="--Rotate Combo 2--"
        
        rollImageCombo1_key="--Roll Combo 1--"
        rollImageCombo2_key="--Roll Combo 2--"
        
        mergeImageCombo1_key="--Merge Combo 1--"
        
        mergeImagesButton="Merge Two Images Button"
    
        browseButton_dict={
            browseButton1:image1Filepathname_key
            ,browseButton2:image2Filepathname_key
            ,browseButton3:image3Filepathname_key
        }
        
        openImageButton_dict={
            openImageButton1:[image1Filepathname_key,src_img]
            ,openImageButton2:[image2Filepathname_key,dest_img]
        }
        
        resizeImageButton_dict={
            resizeImageButton1:[image1Filepathname_key,src_img,scaleImageCombo1_key]
            ,resizeImageButton2:[image2Filepathname_key,dest_img,scaleImageCombo2_key]
        }
        
        transposeImageButton_dict={
            transposeImageButton1:[image1Filepathname_key,src_img,transposeImageCombo1_key]
            ,transposeImageButton2:[image2Filepathname_key,dest_img,transposeImageCombo2_key]
        }
        
        rotateImageButton_dict={
            rotateImageButton1:[image1Filepathname_key,src_img,rotateImageCombo1_key]
            ,rotateImageButton2:[image2Filepathname_key,dest_img,rotateImageCombo2_key]
        }
        
        rollImageButton_dict={
            rollImageButton1:[image1Filepathname_key,src_img,rollImageCombo1_key]
            ,rollImageButton2:[image2Filepathname_key,dest_img,rollImageCombo2_key]
        }
    
        mergeImagesButton_dict={
           mergeImagesButton:[image3Filepathname_key,image1Filepathname_key,src_img,image2Filepathname_key,dest_img] 
        }
    
        availableExt=(('PNG', '.png'), ('JPG', '.jpg'))
        
        availableScale=[0.2
                        ,0.25
                        ,0.4
                        ,0.5
                        ,0.75
                        ,0.8
                        ,1
                        ,1.2
                        ,1.25
                        ,1.5
                        ,1.75
                        ,2
                        ,2.5
                        ,3
                        ,4
                        ,5
            ]
        
        availableTranspose=[0,1,2,3,4,5,6]
        
        availableDegree=[0,15,30,45,60,75,90,105,120,135,150,165,180,195,210,225,240,255,270,285,300,315,330,345]
        
        availableRoll=[1,2,3,4,5,6,7]
        
        availableMerge=[0,1,2,3,4,5,6,7]
        
        layout=[              
            [
                sg.Text("Image 1:"),
                sg.Input(key=image1Filepathname_key,readonly=True),
                sg.Button(key=browseButton1,button_text=BROWSE),
                sg.Button(key=openImageButton1,button_text=OPEN),
                sg.Combo(values=availableScale,default_value=1,key=scaleImageCombo1_key),
                sg.Button(key=resizeImageButton1,button_text=RESIZE),
                sg.Combo(values=availableTranspose,default_value=1,key=transposeImageCombo1_key),
                sg.Button(key=transposeImageButton1,button_text=TRANSPOSE),
                sg.Combo(values=availableDegree,default_value=100,key=rotateImageCombo1_key),
                sg.Button(key=rotateImageButton1,button_text=ROTATE),
                sg.Combo(values=availableRoll,default_value=1,key=rollImageCombo1_key),
                sg.Button(key=rollImageButton1,button_text=ROLL)
            ]
            ,
            [
                sg.Text("Image 2:"),
                sg.Input(key=image2Filepathname_key,readonly=True),
                sg.Button(key=browseButton2,button_text=BROWSE),
                sg.Button(key=openImageButton2,button_text=OPEN),
                sg.Combo(values=availableScale,default_value=1,key=scaleImageCombo2_key),
                sg.Button(key=resizeImageButton2,button_text=RESIZE),
                sg.Combo(values=availableTranspose,default_value=1,key=transposeImageCombo2_key),
                sg.Button(key=transposeImageButton2,button_text=TRANSPOSE),
                sg.Combo(values=availableDegree,default_value=100,key=rotateImageCombo2_key),
                sg.Button(key=rotateImageButton2,button_text=ROTATE),
                sg.Combo(values=availableRoll,default_value=1,key=rollImageCombo2_key),
                sg.Button(key=rollImageButton2,button_text=ROLL)               
            ]
            ,
            [
                sg.Text("Target file path and name:"),
                sg.Input(key=image3Filepathname_key,readonly=True),
                sg.Button(key=browseButton3,button_text=BROWSE)
            ]
            ,
            [
                sg.Combo(values=availableMerge,default_value=1,key=mergeImageCombo1_key),
                sg.Button(key=mergeImagesButton,button_text=MERGE)    
            ]
        ]
        window=sg.Window(title="Image Operation Window",layout=layout)
        
        
        while True:
            event,values=window.read()
            
            if event==sg.WIN_CLOSED:
                break
            
            if event in browseButton_dict.keys():
                filepathname=sg.popup_get_file(message="Select an image"
                                  ,title="Image Select Window"
                                  ,no_window=True
                                  ,file_types=availableExt
                                  ,default_path=defaultpath
                                  )
                
                for k,v in browseButton_dict.items():
                    if event == k:
                        window[v].update(filepathname)
            
            if event in openImageButton_dict.keys():
                for k,v in openImageButton_dict.items():
                    if event == k:
                        val=values[v[0]]
                        print(val)
                        # Check if val is NOT empty
                        if (not val is None) and len(val)!=0:
                            v[1].SetFilepathname(val)
                            v[1].UploadImageWithFilepathname_Self()
                            v[1].OpenImage_Self()
                            
            if event in resizeImageButton_dict.keys():
                for k,v in resizeImageButton_dict.items():
                    if event == k:
                        val=values[v[0]]
                        scale=values[v[2]]
                        # Check if val is NOT empty
                        if (not val is None) and len(val)!=0:
                            v[1].SetFilepathname(val)
                            v[1].UploadImageWithFilepathname_Self()
                            v[1].ScaleImage_Self(scale)
            
            if event in transposeImageButton_dict.keys():
                for k,v in transposeImageButton_dict.items():
                    if event == k:
                        val=values[v[0]]
                        degree=values[v[2]]
                        # Check if val is NOT empty
                        if (not val is None) and len(val)!=0:
                            v[1].SetFilepathname(val)
                            v[1].UploadImageWithFilepathname_Self()
                            v[1].TransposeImage_Self(degree)
                            
                            
            if event in rotateImageButton_dict.keys():
                for k,v in rotateImageButton_dict.items():
                    if event == k:
                        val=values[v[0]]
                        degree=values[v[2]]
                        # Check if val is NOT empty
                        if (not val is None) and len(val)!=0:
                            v[1].SetFilepathname(val)
                            v[1].UploadImageWithFilepathname_Self()
                            v[1].RotateImage_Self(degree)
            
            if event in rollImageButton_dict.keys():
                for k,v in rollImageButton_dict.items():
                    if event == k:
                        val=values[v[0]]
                        delta=values[v[2]]
                        # Check if val is NOT empty
                        if (not val is None) and len(val)!=0:
                            v[1].SetFilepathname(val)
                            v[1].UploadImageWithFilepathname_Self()
                            v[1].RollImage_Self(delta)
                            v[1].OpenImage_Self()
                            
            if event == mergeImagesButton:
                nonemptyImage_list=[]
                v=mergeImagesButton_dict[mergeImagesButton]
                for idx in range(1,len(mergeImagesButton_dict[mergeImagesButton]),2):
                    val=values[v[idx]]
                    if (not val is None) and len(val)!=0:
                        nonemptyImage_list.append(v[idx+1])
                        v[idx+1].SetFilepathname(val)
                        v[idx+1].UploadImageWithFilepathname_Self()
                    
                x=len(nonemptyImage_list)
                if x==0:
                    pass
                elif x==2:
                    val=values[v[0]]
                    imgs.img_tar.SetFilepathname(val)
                    imgs.img_tar.UploadImageWithFilepathname_Self()
                    direction=values[mergeImageCombo1_key]
                    imgs.MergeTwoImages_Self(val,direction=direction)
                    imgs.img_tar.OpenImage_Self()
            
        window.close()
    
def test():
    inst=ImageOperationWindow()
    
if __name__=='__main__':
    test()