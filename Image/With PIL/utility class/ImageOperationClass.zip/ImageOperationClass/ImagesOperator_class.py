from ImageOperator_class import ImageOperator

import PIL

class MergeDirection_ENUM():
    FromLeftToRight=0
    FromRightToLeft=1
    FromTopToDown=2
    FromDownToTop=3
    FromLeftDownToRightUp=4
    FromRightUpToLeftDown=5
    FromLeftUpToRightDown=6
    FromRightDownToLeftUp=7
    

class ImagesOperator():
    def __init__(self
                 ,img_src:ImageOperator
                 ,img_dest:ImageOperator
                 ,filepathname:str):
        self.img_src=img_src
        self.img_dest=img_dest
        
        self.img_tar= ImageOperator(filepathname=filepathname
                                    ,need_check_filepathname_exists=False
                                    ,need_prehandling_filepathname=False
                                    )
        
    @staticmethod
    def MergeTwoImages(img_src,img_dest,direction):
        func=[ImagesOperator.MergeTwoImages_FromLeftToRight
              ,ImagesOperator.MergeTwoImages_FromRightToLeft
              ,ImagesOperator.MergeTwoImages_FromTopToDown
              ,ImagesOperator.MergeTwoImages_FromDownToTop
              ,ImagesOperator.MergeTwoImages_FromLeftDownToRightUp
              ,ImagesOperator.MergeTwoImages_FromRightUpToLeftDown
              ,ImagesOperator.MergeTwoImages_FromLeftUpToRightDown
              ,ImagesOperator.MergeTwoImages_FromRightDownToLeftUp
              
              ]
        if direction>=len(func):
            raise ValueError
        if direction<0:
            raise ValueError
        
        im=func[direction](img_src=img_src,img_dest=img_dest)
        return im
            
    
    @staticmethod
    def MergeTwoImages_FromLeftToRight(img_src,img_dest):
        im1=img_src
        im2=img_dest
        w = im1.size[0] + im2.size[0]
        h = max(im1.size[1], im2.size[1])
        im = PIL.Image.new("RGBA", (w, h))
        im.paste(im1)
        im.paste(im2, (im1.size[0], 0))
        return im
    
    @staticmethod
    def MergeTwoImages_FromRightToLeft(img_src,img_dest):
        im1=img_src
        im2=img_dest
        w = im1.size[0] + im2.size[0]
        h = max(im1.size[1], im2.size[1])
        im = PIL.Image.new("RGBA", (w, h))
        im.paste(im2)
        im.paste(im1, (im2.size[0], 0))
        return im
    
    
    @staticmethod
    def MergeTwoImages_FromTopToDown(img_src,img_dest):
        im1=img_src
        im2=img_dest
        
        h = im1.size[1] + im2.size[1]
        w = max(im1.size[0], im2.size[0])
        im = PIL.Image.new("RGBA", (w, h))
        im.paste(im1,(0,h-im1.size[1]))
        im.paste(im2, (0,0))
        return im
    
    @staticmethod
    def MergeTwoImages_FromDownToTop(img_src,img_dest):
        im1=img_src
        im2=img_dest
        
        h = im1.size[1] + im2.size[1]
        w = max(im1.size[0], im2.size[0])
        im = PIL.Image.new("RGBA", (w, h))
        im.paste(im1,(0,0))
        im.paste(im2, (0,h-im2.size[1]))
        return im
    
    
    @staticmethod
    def MergeTwoImages_FromLeftDownToRightUp(img_src,img_dest):
        im1=img_src
        im2=img_dest
        w = im1.size[0] + im2.size[0]
        h = im1.size[1]+ im2.size[1]
        im = PIL.Image.new("RGBA", (w, h))
        im.paste(im1,(0,h-im1.size[1]))
        im.paste(im2, (im1.size[0], 0))
        return im
    
    
    @staticmethod
    def MergeTwoImages_FromRightUpToLeftDown(img_src,img_dest):
        im1=img_src
        im2=img_dest
        w = im1.size[0] + im2.size[0]
        h = im1.size[1]+ im2.size[1]
        im = PIL.Image.new("RGBA", (w, h))
        im.paste(im2,(0,h-im2.size[1]))
        im.paste(im1, (im2.size[0], 0))
        return im
    
    
    @staticmethod
    def MergeTwoImages_FromLeftUpToRightDown(img_src,img_dest):
        im1=img_src
        im2=img_dest
        w = im1.size[0] + im2.size[0]
        h = im1.size[1]+ im2.size[1]
        im = PIL.Image.new("RGBA", (w, h))
        im.paste(im1)
        im.paste(im2, (im1.size[0], im1.size[1]))
        return im
    
    @staticmethod
    def MergeTwoImages_FromRightDownToLeftUp(img_src,img_dest):
        im1=img_src
        im2=img_dest
        w = im1.size[0] + im2.size[0]
        h = im1.size[1]+ im2.size[1]
        im = PIL.Image.new("RGBA", (w, h))
        im.paste(im2)
        im.paste(im1, (im2.size[0], im2.size[1]))
        return im
    
    
    
    def MergeTwoImages_Self(self,tarFilepathname,direction):
        img_tar=ImagesOperator.MergeTwoImages(self.img_src.img,self.img_dest.img,direction=direction)
        self.img_tar.ChangeImage_Self(img_tar)
        self.img_tar.SaveImage_Self()
        
        
def test():
    filepathname1=r"C:\Users\user\Downloads\R2.png"
    filepathname2=r"C:\Users\user\Downloads\R3.png"
    filepathname3=r"C:\Users\user\Downloads\R5.png"
    inst1=ImageOperator(filepathname=filepathname1
                        , need_check_filepathname_exists=False
                        , need_prehandling_filepathname=False)
    
    inst1.UploadImageWithFilepathname_Self()
    
    inst2=ImageOperator(filepathname=filepathname2
                        , need_check_filepathname_exists=False
                        , need_prehandling_filepathname=False)
    
    inst2.UploadImageWithFilepathname_Self()
    
    insts=ImagesOperator(img_src=inst1,img_dest=inst2,filepathname=filepathname3)
    insts.MergeTwoImages_Self(filepathname3,MergeDirection_ENUM.FromRightDownToLeftUp)
    insts.img_tar.OpenImage_Self()
    
    
if __name__=='__main__':
    test()       
        