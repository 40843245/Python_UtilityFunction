import requests
import os,sys

import PIL
import numpy as np

from _FileProperty_class import _FileProperty
from DrawImage_class import DrawImage
from ImageData_class import ImageData
from ImageFilter_class import ImageFilters

from _ColorOperation_class import _ColorOperation



class ImageOperator():
    def __init__(self
                 ,filepathname:str
                 ,need_check_filepathname_exists:bool
                 ,need_prehandling_filepathname:bool
                 ):
        self.src_file=_FileProperty(filepathname=filepathname
                                    , need_check_filepathname_exists=need_check_filepathname_exists
                                    , need_prehandling_filepathname=need_prehandling_filepathname
                                    )
        self.url=""
        self.img=None
    
    def SetFilepathname(self,filepathname:str):
        self.src_file.filepathname=filepathname
    
    def GetFilepathname(self):
        return self.src_file.filepathname
        
    def SetUrl(self,url):
        self.url=url
        
    def GetUrl(self):
        return self.url
    
    def SetImage(self,img):
        self.img=img
      
    def UploadImageWithFilepathname_Self(self):
       self.img=PIL.Image.open(self.GetFilepathname())
      
    def ChangeImage_Self(self,img):
        self.img=img

    def Filter_Self(self,filt):
        result=ImageFilters.Filter(im=self.img, filt=filt)
        return result

    def GetSize_Self(self):
        result=ImageData.GetImageData.GetSize(self.img)
        return result
        
    def GetInfo_Self(self):
        result=ImageData.GetImageData.GetInfo(self.img)
        return result    
    
    def GetFormat_Self(self):
        result=ImageData.GetImageData.GetFormat(self.img)
        return result
    
    
    def GetData_Self(self,band=None):
        result=ImageData.GetImageData.GetData(self.img,band=band)
        return result
    
    def GetChannel_Self(self,channel):
        result=ImageData.GetImageData.GetChannel(im=self.img,channel=channel)
        return result
    
    def GetBands_Self(self):
        result=ImageData.GetImageData.GetBands(self.img)
        return result
    
    def GetBoundingBox_Self(self):
        result=ImageData.GetImageData.GetBoundingBox(self.img)
        return result
    
    def GetRGBColor_Self(self,color):
        result=_ColorOperation.GetRGBColor(im=self.img, color=color)
        return result
    
    def GetColor_Self(self,color,mode):
        result=_ColorOperation.GetColor(im=self.img, color=color, mode=mode)
        return result
    
    
    def CopyImage(self):
        result=self.img.copy()
        return result
    
    
    
    @staticmethod
    def SaveImage(img,pathfilename:str):
        img.save(pathfilename)
        
    def SaveImage_Self(self):
        ImageOperator.SaveImage(self.img,self.GetFilepathname())
        
    @staticmethod
    def OpenImage(filepathname):
        try:
            img=PIL.Image.open(filepathname)
            img.show()
        except OSError:
            print("ERROR!!! unknown error occured while an attempt to open file.")
        
    def OpenImage_Self(self):
        ImageOperator.OpenImage(self.src_file.filepathname)
    
    @staticmethod        
    def OpenImages(filepathname_list:list):
        for filepathname in filepathname_list:
            ImageOperator.OpenImage(filepathname=filepathname)
    
    @staticmethod
    def AutoDownloadImage(filepathname:str
                          ,url:str
                          ,need_to_pop_notification:bool):    
        r = requests.get(url)    
        if r.status_code==200:
            with open(filepathname, 'wb') as f:
                f.write(r.content)
                img=PIL.Image.open(filepathname)  
        else:
            print("The status code must be 200. However, it is "+str(r.status_code)+" which refers the error occured while requesting.")
            
    def AutoDownloadImage_Self(self,need_to_pop_notification=False):
        ImageOperator.AutoDownloadImage(filepathname=self.src_file.filepathname
                                        ,url=self.GetUrl()
                                        ,need_to_pop_notification=need_to_pop_notification)
        
        
    @staticmethod
    def ConvertImage(filepathname:str,fmt:str):
        f, e = os.path.splitext(filepathname)
        outfile = f + fmt
        if filepathname != outfile:
            try:
                with PIL.Image.open(filepathname) as im:
                    im.save(outfile)
            except OSError:
                print("ERROR!!! unknown error, cannot convert", filepathname)
                
    def ConvertImage_Self(self,fmt:str):
         ImageOperator.ConvertImage(filepathname=self.src_file.filepathname,fmt=fmt)
         
    @staticmethod
    def ConvertImageToJPG(filepathname:str):
        ImageOperator.ConvertImage(filepathname=filepathname,fmt=".jpg")
        
    def ConvertImageToJPG_Self(self):
        ImageOperator.ConvertImageToJPG(filepathname=self.src_file.filepathname)
       
    @staticmethod
    def ConvertImage_List(filepathname:str,fmts:list):
        for fmt in fmts:
            ImageOperator.ConvertImage(filepathname=filepathname,fmt=fmt)
    
    def ConvertImage_List_Self(self,fmts:list):
        ImageOperator.ConvertImage_List(filepathname=self.src_file.filepathname,fmts=fmts)
        
    @staticmethod
    def CropImage(img,box):
        region=img.crop(box)
        return region
    
    def CropImage_Self(self,box):
        region=ImageOperator.CropImage(img=self.img, box=box)
        self.img=region
        self.SaveImage_Self()
     
    @staticmethod
    def TransposeImage(img,degree):
        img=img.transpose(degree)
        return img
    
    def TransposeImage_Self(self,degree):
        self.img=ImageOperator.TransposeImage(self.img,degree=degree)
        self.SaveImage_Self()
    
    @staticmethod
    def RotateImage(img,degree):
        
        img = img.rotate(degree)
        return img
    
    def RotateImage_Self(self,degree):
        self.img=ImageOperator.RotateImage(img=self.img,degree=int(degree))
        self.SaveImage_Self()
    
    @staticmethod 
    def RollImage(img,delta):
        """Roll an image sideways."""
        xsize, ysize = img.size
        
        delta = delta % xsize
        if delta == 0:
            return img

        part1 = img.crop((0, 0, delta, ysize))
        part2 = img.crop((delta, 0, xsize, ysize))
        img.paste(part1, (xsize - delta, 0, xsize, ysize))
        img.paste(part2, (0, 0, xsize - delta, ysize))
        return img
    
    def RollImage_Self(self,delta):
        self.img=self.RollImage(img=self.img, delta=delta)
        self.SaveImage_Self()
    
    @staticmethod
    def ResizeImage(img,box):
        return img.resize(box)
    
    def ResizeImage_Self(self,box):
        self.img=self.ResizeImage(img=self.img,box=box)
        self.SaveImage_Self()
    
    @staticmethod
    def ScaleImage(img,scale):
        new_box=tuple(int(x*scale) for x in img.size)
        return img.resize(new_box)
    
    def ScaleImage_Self(self,scale):
        self.img=self.ScaleImage(img=self.img,scale=scale)
        self.SaveImage_Self()
    
    
    
def test():
    
    np_arr=np.array(([i + j for i in range(3) for j in range(3)]))
    
    
    filepathname=r"C:\Users\user\Downloads\YA4.jpg"
    inst=ImageOperator(filepathname=filepathname, need_check_filepathname_exists=False, need_prehandling_filepathname=False)
    inst.UploadImageWithFilepathname_Self()
    
    inst.SaveImage_Self()
    
    #inst.img=DrawImage.DrawALine(filepathname=filepathname, point=(0,0,100,100), fill=128)
    
    #inst.img=DrawImage.DrawBitmap(filepathname=filepathname,one_point=(0,0),fill=(255,255,255),bitmap_s="L")
    #inst.img=DrawImage.DrawChord(filepathname=filepathname, two_points=(0,0,100,100), start=1, end=10)
    #inst.img=DrawImage.DrawEllipse(filepathname=filepathname, two_points=(0,0,100,100))
    #inst.img=DrawImage.DrawPieslice(filepathname=filepathname,two_points=(0,0,100,100), start=1, end=2)
    #inst.img=DrawImage.DrawRectangle(filepathname=filepathname, two_points=(0,0,100,100))
    #inst.img=DrawImage.DrawPolygon(filepathname=filepathname, two_points=(0,0,100,100))
    #inst.img=DrawImage.DrawRegularPolygon(filepathname=filepathname, bounding_circle=(2,2,2), n_sides=4)

    
    
    inst.SaveImage_Self()
    inst.OpenImage_Self()
    
    
    
    
if __name__=='__main__':
    test()