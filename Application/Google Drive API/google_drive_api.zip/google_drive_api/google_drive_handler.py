from __future__ import print_function
import pickle
import os.path
import os
from googleapiclient.discovery import build
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request

from tabulate import tabulate
import pandas

from googleapiclient.http import MediaFileUpload

SCOPES = ['https://www.googleapis.com/auth/drive.metadata.readonly', # prepare to grant permission for readonly of google drive metafile 
          'https://www.googleapis.com/auth/drive.file' # prepare to grant permission of google drive.
         ]

class GoogleDriveHandler():
  
  """
    Description:
		Get google drive serivce
  	Parameter:
		None
    Returned Value:
		Returns Google Drive API service
  """
  @staticmethod
  def get_gdrive_service() :
    creds = None
    # The file token.pickle stores the user's access and refresh tokens, and is
    # created automatically when the authorization flow completes for the first
    # time.
    if os.path.exists('token.pickle'):
        with open('token.pickle', 'rb') as token:
            creds = pickle.load(token)
    # If there are no (valid) credentials available, let the user log in.
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(
                'credentials.json', SCOPES)
            creds = flow.run_local_server(port=0)
        # Save the credentials for the next run
        with open('token.pickle', 'wb') as token:
            pickle.dump(creds, token)
    return build('drive', 'v3', credentials=creds)

  """
    Description:
		Get a list of files in the specified drive (in the parameter items).
  	Parameter:
		items: drive in Google Drive API.
    Returned Value:
   		Returns files by Google Drive API in the given parameter items (if items exists and there are files in items), 
        None (if items exists but there are NO any files in items), or
        a string 'No files found.' (if items does NOT exist).
  """
  @staticmethod
  def list_files(items) -> list | str | None :
    if not items:
    # empty drive
     return 'No files found.'
    else:
      rows = []
      for item in items:
        # get the File ID
        id = item["id"]
        # get the name of file
        name = item["name"]
        # We can simply use .get method instead
        parents = item.get('parents','N/A')
        
        try:
        # get the size in nice bytes format (KB, MB, etc.)
          size = GoogleDriveHandler.get_size_format(int(item["size"]))
        except:
        # not a file, may be a folder
          size = "N/A"
        # get the Google Drive type of file
        mime_type = item["mimeType"]
        # get last modified date time
        modified_time = item["modifiedTime"]
        # append everything to the list
        rows.append((id, name, parents, size, mime_type, modified_time))
    # convert to a human readable table
    # table = tabulate(rows, headers=["ID", "Name", "Parents", "Size", "Type", "Modified Time"])
    table = pandas.DataFrame(rows,index=None,columns=["ID", "Name", "Parents", "Size", "Type", "Modified Time"])
    # print the table
    return table

  """
	Description:
    	Scale bytes to its proper byte format.
	Paramater:
   		b:unformatted size.
    Returned Value:
		Return size as a string that has proper byte format (such as 1.5GB)
    Example:
        1253656 => '1.20MB'
        1253656678 => '1.17GB'
  """
  @staticmethod
  def get_size_format(b, factor=1024, suffix="B") -> str:
    for unit in ["", "K", "M", "G", "T", "P", "E", "Z"]:
      if b < factor:
        return f"{b:.2f}{unit}{suffix}"
      b /= factor
    return f"{b:.2f}Y{suffix}"
  
  """
	NOT to use it now.
  	Has some bugs.
  """
  @staticmethod
  def upload_files():
    """
    Creates a folder and upload a file to it
    """
    # authenticate account
    service = GoogleDriveHandler.get_gdrive_service()
    # folder details we want to make
    folder_metadata = {
        "name": "TestFolder",
        "mimeType": "application/vnd.google-apps.folder"
    }
    # create the folder
    file = service.files().create(body=folder_metadata, fields="id").execute()
    # get the folder id
    folder_id = file.get("id")
    print("Folder ID:", folder_id)
    # upload a file text file
    # first, define file metadata, such as the name and the parent folder ID
    file_metadata = {
        "name": "test.txt",
        "parents": [folder_id]
    }
    # upload
    media = MediaFileUpload("test.txt", resumable=True)
    file = service.files().create(body=file_metadata, media_body=media, fields='id').execute()
    print("File created, id:", file.get("id"))
    
def main():
  service = GoogleDriveHandler.get_gdrive_service()
  results = service.files().list(
        pageSize=5, fields="nextPageToken, files(id, name, mimeType, size, parents, modifiedTime)").execute()
  items = results.get('files', [])
  tables = GoogleDriveHandler.list_files(items)
  print(tables)

  # GoogleDriveHandler.upload_files()

if __name__ == '__main__':
  main()