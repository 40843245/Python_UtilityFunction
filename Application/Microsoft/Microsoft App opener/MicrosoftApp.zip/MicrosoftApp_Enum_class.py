from enum import Enum
class MicrosoftApp_Enum(Enum):
    WeatherReport = 'Microsoft.BingWeather_8wekyb3d8bbwe!App'

    OOBENetworkConnectionFlow='Microsoft.Windows.OOBENetworkConnectionFlow_cw5n1h2txyewy!App'
    OOBENetworkCaptivePortal='Microsoft.Windows.OOBENetworkCaptivePortal_cw5n1h2txyewy!App'
    ClientCorePackageMetadata='MicrosoftWindows.Client.Core_cw5n1h2txyewy!PackageMetadata'
    SystemTray='MicrosoftWindows.Client.Core_cw5n1h2txyewy!Global.SystemTray'
    Taskbar='MicrosoftWindows.Client.Core_cw5n1h2txyewy!Global.Taskbar'
    FileExplorerExtensions='MicrosoftWindows.Client.Core_cw5n1h2txyewy!Global.FileExplorerExtensions'
    
    SnapLayout='MicrosoftWindows.Client.Core_cw5n1h2txyewy!Global.SnapLayout'
    StartMenu='MicrosoftWindows.Client.Core_cw5n1h2txyewy!Global.StartMenu'
    CloudExperienceHost='Microsoft.Windows.CloudExperienceHost_cw5n1h2txyewy!App'
    BioEnrollment='Microsoft.BioEnrollment_cw5n1h2txyewy!App'
    BrokerPlugin='Microsoft.AAD.BrokerPlugin_cw5n1h2txyewy!App'
    ClientPackageMetadata='MicrosoftWindows.Client.CBS_cw5n1h2txyewy!PackageMetadata'
    Accounts='MicrosoftWindows.Client.CBS_cw5n1h2txyewy!Global.Accounts'

    AppListBackup='MicrosoftWindows.Client.CBS_cw5n1h2txyewy!Global.AppListBackup'
    DesktopStickerEditor='MicrosoftWindows.Client.CBS_cw5n1h2txyewy!Global.DesktopStickerEditor'
    DesktopStickerEditorCentennial='MicrosoftWindows.Client.CBS_cw5n1h2txyewy!DesktopStickerEditorCentennial'

    DesktopVisual='MicrosoftWindows.Client.CBS_cw5n1h2txyewy!Global.DesktopVisual'
    InputApp='MicrosoftWindows.Client.CBS_cw5n1h2txyewy!InputApp'

    TextInputExtensions='MicrosoftWindows.Client.CBS_cw5n1h2txyewy!Global.TextInputExtensions'
    IrisService='MicrosoftWindows.Client.CBS_cw5n1h2txyewy!Global.IrisService'
    LiveCaptionsDesktop='MicrosoftWindows.Client.CBS_cw5n1h2txyewy!Global.LiveCaptionsDesktop'
    LogonWebHost='MicrosoftWindows.Client.CBS_cw5n1h2txyewy!LogonWebHost'
    MicrosoftGraphRecentItemsManager='MicrosoftWindows.Client.CBS_cw5n1h2txyewy!Global.MicrosoftGraphRecentItemsManager'

    ScreenClipping='MicrosoftWindows.Client.CBS_cw5n1h2txyewy!ScreenClipping'
    MiniSearchUI='MicrosoftWindows.Client.CBS_cw5n1h2txyewy!MiniSearchUI'

    FESearchUI='MicrosoftWindows.Client.CBS_cw5n1h2txyewy!FESearchUI'

    SpeechSynthesizerExtension='MicrosoftWindows.Client.CBS_cw5n1h2txyewy!Global.SpeechSynthesizerExtension'
    FamilyValueProp='MicrosoftWindows.Client.CBS_cw5n1h2txyewy!Global.FamilyValueProp'
    ValueBanner='MicrosoftWindows.Client.CBS_cw5n1h2txyewy!Global.ValueBanner'
    VoiceAccessHost='MicrosoftWindows.Client.CBS_cw5n1h2txyewy!Global.VoiceAccessHost'
    WebExperienceHost='MicrosoftWindows.Client.CBS_cw5n1h2txyewy!WebExperienceHost'
    ExperienceExtensions='MicrosoftWindows.Client.CBS_cw5n1h2txyewy!Global.ExperienceExtensions'
    WsxPackManager='MicrosoftWindows.Client.CBS_cw5n1h2txyewy!Global.WsxPackManager'
    StartMenuExperienceHost='Microsoft.Windows.StartMenuExperienceHost_cw5n1h2txyewy!App'
    ShellExperienceHost='Microsoft.Windows.ShellExperienceHost_cw5n1h2txyewy!App'
    immersivecontrolpanel='windows.immersivecontrolpanel_cw5n1h2txyewy!microsoft.windows.immersivecontrolpanel'


    Microsoft_549981C3F5F10_8wekyb3d8bbwe='Microsoft.549981C3F5F10_8wekyb3d8bbwe!App'

    

    ContentDeliveryManager='Microsoft.Windows.ContentDeliveryManager_cw5n1h2txyewy!App'
    XboxIdentityProvider='Microsoft.XboxIdentityProvider_8wekyb3d8bbwe!Microsoft.XboxIdentityProvider'
    DragonCenter='9426MICRO-STARINTERNATION.DragonCenter_kzh8wxbdkxb8p!App'
    ScreenSketch='Microsoft.ScreenSketch_8wekyb3d8bbwe!App'
    WindowsNotepad='Microsoft.WindowsNotepad_8wekyb3d8bbwe!App'
    VP9VideoExtensions='Microsoft.VP9VideoExtensions_8wekyb3d8bbwe!App'
    LockApp='Microsoft.LockApp_cw5n1h2txyewy!WindowsDefaultLockScreen'
    PrintDialog='Windows.PrintDialog_cw5n1h2txyewy!Microsoft.Windows.PrintDialog'
    CallingShellApp='Microsoft.Windows.CallingShellApp_cw5n1h2txyewy!Microsoft.Windows.CallingShellApp'
    CBSPreview='Windows.CBSPreview_cw5n1h2txyewy!Microsoft.Windows.CBSPreview'
    NarratorQuickStart='Microsoft.Windows.NarratorQuickStart_8wekyb3d8bbwe!App'
    PrintQueueActionCenter='Microsoft.Windows.PrintQueueActionCenter_cw5n1h2txyewy!App'
    XGpuEjectDialog='Microsoft.Windows.XGpuEjectDialog_cw5n1h2txyewy!Microsoft.Windows.XGpuEjectDialog'
    PeopleExperienceHost='Microsoft.Windows.PeopleExperienceHost_cw5n1h2txyewy!App'
    PinningConfirmationDialog='Microsoft.Windows.PinningConfirmationDialog_cw5n1h2txyewy!App'
    AccountsControl='Microsoft.AccountsControl_cw5n1h2txyewy!App'
    Win32WebViewHost='Microsoft.Win32WebViewHost_cw5n1h2txyewy!DPI.PerMonitorAware'

    SystemAware='Microsoft.Win32WebViewHost_cw5n1h2txyewy!DPI.SystemAware'
    Unaware='Microsoft.Win32WebViewHost_cw5n1h2txyewy!DPI.Unaware'
    XboxGameCallableUI='Microsoft.XboxGameCallableUI_cw5n1h2txyewy!Microsoft.XboxGameCallableUI'
    CapturePicker='Microsoft.Windows.CapturePicker_cw5n1h2txyewy!App'
    Apprep_ChxApp='Microsoft.Windows.Apprep.ChxApp_cw5n1h2txyewy!App'
    ParentalControls='Microsoft.Windows.ParentalControls_cw5n1h2txyewy!App'

    AppResolverUX='E2A4F912-2574-4A75-9BB0-0D023378592B_cw5n1h2txyewy!Microsoft.Windows.AppResolverUX'
    FilePicker='1527c705-839a-4832-9118-54d4Bd6a0c89_cw5n1h2txyewy!Microsoft.Windows.FilePicker'

    MicrosoftEdgeDevToolsClient='Microsoft.MicrosoftEdgeDevToolsClient_8wekyb3d8bbwe!App'
    NcsiUwpApp='NcsiUwpApp_8wekyb3d8bbwe!App'
    F46D4000_FD22_4DB4_AC8E_4E1DDDE828FE_cw5n1h2txyewy='F46D4000-FD22-4DB4-AC8E-4E1DDDE828FE_cw5n1h2txyewy!App'
    ECApp='Microsoft.ECApp_8wekyb3d8bbwe!App'
    CredDialogHost='Microsoft.CredDialogHost_cw5n1h2txyewy!App'
    AsyncTextService='Microsoft.AsyncTextService_8wekyb3d8bbwe!App'

    c5e2524a_ea46_4f67_841f_6a9465d9d515_cw5n1h2txyewy='c5e2524a-ea46-4f67-841f-6a9465d9d515_cw5n1h2txyewy!App'
    XboxSpeechToTextOverlay='Microsoft.XboxSpeechToTextOverlay_8wekyb3d8bbwe!App'

    XboxGameOverlay='Microsoft.XboxGameOverlay_8wekyb3d8bbwe!App'

    @staticmethod
    def GetEnumValue():
        return [e.value for e in MicrosoftApp_Enum ]
    """
Microsoft.People_8wekyb3d8bbwe!x4c7a3b7dy2188y46d4ya362y19ac5a5805e5x
Microsoft.SecHealthUI_8wekyb3d8bbwe!SecHealthUI
Microsoft.StorePurchaseApp_8wekyb3d8bbwe!App
Microsoft.ZuneVideo_8wekyb3d8bbwe!Microsoft.ZuneVideo
Microsoft.WindowsCamera_8wekyb3d8bbwe!App
Microsoft.WindowsCalculator_8wekyb3d8bbwe!App
Microsoft.WebpImageExtension_8wekyb3d8bbwe!App
Microsoft.WebMediaExtensions_8wekyb3d8bbwe!App
Microsoft.HEIFImageExtension_8wekyb3d8bbwe!App
Microsoft.GamingServices_8wekyb3d8bbwe!Microsoft.GamingServices
Microsoft.GamingServices_8wekyb3d8bbwe!GamingServices
Microsoft.GamingServices_8wekyb3d8bbwe!Microsoft.GamingServicesFT
Microsoft.BingTranslator_8wekyb3d8bbwe!App
Microsoft.Xbox.TCUI_8wekyb3d8bbwe!Microsoft.Xbox.TCUI
Microsoft.WindowsFeedbackHub_8wekyb3d8bbwe!App
Microsoft.BingWeather_8wekyb3d8bbwe!App
7EE7776C.LinkedInforWindows_w1wdnht996qgy!App
Microsoft.WindowsSoundRecorder_8wekyb3d8bbwe!App
Microsoft.MixedReality.Portal_8wekyb3d8bbwe!App
NortonSecurity_cjtsyd8xszapp!NortonSecurity
Microsoft.MSPaint_8wekyb3d8bbwe!Microsoft.MSPaint
Microsoft.WindowsMaps_8wekyb3d8bbwe!App
AppUp.IntelGraphicsExperience_8j3eq9eme6ctt!App
Clipchamp.Clipchamp_yxz26nhyzhsrt!App
Clipchamp.Clipchamp_yxz26nhyzhsrt!CLI
Microsoft.RawImageExtension_8wekyb3d8bbwe!App
Microsoft.MicrosoftOfficeHub_8wekyb3d8bbwe!Microsoft.MicrosoftOfficeHub
Microsoft.MicrosoftOfficeHub_8wekyb3d8bbwe!LocalBridge
Microsoft.MicrosoftOfficeHub_8wekyb3d8bbwe!OfficeHubHWA
Microsoft.MicrosoftStickyNotes_8wekyb3d8bbwe!App
Microsoft.DesktopAppInstaller_8wekyb3d8bbwe!App
Microsoft.DesktopAppInstaller_8wekyb3d8bbwe!PythonRedirector
Microsoft.DesktopAppInstaller_8wekyb3d8bbwe!winget
Microsoft.DesktopAppInstaller_8wekyb3d8bbwe!WinGetComServer
RealtekSemiconductorCorp.RealtekAudioControl_dt26b99r8h8gj!App
Microsoft.GetHelp_8wekyb3d8bbwe!App
Microsoft.WindowsAlarms_8wekyb3d8bbwe!App
Microsoft.Windows.Photos_8wekyb3d8bbwe!App
Microsoft.Windows.Photos_8wekyb3d8bbwe!SecondaryEntry
NAVER.LINEwin8_8ptj331gd3tyt!LINE
Microsoft.WindowsTerminal_8wekyb3d8bbwe!App
Microsoft.XboxGamingOverlay_8wekyb3d8bbwe!App
Microsoft.WindowsStore_8wekyb3d8bbwe!App
MicrosoftWindows.Client.WebExperience_cw5n1h2txyewy!PackageMetadata
MicrosoftWindows.Client.WebExperience_cw5n1h2txyewy!Widgets
MicrosoftWindows.Client.WebExperience_cw5n1h2txyewy!WidgetService
Microsoft.YourPhone_8wekyb3d8bbwe!App
Microsoft.ZuneMusic_8wekyb3d8bbwe!Microsoft.ZuneMusic
Microsoft.LanguageExperiencePackzh-TW_8wekyb3d8bbwe!App
Microsoft.MicrosoftEdge_8wekyb3d8bbwe!MicrosoftEdge
Microsoft.MicrosoftEdge_8wekyb3d8bbwe!PdfReader
Microsoft.LanguageExperiencePackja-JP_8wekyb3d8bbwe!App
Microsoft.SkypeApp_kzf8qxf38zg5c!App
Microsoft.MicrosoftEdge.Stable_8wekyb3d8bbwe!App
A-Volute.Nahimic_w2gh52qy24etm!App
Microsoft.OneDriveSync_8wekyb3d8bbwe!OneDrive
Microsoft.Paint_8wekyb3d8bbwe!App
Microsoft.PowerAutomateDesktop_8wekyb3d8bbwe!PAD.Console
Microsoft.PowerAutomateDesktop_8wekyb3d8bbwe!PAD.Designer
Microsoft.PowerAutomateDesktop_8wekyb3d8bbwe!PAD.BrowserNativeMessageHost
Microsoft.PowerAutomateDesktop_8wekyb3d8bbwe!PAD.Updater.MSIX
NVIDIACorp.NVIDIAControlPanel_56jybvy8sckqj!NVIDIACorp.NVIDIAControlPanel

    """