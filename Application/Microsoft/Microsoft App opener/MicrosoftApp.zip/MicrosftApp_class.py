import os

from MicrosoftApp_Enum_class import MicrosoftApp_Enum

class MicrosftApp():
    @staticmethod
    def Open(app):
        cmd=r"start shell:appsfolder\ "+app
        os.system(cmd)

def test():
    #MicrosftApp.Open(r'appsfolder\Microsoft.BingWeather_8wekyb3d8bbwe!App')
    result=MicrosoftApp_Enum.GetEnumValue()
    for x in result:
        print(x)
        MicrosftApp.Open(x)


if __name__=='__main__':
    test()