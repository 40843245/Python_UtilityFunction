import webbrowser

from MicrosoftStoreUrl_Enum_class import MicrosoftStoreUrl_Enum

class MicrosoftStoreUrl():

    @staticmethod
    def GetProductIDUrl(productName
    ,productId
    ,hl):
        result=MicrosoftStoreUrl_Enum.proudctId_baseUrl+productName+"/"+productId+"?hl="+hl
        return result

    @staticmethod
    def OpenProductIDUrl(productName
    ,productId
    ,hl):
        result=MicrosoftStoreUrl.GetProductIDUrl(productName=productName
        ,productId=productId
        ,hl=hl)
        webbrowser.open(result)

    @staticmethod
    def GetMicrosoftAppHelpUrl(la):
        result=MicrosoftStoreUrl_Enum.MicrsoftSupport_baseUrl+"/"+la+"/"+MicrosoftStoreUrl_Enum.MicrosoftAppHelp_DesktopDevice_Url
        return result
    
    @staticmethod
    def OpenMicrosoftAppHelpUrl(la):
        result=MicrosoftStoreUrl.GetMicrosoftAppHelpUrl(la)
        webbrowser.open(result)

    @staticmethod
    def GetMicrosoftStoreHomepageUrl():
        result=MicrosoftStoreUrl_Enum.homepage_baseUrl
        return result
    
    @staticmethod
    def OpenMicrosoftStoreHomepageUrl():
        result=MicrosoftStoreUrl.GetMicrosoftStoreHomepageUrl()
        webbrowser.open(result)

    @staticmethod
    def GetMicrosoftStoreSearchResultUrl_WithoutFilter(productName):
        result=MicrosoftStoreUrl_Enum.searchResult_baseUrl+"/"+productName
        return result
    
    @staticmethod
    def OpenMicrosoftStoreSearchResultUrl_WithoutFilter(productName):
        result=MicrosoftStoreUrl.GetMicrosoftStoreSearchResultUrl_WithoutFilter(productName=productName)
        webbrowser.open(result)

    @staticmethod
    def GetMicrosoftStoreSearchResultUrl_WithFilter(productName,filter:list):
        result=MicrosoftStoreUrl_Enum.searchResult_baseUrl+"/"+productName
        length=len(filter)
        for idx in range(0,length,1):
            if idx==0:
                result=result+"?filteredCategories="

            result=result+filter[idx]

            if idx!=length-1:
                result=result+","
        return result
    
    
    @staticmethod
    def OpenMicrosoftStoreSearchResultUrl_WithFilter(productName,filter:list):
        result=MicrosoftStoreUrl.GetMicrosoftStoreSearchResultUrl_WithFilter(productName=productName,filter=filter)
        webbrowser.open(result)

    @staticmethod
    def GetMicrosoftStoreCategoryUrl(category):
        result=MicrosoftStoreUrl_Enum.storeCategory_baseUrl+"/"+category      
        return result

    @staticmethod
    def OpenMicrosoftStoreCategoryUrl(category):
        result=MicrosoftStoreUrl.GetMicrosoftStoreCategoryUrl(category=category)
        webbrowser.open(result)

    


def test():
    #MicrosoftStoreUrl.OpenProductIDUrl(productName='ytd-yt-video-downloader',productId='9MZQ5285RW0Q',hl='en-us')
    #MicrosoftStoreUrl.OpenMicrosoftAppHelpUrl(la='en-us')
    #MicrosoftStoreUrl.OpenMicrosoftStoreHomepageUrl()
    #MicrosoftStoreUrl.OpenMicrosoftStoreSearchResultUrl_WithoutFilter(productName="YT")
    filter=[
        MicrosoftStoreUrl_Enum.Category.Business
    ]
    #MicrosoftStoreUrl.OpenMicrosoftStoreSearchResultUrl_WithFilter(productName="YT",filter=filter)
    category=MicrosoftStoreUrl_Enum.Category.Utilities_tools    
    MicrosoftStoreUrl.OpenMicrosoftStoreCategoryUrl(category=category)
if __name__=='__main__':
    test()