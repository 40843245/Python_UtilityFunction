class MicrosoftStoreUrl_Enum():

    homepage_baseUrl='https://apps.microsoft.com/apps'

    store_baseUrl="https://apps.microsoft.com/store"

    storeCategory_baseUrl="https://apps.microsoft.com/store/category"

    proudctId_baseUrl='https://apps.microsoft.com/store/detail/'

    searchResult_baseUrl='https://apps.microsoft.com/store/search'

    getstarted_baseUrl="https://apps.microsoft.com/store/get-started"

    productivityApps_baseUrl="https://apps.microsoft.com/store/collections/BestProductivityApps"

    windowsthemes_baseUrl="https://apps.microsoft.com/store/windows-themes"

    photoAndVideoEditingApps_baseUrl="https://apps.microsoft.com/store/collections/BestPhotoAndVideoEditingApps"

    MicrsoftSupport_baseUrl='https://support.microsoft.com' 

    MicrosoftAppHelp_DesktopDevice_Url='microsoft-store-and-billing?OCID=StoreApp_HelpLink&pc=windows.desktop'

    class Category():
        Business="Business"
        Developer_tools="Developer tools"
        Education="Education"
        Entertainment="Entertainment"
        Health_fitness="Health & fitness"
        Kids_family="Kids & family"
        Lifestyle="Lifestyle"
        Multimedia_design="Multimedia design"
        Music="Music"
        News_Weather="News & Weather"
        Personal_finance="Personal finance"
        Personalization="Personalization"
        Security="Security"
        Shopping="Shopping"
        Social="Social"
        Sports="Sports"
        Travel="Travel"
        Utilities_tools="Utilities & tools"
    