import webbrowser
import openai

class chatGPT():
    chatGPT_base_url="https://chat.openai.com/chat"
    api=""

    @staticmethod
    def SetAPI(api:str):
        chatGPT.api=api

    class Open():
        @staticmethod
        def OpenUrl():
            url=chatGPT.chatGPT_base_url
            webbrowser.open(url)
    class Question():
        @staticmethod
        def CreateAQuestion(
            prompt:str
            ,engine
            ,max_tokens:int
            ,n:int
            ,stop
            ,temperature:float
            ):
            openai.api_key = chatGPT.api

            response = openai.Completion.create(
                engine=engine,
                prompt=prompt,
                max_tokens=max_tokens,
                n=n,
                stop=stop,
                temperature=temperature,
            )
            result=response.choices
            answer = response.choices[0].text.strip()
            return (answer,result)

    class Chat():

        @staticmethod
        def Chat(api:str):
            from LetterHandler_class import LetterHandler

            def generate_response(prompt):
                completions = openai.Completion.create(
                engine = "davinci",
                prompt = prompt,
                max_tokens = 2000,
                n = 1,
                stop = None,
                temperature=0.5,
            )
                message = completions.choices[0].text.strip()
                message=LetterHandler.RemoveTheFirstLetters_AtMultiLine(s1=message,src_s2=0,need_to_strip_extra_atend_after_join=False)
                return message

            openai.api_key = api

            user_input = ""
            chat_history = ""

            # Start the conversation loop
            while True:
                user_input = input("You: ")
                if user_input.lower() == "bye":
                    break
                ai_response = generate_response(user_input)
                chat_history += "You: " + user_input + "\n"
                chat_history += "ChatGPT: " + ai_response + "\n"
                print("ChatGPT: " + ai_response)
            # Clear the history
            user_input = ""
            chat_history = ""

def test():
    api="<Your-API-KEY>"
    prompt = str(input())
    chatGPT.SetAPI(api=api)
    #chatGPT.Open.Question.CreateAQuestion(prompt=prompt,engine="davinci",max_tokens=100,n=1,stop=None,temperature=0.5)
    chatGPT.Chat().Chat(api=api)

if __name__=='__main__':
    test()