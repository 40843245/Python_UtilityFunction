from enum import Enum
class ScriptExtensions(Enum):
    BatchFile=".bat"
    TextFile=".txt"
    Python=".py"
    C=".c"
    CPP=".cpp"
    CSharp=".cs"
    MatLabEditor=".m"
    MicrsoftAccessTable=".mat"
    Java=".java"
    JavaScript=".js"
    Php=".php"
    Html=".html"
    CSS=".css"
    VB='.vba'
    Kotlin=".kt"
    PerlScript=".plx"
    PerlModule=".pm"
    PerlLibraray=".pl"
    Go=".tmpl"
    
    @staticmethod
    def GetEnum():
        return [e for e in ScriptExtensions ]
    @staticmethod
    def GetEnumValue():
        return [e.value for e in ScriptExtensions ]


 
def test():
   result=ScriptExtensions.GetEnumValue()
   print(result)
   
   """
   r=list(ScriptExtensions.__members__.values())
   print(type(r))
   for x in r:
    print(x)
    print(type(x))
    """
if __name__=='__main__':
    test()
    
    
    
    
    