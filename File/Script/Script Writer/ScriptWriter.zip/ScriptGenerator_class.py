import os 

from ScriptExtensions_class import ScriptExtensions
from WriteStream_class import WriteStream
class ScriptGenerator():
    @staticmethod
    def WriteDataToScript(content:str
        ,filepathname:str)->None:

        fileExt=os.path.splitext(filepathname)[-1]
        if not fileExt in ScriptExtensions.GetEnumValue():
            raise ValueError
        
        ws=WriteStream()
        filepath=os.path.dirname(filepathname)
        filename=os.path.basename(filepathname).rstrip(fileExt)
        ws.SetPath(filepath=filepath,filename=filename,fileExt=fileExt)
        ws.WriteData(textContent=content)
    
def test():
    filepathname=r"C:\Users\user\ "+ "jaytest1.py"
    content="12345"
    ScriptGenerator.WriteDataToScript(filepathname=filepathname,content=content)

if __name__=='__main__':
    test()


