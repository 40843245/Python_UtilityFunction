website = "https://www.google.com/";
filetypes = ".json";
downloadPath = "C:\Users\40843\OneDrive\Utility\MatLab\Statistics\StockEstimator\output"
crawling(website,filetypes,downloadPath);