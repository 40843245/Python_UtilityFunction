function output1 = NestedStruct2Table(input1,tempInput1)
    output1 = tempInput1;
    if isstruct(input1)
        input1 = struct2cell(input1)
    end
    if iscell(input1)
        for idx=1:numel(input1)
            elem = input1{idx};
            disp(elem);
            if ~isempty(elem)
                output = NestedStruct2Table(elem,tempInput1)
                %disp(output);
                %disp(output1);
                if ~isempty(elem)
                    output1(end+1,:) = output;
                end
            end
        end
    end
end