var1 = struct();
var1.val1 = [1,2,3,-1];
var1.val2 = [4,5,6,-2];
var1.val3 = [7,8,{'valm1',9}];

disp("var1:");
disp(var1);

output1 = NestedStruct2Table(var1);

disp("output1:");
disp(output1);
disp("class(output1):");
disp(class(output1));

writetable(output1,'output1.xlsx');

writestruct(var1,'var1.json');

