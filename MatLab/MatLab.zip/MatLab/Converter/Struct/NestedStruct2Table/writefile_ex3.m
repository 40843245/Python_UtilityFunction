% Sample Data
C = repmat({num2cell(1:4,1)},10,1);
% Unpacked
C2 = vertcat(C{:})
C3 = cell2mat(C2)