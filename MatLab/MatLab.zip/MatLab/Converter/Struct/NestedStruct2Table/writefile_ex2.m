var1 = struct();
var1.val1 = [1,2,3,-1];
var1.val2 = [4,5,6,-2];
var1.val3 = [7,8,{'valm1',9}];

% writestruct(var1,'var1.json','WriteMode','Append');
% var2 = struct2cell(var1)
% var3 = cell2mat(var2)
%var4 = writetable(var1)

var4 = struct2table(var1)

writetable(var4,'var4.xlsx','WriteMode','Append')

writestruct(var1,'var1.json');

