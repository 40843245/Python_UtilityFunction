var1 = struct();
var1.val1 = [1,2,3,-1];
var1.val2 = [4,5,6,-2];
var1.val3 = [7,8,{'valm1',9}];

writestruct(var1,'var1.json');
writecell(struct2cell(var1),'var1.txt');
writetable(struct2table(var1),'var1.xlsx');

