function output1 = NestedStruct2Table(input1)
    output1 = input1;
    if isempty(input1)
        return;
    end
    if isstruct(input1)
        input1 = struct2table(input1);
    end
    output1 = input1;
    return;
end