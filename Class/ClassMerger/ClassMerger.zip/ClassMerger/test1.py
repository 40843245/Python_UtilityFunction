import pyparsing as pp

whitespace = ' '
#definition = ( pp.Keyword("class") )
#pp.ignore_whitespace = True
#definition = pp.Keyword("class")
definition = And(pp.Keyword("class"),
hello = """
class def Func1(): pass
class def Func2(): pass 
class(): def Func3(): pass
class3():
passclass
"""
print(definition)
print(type(definition))
print(definition.parseString(hello))