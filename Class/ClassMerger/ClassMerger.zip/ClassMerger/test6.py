from REHandler import REHandler

class ContentFinder():
    """
    Intro: 
        Get the content info. 
    Parameter:
        content: a string as content.
    Returned Value:
        A dict whose keys are classes in content (the next word after class keyword) and 
        whose values are methods in the class (the next word after def keyword).
    Examples:
        Example 1:
            A file content is shown as follows.
            Input:
                class Response(): def Unknown(): pass \nclass Animal(): def Dog(): pass
            Output:
                {'Response': ['Unknown'], 'Animal': ['Dog']}
            Explanation:
                There are two classes Response and Animal.
                There are one method named Unknown in Response class.
                There are one method named Dog in Animal class.
    """
    @staticmethod
    def GetInfo(content:str):
        keyword = 'class'
        s = content
        allClass = REHandler.NextWord(s,keyword)
        paragraphs = REHandler.SplitParagraph(s, keyword)
        allMethod = list()
        t = list()
        for i in range(0,len(paragraphs),1):
            paragraph = paragraphs[i]
            t = REHandler.NextWord(paragraph, "def")
            if t != None and len(t) > 0:
                allMethod.append(t)
        table = dict()
        for i in range(0,len(allMethod),1):
            table.update({allClass[i]:allMethod[i]})
        return table
if __name__ == '__main__':
    
    print('!'*40)
    s = 'class Response(): def Yes(): pass \n'
    r = ContentFinder.GetInfo(s)
    print('-'*40)
    print(r)
        
    print('!'*40)       
    keyword = 'class'
    s = 'class Response(): def No(): pass \n'
    r = ContentFinder.GetInfo(s)
    print('-'*40)
    print(r)
    

    print('!'*40)
    s = 'class Response(): def Unknown(): pass \n'
    r = ContentFinder.GetInfo(s)
    print('-'*40)
    print(r)
    

    print('!'*40)
    s = 'class Response(): def Unknown(): pass \nclass Animal(): def Dog(): pass'
    r = ContentFinder.GetInfo(s)
    print('-'*40)
    print(r)