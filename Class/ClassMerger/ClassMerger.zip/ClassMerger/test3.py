import re
class REHandler():
    @staticmethod
    def WordRest(delim : str , s : str , rests : str ,ends : str ):        
        expr = r'(?<=('+delim+'))('+rests+'+'+ends+'*)'
        m = re.split(expr, s ,flags = re.NOFLAG)
        whitespace = ' '
        r = [ elem.removesuffix(whitespace) for elem in m if elem.endswith(delim) == False  ]
        nolast = r[:-1]
        return ( expr, m , r , nolast)
    @staticmethod
    def NextWord(s : str , keyword:str):
        expr = r'.*(('+keyword+'))'+'('+'\s*\S*'+')'
        pattern = re.compile(expr,re.DOTALL)
        m = pattern.search(s,0)
        
        nextword = list()
        while m != None:
            groups = m.groups(0)
            endPos = m.end()
            whitespace = ' '
            w = groups[2].strip(whitespace)
            print("m:")
            print(m)
            print("groups:")
            print(groups)
            print('*'*40)
            print("w:")
            print(w)
            nextword.append(w)
            m = pattern.search(s,endPos)
        
        return nextword
            
if __name__ == '__main__':
    keyword = 'class'
    s = 'class Response(): def Yes(): pass \n'
    rests = '\w'
    ends = '\s'
    r = REHandler.NextWord(s,keyword)
    print('-'*40)
    print(r)
    
    keyword = 'class'
    s = 'class Response(): def No(): pass \n'
    rests = '\w'
    ends = '\s'
    r = REHandler.NextWord(s,keyword)
    print('-'*40)
    print(r)
    
    keyword = 'class'
    s = 'class Response(): def Unknown(): pass \n'
    rests = '\w'
    ends = '\s'
    r = REHandler.NextWord(s,keyword)
    print('-'*40)
    print(r)
    
    keyword = 'class'
    s = 'class Response(): def Unknown(): pass \nclass Animal(): Dog(): pass'
    rests = '\w'
    ends = '\s'
    r = REHandler.NextWord(s,keyword)
    print('-'*40)
    print(r)