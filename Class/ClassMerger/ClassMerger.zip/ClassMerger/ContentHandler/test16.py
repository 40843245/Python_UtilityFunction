import linecache
if __name__ == '__main__':
    x = 2
    r = linecache.getline(__file__,3)
    print(r)