from StringHandler2 import StringHandler
if __name__ == '__main__':
    s = '#startPos # another single line comments.'
    keyword = '#'
    r = StringHandler.Single.FindAll(s, keyword)
    print("r:")
    print(r)
    