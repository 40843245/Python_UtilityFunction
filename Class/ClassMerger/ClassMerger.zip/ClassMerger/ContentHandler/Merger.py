import shutil
from pathlib import Path
from ElemsHandler import ElemsFinder
from ClassHandler2 import ClassHandler
from FuncHandler import FuncHandler
from IndentationHandler2 import IndentationHandler

class Merger():
    class Class():
        @staticmethod
        def JoinToClasses( classes : list ) -> str:
            string = ""
            for i in range(0,len(classes),1):
                s = Merger.Class.JoinToClass(classes[i][:])
                string += s
            return string
            
        @staticmethod
        def JoinToClass( classItem : list ) -> str:
            if classItem is None:
                raise Exception("Can Not join it to class.")
            if not isinstance(classItem , (list,tuple)):
                raise Exception("Can Not join it to class.")
            whitespace = ' '
            tab = '\t'
            newLine = '\n'
            leftBracket = '('
            rightBracket = ')'
            semicolon = ':'
            comma = ','
            
            string = ""
            
            string += "class"
            string += whitespace
            string += classItem[0] 
            string += leftBracket
            string += whitespace
            string += classItem[1] 
            string += whitespace
            string += rightBracket
            string += whitespace
            string += semicolon
            string += whitespace
            string += newLine
            
            funcs = classItem[2]
            if not funcs is None and len(funcs) > 0 :
                funcName = funcs[0]
                if not funcName is None and len(funcName) > 0 :
                    string += tab
                    string += "def"
                    string += whitespace
                    string += funcName 
                    string += whitespace
                    string += leftBracket
                    argvs = funcs[1]
                    firstTime = True
                    if not argvs is None and len(argvs) > 0 :
                        for j in range(0,len(argvs),1):
                            argv = argvs[j]
                            if not argv is None:
                                if not argv[0] is None and len(argv[0]) > 0 :
                                    string += argv[0] 
                                    string += whitespace
                                    if len(argv) > 1 and not argv[1] is None:
                                        string += semicolon
                                        string += whitespace
                                        string += argv[1]
                                        string += whitespace
                                    else:
                                        string += whitespace
                                        string += "None"
                                        string += whitespace
                                    if firstTime == False:
                                        string += comma
                                    firstTime = False
                    string += rightBracket
                    string += whitespace
                    string += semicolon
                    string += newLine
                    if len(funcs) > 2:
                        funcContent = funcs[2]
                        if not funcContent is None and len(funcContent) > 0 :
                            splittedList = funcContent.split(newLine)
                            tab1 = newLine + tab * 2 
                            indentedString = tab1.join(splittedList)
                            string += tab1
                            string += indentedString
                            string += newLine
                        else:
                            string += tab * 2 
                            string += "pass"
                            string += newLine
                    else:
                        string += tab * 2
                        string += "pass"
                        string += newLine
            return string
        class Method():
            @staticmethod
            def MergeDuplicateMethods( classes :list[tuple]):
                classesList = list()
                for i in range(0,len(classes),1):
                    currClass = classes[i]
                    currClass_t = currClass[:]
                    funcs = currClass[2]
                    for j in range(0,len(funcs),1):
                        currClass_t[2] = funcs[j]
                        classesList.append(currClass_t)
                keyIndices = [0,1,[0,1]]
                newClasses = ElemsFinder.NestedValuesOfSameKeys(classesList, keyIndices)              
                string = Merger.Class.JoinToClasses(newClasses[0])             
                return string
            @staticmethod
            def Merge(indicesList:list,methods:list) -> (list| None):                
                if indicesList is None :
                    raise Exception("Invalid indices.")
                if len(indicesList) <= 0 :
                    return methods             
                keyIndices = [0,1,2]
                newMethods = list()
                for i in range(0,len(indicesList),1):
                    l1 = list()
                    if indicesList[i] == None or len(indicesList[i]) < 2 :
                        raise Exception("Unknown issues.")
                    for j in range(1,len(indicesList[i]),1):
                        startIndex = indicesList[i][0]
                        mergeIndex = indicesList[i][j]
                        thisElems = ElemsFinder.GetOtherElem(methods[startIndex], keyIndices)
                        otherElems = ElemsFinder.GetOtherElem(methods[mergeIndex], keyIndices)
                        minLength = min(len(thisElems),len(otherElems))
                        for k in range(0,minLength,1):
                            if thisElems[k] == None or otherElems[k] == None :
                                raise Exception("Error!!! Either elem of thisElems otherElems is None.")
                            l1.append(thisElems[k] + '\n' + otherElems[k] )
                    if l1 != None and len(l1) > 0 :
                        originalList = [ methods[startIndex][keyIndices[i]] for i in range(0,len(keyIndices),1)]
                        newMethods.append(originalList + l1)
                return newMethods
                        
    class File():
        @staticmethod
        def Merge(srcFullPaths : list[str] , destFullPath : str, numOfLineBreaks : int , options : (dict|None)) -> list[str]:
            if numOfLineBreaks <= 0 :
                raise Exception("The specified number of line breaks (named numOfLineBreaks) must be a positive integer.")
            with open(Path(destFullPath), 'wb') as dest:
                for i in range(0,len(srcFullPaths),1):
                    fullPath = srcFullPaths[i] 
                    with open(Path(fullPath),'rb') as src:
                        shutil.copyfileobj(src, dest)
                    newBytes = str.encode("\n")
                    for j in range(0,numOfLineBreaks,1):
                        dest.write(newBytes)              
            print("Merge two files successfully!")
            newClasses = Merger.File.GetInfo(destFullPath)        
            fileContent = ''
            with open(destFullPath,'r') as dest:
                fileContent = dest.read()
            originalFileContent = fileContent
            newFileContent = fileContent
            if not options is None:
                if not isinstance(options, (dict)) :
                    raise Exception("options must be a dict object.")
                if options.get("MergeMode") in ["MergeClass"] :
                    newFileContent = Merger.Class.Method.MergeDuplicateMethods(newClasses)
                    with open(destFullPath,'w') as dest:
                        dest.write(newFileContent)
                    print("Merge class in the file successfully!")
            return (originalFileContent,newClasses,newFileContent)
        @staticmethod
        def GetInfo(srcFullPath : str ):
            with open(Path(srcFullPath),'r') as src:
                content = src.read()                  
                stringList = ClassHandler.Class.String.Split(content)
                classes = list()
                for string in stringList :    
                    cla = ClassHandler.Class.String.GetClassContent(string)
                    classes.append(cla)
                classesList = classes[:]
                for i in range(0,len(classes),1):
                   cla = classesList[i]
                   c = FuncHandler.Func.String.GetInfos(cla[2])
                   classesList[i][2] = c
                   
                comments = IndentationHandler.Indentation.String.CheckIndentations(content)
                if not comments is None and len(comments) >= 0 :
                   print("comments:")
                   print(comments)
                return classesList
if __name__ == '__main__':
    fullPaths = [
        "./Demo/demo_1.py",
        "./Demo/demo_2.py",
    ]
    destFullPath = "./Demo/merged_file.py"
    options = { "MergeMode":"MergeClass" }
    #options = {  "MergeMode" : None }
    r = Merger.File.Merge(fullPaths,destFullPath,2 , options )
    print("r[0]:")
    print(r[0])
    print("r[1]:")
    print(r[1])
    print("r[2]:")
    print(r[2])
    

    classes = ClassHandler.Class.String.GetInfos(r[2])    
    
    print("classes:")
    print(classes)
