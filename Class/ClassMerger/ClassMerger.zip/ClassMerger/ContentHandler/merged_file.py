"""
DemoClass in demo_1.py
"""
class DemoClass():
    def Func1():
        pass
    

"""
DemoClass in demo_2.py
"""
class DemoClass(x):
    def Func2():
        pass
    
    def Func1():
        return "Method Func1 of DemoClass in demo_2.py file."

