from ClassHandler2 import ClassHandler

class ContentFinder():
    class Class():
        """
        Intro: 
            Get the content info. 
        Parameter:
            content: a string as content.
        Returned Value:
            A list whose elem is a dict.
            The dict whose keys are classes in content (the next word after class keyword) and 
            whose values are methods in the class (the next word after def keyword).
        Examples:
            Example 1:
                A file content is shown as follows.
                Input:
                    class Response(): def Unknown(): pass \nclass Animal(): def Dog(): pass
                Output:
                    [{'Response': ['Unknown']}, {'Animal': ['Dog']}]
                Explanation:
                    There are two classes Response and Animal.
                    There are one method named Unknown in Response class.
                    There are one method named Dog in Animal class.
        """
        @staticmethod
        def GetInfo(s:str):
            r = ClassHandler.Class.String.GetInfo(s)
            return r
if __name__ == '__main__':
    
    print('!'*40)
    s = """\
    class DemoClass():
        def Func1():
            pass
        

    class DemoClass():
        def Func2():
            pass
        
        def Func1():
            return "Method Func1 of DemoClass in demo_2.py file."
    """
    r = ContentFinder.Class.GetInfo(s)
    print(r)