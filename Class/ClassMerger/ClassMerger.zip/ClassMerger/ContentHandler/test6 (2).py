if __name__ == '__main__':
    l = [1,2]
    l.insert(1,'a')
    print(l)