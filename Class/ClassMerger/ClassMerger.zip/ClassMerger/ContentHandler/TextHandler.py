from StringHandler2 import StringHandler
from DictionaryHandler import DictionaryHandler

class TextHandler():
    class Text():
        @staticmethod
        def Index(s:str,row:int,col:int) ->str:
            newLine = '\n'
            lines = s.split(newLine)
            return lines[row][col]
            
        @staticmethod
        def Range(s:str,starts:tuple[int],ends:tuple[int],options : (dict | None) = None ) -> str :
            newLine = '\n'
            lines = s.split(newLine)
            string = ''
            defaultOptions = { 
                        "ignoreStartPos" : False ,
                        "ignoreEndPos" : False ,
            }
            options = DictionaryHandler.Dict.Operation.DefaultDict(options, defaultOptions)
            
            if isinstance(starts, (tuple) ) == False:
                raise Exception("Error!!! starts must be a tuple.")
            if isinstance(ends, (tuple) ) == False:
                raise Exception("Error!!! ends must be a tuple.")
            if ((starts[0] > ends[0] ) or \
                (starts[0] == ends[0] and starts[1] > ends[1] ) ) and \
                options.get("ignoreStartPos") == True and\
                options.get("ignoreEndPos") == True:
                raise Exception("Error!!! ends is greater than starts.")
            

            if starts[0] == ends[0]:
                startPos = starts[1] if options.get("ignoreStartPos") == False else 0
                endPos = ends[1] if options.get("ignoreEndPos") == False else len(lines[ends[0]])
                string += lines[ends[0]][startPos:endPos]
                return string
            else :
                startPos = starts[1] if options.get("ignoreStartPos") == False else 0
                endPos = ends[1] if options.get("ignoreEndPos") == False else len(lines[ends[0]])
                string += ( lines[starts[0]][startPos:] + newLine )
                for rowIndex in range(starts[0]+1,ends[0],1):
                    string += (lines[rowIndex][:] + newLine)
                string += lines[ends[0]][:endPos]
                return string
            
        @staticmethod
        def InsertText(line:str,starts:int,textToInsert : str) -> str:
            if starts < 0 :
                raise Exception("The pos (named starts) must be greater than or equal to 0.")
            rightText = line[starts+1:]
            leftText = line[:starts]
            textAfterInserted = leftText + textToInsert + rightText
            return textAfterInserted
        
if __name__ == '__main__':
    s = """\
#1st singleline comment # NOT an another singleline comment since it is in 1st singleline comment.
'''1st multiline comment''' 
'''2nd multiline comment
'''
\tclass DemoClass(x):
\t\t'''3rd multiline comment''' \"\"\"4th multiline comment\"\"\"
\t\tdef Func1():
\t\t\tpass \"\"\"'''5th multiline comment'''\"\"\"
\tclass DemoClass():
\t\tdef Func2():
\t\t\tpass
\t\tdef Func1():
\t\t\treturn "Method Func1 of DemoClass in demo_2.py file."
'''
6th multiline comment
# NOT a singleline comment.
end of 6th multiline comment
'''
\t#2nd singleline comment '''NOT a multiline comment since it is in 2nd singleline comment'''
'''
7th multiline comment
# NOT a singleline comment.
end of 7th multiline comment

''' # Is a singleline comment.

''' hello REWSSZZ\"\"\" world ''' what \"\"\" the \"\"\" fuck?
"""
    s2 = """"""
    s3 = """"""
    starts = (0,5)
    ends = (0,10)
    options = None
    print("s:")
    print(s)
    print('^'*40)
    s = StringHandler.Single.Whitespacize(s)
    
    r = TextHandler.Text.Range(s, starts, ends,options)
    
    print("r:")
    print(r)
    print('^'*40)
    