class DemoClass():
    """
	Bullshit!
    """
    def Func1():
        pass

string = """\
\tBullshit!
"""

lines = list()
pos = list()
f = open(__file__, 'r') 
fileContent = f.read()
lines = fileContent.split('\n')
       
for i in range(0,len(lines),1):
    line = lines[i]
    if line.count('"""') > 0 :
        pos.append(i)
        if len(pos) == 2:
            break
f.close()

f = open(__file__, 'w')
if len(pos) > 0 :
    stringList = string.split('\n')
    j = 0 
    for i in range(pos[0]+1,pos[1],1) :
        if j >= len(stringList):
            break
        lines[i] = stringList[j]
        j += 1
        fileContent = '\n'.join(lines)
    if len(fileContent) > 0 :
        f.write(fileContent)
        
f.close()