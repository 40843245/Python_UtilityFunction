from NestedFlatterInhomogenous import NestedFlatterInhomogenous
if __name__ == '__main__':
    classes = [
                ['DemoClass', '', [['Func1', [['', None]], 'pass\n    \n']]], 
                ['DemoClass', '', [
                                    ['Func2', [['', None]], 'pass\n    \n    '], 
                                    ['Func1', [['', None]], 'return "Method Func1 of DemoClass in demo_2.py file."']]
                                  ]
                ]
    depth = 2
    print("classes:")
    print(classes)
    
    classesList = list()
    
    for i in range(0,len(classes),1):
        currClass = classes[i]
        currClass_t = currClass[:]
        funcs = currClass[2]
        for j in range(0,len(funcs),1):
            currClass_t[2] = funcs[j]
            classesList.append(currClass_t)
    
    print("classesList:")
    print(classesList)
    
    r = NestedFlatterInhomogenous.PartiallyFlat(classesList,depth)
    
    print("r:")
    print(r)
    
    
    