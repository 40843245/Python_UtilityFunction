class StringHandler():
    class Single():
        class Prefix():
            @staticmethod        
            def GetPrefixesIndex(src:str, keywords:list) -> int:
                if not isinstance(src, (str)):
                    raise Exception("Invalid source (named src).")
                if not isinstance(keywords, (list)):
                    raise Exception("Invalid keywords (named keywords).")
                    
                keywordsIndices = list()
                indexTemp = posTemp = 0 
                hasMeetRequirement = True
    
                while posTemp < len(src) and hasMeetRequirement == True:
                    hasMeetRequirement = False
                    for i in range(0,len(keywords),1):
                        keyword = keywords[i]
                        indexTemp = 0 
                        prevPosTemp = posTemp
                        while posTemp < len(src):
                            c = src[posTemp]
                            if c != keyword:
                                break
                            indexTemp += 1
                            posTemp += 1
                        if indexTemp > 0:
                            hasMeetRequirement = True
                            keywordsIndices.append( [i,prevPosTemp,indexTemp] )
                return keywordsIndices                    
        
        class Keyword():
            @staticmethod
            def GetPoses(s:str,keyword:str) -> list :
                newLine = '\n'
                lines = s.split(newLine)
                infos = list()
                for i in range(0,len(lines),1):
                    line = lines[i]
                totalLength = 0
                startIndex = 0
                for i in range(0,len(lines),1):
                    line = lines[i]
                    if line.count(keyword) > 0:
                        sIndex = line.find(keyword, 0 )
                        tu = (i,sIndex)
                        infos.append(tu)
                    totalLength += ( len(line) + 1 )
                return infos
        @staticmethod
        def Whitespacize(s:str):
            return s.replace('\t',' '*4)
    
        @staticmethod
        def GetIndentation(s:str) -> int:
            if s is None:
                raise Exception("The input is None.")
            if not isinstance(s, (str)):
                raise Exception("The input is not a string.")
            if len(s) <= 0 :
                return -1 
                
            whitespace = ' '
            tab = '\t'
            newLine = '\n'
            wt = whitespace + tab            
            lineNo = -1 
            whitespaceCount = 0
            tabCount = 0 
            currPos = -1
            lines = s.split(newLine)
            for currLineNo in range(0,len(lines),1):
                currLine = lines[currLineNo]
                if not currLine is None and len(currLine) > 0 and len(currLine.lstrip(wt)) > 0:
                    lineNo = currLineNo
                    break
            if lineNo == -1:
                return -1 
            line = lines[lineNo]
            
            prevChar = ''
            for i in range(0,len(line),1):
                currChar = line[i]
                if not currChar in wt:
                    break
                if currChar != prevChar :
                    whitespaceCount = 0
                    tabCount = 0
                    currPos = i 
                #
                if currChar == whitespace :
                    whitespaceCount += 1
                else:
                    tabCount += 1
            prevChar = currChar 
            return (whitespaceCount,tabCount,currPos)
        @staticmethod
        def FindAll(s:str,keyword:str):
            index = -1
            table = list()
            while True:
                index = s.find(keyword,index+1)
                if index == -1 :
                    break
                table.append(index)
            return table
        @staticmethod
        def Match(s:str,keyword:str):
            startPosIndex = StringHandler.Single.FindAll(s, keyword)
            r = [ (elem, elem + len(keyword) ) for elem in startPosIndex ]
            return r    
        
        @staticmethod
        def Split(s:str,keyword:str) -> list[str] :            
            keywordIndices = StringHandler.Single.Keyword.GetPoses(s, keyword)
            startPosList = StringHandler.Single.FindAll(s, keyword)
            startPosList =  [ startPosList[i] - keywordIndices[i][1] for i in range(0,len(startPosList),1)]
            stringList = list()
            if startPosList == None:
                raise Exception("Unknown issues.")
            if len(startPosList) <= 0 :
                return [s]
            for currIndex in range(0,len(startPosList) - 1 ,1):
                s1 = s[startPosList[currIndex] : startPosList[currIndex+1] ]
                stringList.append(s1)
    
            s1 = s[ startPosList[-1] : -1 ]
            stringList.append(s1)
            return stringList
                
if __name__ == '__main__' :
    s = """\
\t\t''' Multiline Comment''' 
\tclass DemoClass():
        def Func1(argv1,argv2:int)->tuple:
pass
\tclass DemoClass():
        def Func2(argv1,argv2,)->list:
            pass
    """
    whitespace = ' '
    tab = '\t'
    newLine = '\n'
    wt = [ whitespace , tab ] 
    keyword = "class"
    lines = s.split(newLine)
    s = StringHandler.Single.Whitespacize(s)
    print(s)
    r = StringHandler.Single.Prefix.GetPrefixesIndex(lines[0], wt)
    print(r)