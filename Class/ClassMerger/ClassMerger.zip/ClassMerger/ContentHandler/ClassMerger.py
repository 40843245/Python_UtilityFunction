import shutil
from pathlib import Path
# from ContentFinder import ContentFinder
from ClassHandler import ClassHandler
class Merger():
    class File():
        @staticmethod
        def Merge(srcFullPaths : list[str] , destFullPath : str, numOfLineBreaks : int ):
            if numOfLineBreaks <= 0 :
                raise Exception("The specified number of line breaks (named numOfLineBreaks) must be a positive integer.")
            try:
                with open(Path(destFullPath), 'wb') as dest:
                    for i in range(0,len(srcFullPaths),1):
                        fullPath = srcFullPaths[i] 
                        with open(Path(fullPath),'rb') as src:
                            shutil.copyfileobj(src, dest)
                        newBytes = str.encode("\n")
                        for j in range(0,numOfLineBreaks,1):
                            dest.write(newBytes)              
                print("Files merged successfully!")
            except Exception as ex:
                raise Exception("Cannot merge files! Msg:\n%s" % (ex))
    
    class Class():
        @staticmethod
        def MergeClass(srcFullPath : str ):
            try:
                with open(Path(srcFullPath),'r') as src:
                   whitespace = ' '
                   newline = '\n'
                   tab = '\t'
                   content = src.read()
                   
                   r = ClassHandler.Class.String.GetInfos(content)
                   
                   print("r:")
                   print(r)
                   
            except Exception as ex:
                raise Exception("Error\n%s" % (ex))
            
if __name__ == '__main__':
    fullPaths = [
        "./Demo/demo_1.py",
        "./Demo/demo_2.py",
    ]
    destFullPath = "merged_file.py"
    r = Merger.File.Merge(fullPaths,destFullPath,2)
    print(r)
    r = Merger.Class.MergeClass(destFullPath)
            
            