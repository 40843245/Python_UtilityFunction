from FuncHandler import FuncHandler
from REHandler import REHandler

class ClassHandler():
    class Class():
        class String():
            """
            Intro:
                A method that returns info for all class definitions with given string.
                (Bunches of classes)
            Parameter:
                s: given string
            Returned Value:
                All infos that contains info for all classes.
            """
            @staticmethod
            def GetInfos(s:str):
                classes = ClassHandler.Class.String.Split(s)
                infos = list()
                for cla in classes:
                    info = ClassHandler.Class.String.GetInfo(cla)
                    infos.append(info)
                return infos
            
            """
            Intro:
                A method that returns info for the class definition with given string.
                (Single class)
            Parameter:
                s: given string.
            Returned Value:
                All info that contains info for the class.
            """
            @staticmethod
            def GetInfo(s : str):
                keyword = "class"
                newline = '\n'
                tab = '\t'
                whitespace = ' '       
                wn = whitespace + newline + tab
                
                s = s.lstrip(wn)
                s = s.lstrip(keyword)
                s = s.lstrip(wn)
                
                cla = FuncHandler.Func.String.GetInfos(s)
                return cla
            
            """
            Intro:
                A method that splits the string into class definitions.
            Parameter:
                s: given string.
            Returned Value:
                A list that contains all class definitions.
            """
            @staticmethod
            def Split(s:str):
                keyword = 'class'
                r = REHandler.SplitParagraph(s, keyword)
                return r
                
                
if __name__ == '__main__':
    s = """
    class DemoClass():
        def Func1():
            pass
    

    class DemoClass():
        def Func2():
            pass
    
        def Func1():
            return "Method Func1 of DemoClass in demo_2.py file."
    """
    r = ClassHandler.Class.String.GetInfo(s)
    print(r)