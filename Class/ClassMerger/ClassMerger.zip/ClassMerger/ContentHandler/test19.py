import pdb
if __name__ == '__main__':
    # append breakpoint to .pdbrc in current working directory
    # usage: bs lineno
    def bs(lineno):
        with open(".pdbrc", "a") as pdbrc:
            pdbrc.write("break " + __file__ +  ":%d\n" % (lineno))
            
    bs(15)
