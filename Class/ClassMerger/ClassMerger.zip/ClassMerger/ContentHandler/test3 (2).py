import re
words = {'thanks', 'cat', '""" """'}

samples = [
    (1, 'having fun at thanksgiving'),
    (2, 'cater the food'),
    (3, 'instead you can come'),
    (4, 'instead of you can come'),
    (5, 'instead of you can come """ """ '),
    (6, 'instead of you can come """ a """ '),
]

for id, description in samples:
    for word in words:
        if re.search(r'\b' + word + r'\b', description):
            print("'%s' in '%s" % (word, description))