class NestedFlatterInhomogenousWithOrder():
    """
    Intro :
        A function that flats a nested array-like object to 1D array-like object with order.
        For more details of returned value and returned type, see the following sections.
    Parameter :
        items : nested array-like object that be flatted.
    Returned Value:
        It returns an array-like object after flattening. 
    Returned Type:
        The type of returned value is same as type of input nested array-like object.
        i.e.
        1D list if input is nested list.
        1D tuple if input is nested tuple.
    NOTICE :
        NOTICE that 
        The input nested array-like object can be inhomogenous (i.e. with different shape.)
        (rather than NestedFlatter class in NestedFlatter.py file, which can only handle homogenous (i.e. with same shape) of nested array-like object.)
        For more details, see the following examples.
    Example : 
        Example 1 :
            ( (1,2,3) ,('a','b','c' ) )
        Example 2 :
            ( ( (1,2,3) ,('a','b','c' ) ) , ('q','w','e'))
    """
    @staticmethod
    def Flat(items : ( list | tuple ) , options : (dict|None)  = None ) -> ( list | tuple ) :
        result = NestedFlatterInhomogenousWithOrder.Flat_SubUtility(items)
        if isinstance(items, tuple) == True:
            result = tuple(result)
        return result
     
    @staticmethod
    def Flat_SubUtility(items : ( list | tuple ) , options : (dict|None)  = None ) -> ( list | tuple ) :
        temp = list()
        for i in range(0,len(items),1):
            item = items[i]
            if item != None:
                if isinstance(item, (tuple,list)) == True:
                    elem = NestedFlatterInhomogenousWithOrder.Flat_SubUtility(item)
                    temp = temp + elem
                elif item != None and ( options is None or not options.get("AppendMode") in (None,"NotNone") ) :
                    temp.append(item)
        return temp
    
    @staticmethod
    def PartiallyFlat_SubUtility(items : ( list | tuple ) , currDepth : int = 0 , maxDepth : int = 10000) -> ( list | tuple ) :
        if maxDepth <= 0 :
            raise Exception("Invalid max depth for searching (named as maxDepth).")
        if currDepth > maxDepth :
            raise Exception("It is not allowed to search the ith dimensional elem where ith depth is larger than or equal to maxDepth.")
        temp = list()
        for i in range(0,len(items),1):
            item = items[i]
            if item != None:
                if currDepth  == maxDepth :
                    temp.append(item)
                if isinstance(item, (tuple,list)) == True:
                    elem = NestedFlatterInhomogenousWithOrder.PartiallyFlat_SubUtility(item,currDepth + 1 , maxDepth)
                    if elem != None:
                        temp = elem + temp
                else:
                    temp.append(item)
        return temp
    
    @staticmethod
    def PartiallyFlat(items : ( list | tuple ) , maxDepth : int ) -> ( list | tuple ) :
        if maxDepth <= 0 :
            raise Exception("Invalid max depth for searching (named as maxDepth).")
        result = NestedFlatterInhomogenousWithOrder.PartiallyFlat_SubUtility(items,0 ,maxDepth)
        if isinstance(items, tuple) == True:
            result = tuple(result)
        return result
    
if __name__ == '__main__':
    items = [ (1,2,3) ,('a','b','c' ) ]
    r = NestedFlatterInhomogenousWithOrder.Flat(items)
    print(r)
    
    items = [ [1,2,3] ,('a','b','c' ) ]
    r = NestedFlatterInhomogenousWithOrder.Flat(items)
    print(r)
    
    items = [ [1,2,3] ,['a','b','c', ['z','x','c'] ] ]
    r = NestedFlatterInhomogenousWithOrder.Flat(items)
    print(r)

    
    items = [['DemoClass', '', ['Func1', [['', None]], 'pass\n    \n']], ['DemoClass', '', ['Func1', [['', None]], 'return "Method Func1 of DemoClass in demo_2.py file."']], ['DemoClass', '', ['Func1', [['', None]], 'return "Method Func1 of DemoClass in demo_2.py file."']]]
    r = NestedFlatterInhomogenousWithOrder.Flat(items)
    print(r)
    
    items = [['DemoClass', '', ['Func1', [['', None]], 'pass\n    \n']], ['DemoClass', '', ['Func1', [['', None]], 'return "Method Func1 of DemoClass in demo_2.py file."']], ['DemoClass', '', ['Func1', [['', None]], 'return "Method Func1 of DemoClass in demo_2.py file."']]]
    options = { "AppendMode" : "NotNone" }
    r = NestedFlatterInhomogenousWithOrder.Flat(items,options)
    print(r)
    