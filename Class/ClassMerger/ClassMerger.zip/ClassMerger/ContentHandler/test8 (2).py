from ElemsHandler import ElemsFinder

if __name__ == '__main__':
    methods = [
                ['DemoClass', '', 'Func1', '', 'pass\n    \n'], 
                ['DemoClass', '', 'Func1', '', 'return "Method Func1 of DemoClass in demo_2.py file."'], 
                ['DemoClass', '', 'Func2', '', 'return "Method Func1 of DemoClass in demo_2.py file."']
    ]
    indicesList = [[0, 1]]
    
    print("methods:")
    print(methods)
    
    keyIndices = [0,1,2,3]
    newMethods = list()
    for i in range(0,len(indicesList),1):
        l1 = list()
        if indicesList[i] == None or len(indicesList[i]) < 2 :
            raise Exception("Unknown issues.")
        
        for j in range(1,len(indicesList[i]),1):
            startIndex = indicesList[i][0]
            mergeIndex = indicesList[i][j]
            thisElems = ElemsFinder.GetOtherElem(methods[startIndex], keyIndices)
            otherElems = ElemsFinder.GetOtherElem(methods[mergeIndex], keyIndices)
            minLength = min(len(thisElems),len(otherElems))
            for k in range(0,minLength,1):
                if thisElems[k] == None or otherElems[k] == None :
                    raise Exception("Error!!! Either elem of thisElems otherElems is None.")
                l1.append(thisElems[k] + '\n' + otherElems[k] )
        if l1 != None and len(l1) > 0 :
            originalList = [ methods[startIndex][keyIndices[i]] for i in range(0,len(keyIndices),1)]
            newMethods.append(originalList + l1)
                    
    print("newMethods:")
    print(newMethods)