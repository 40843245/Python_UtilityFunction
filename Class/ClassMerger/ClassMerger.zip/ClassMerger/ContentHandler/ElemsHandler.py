from NestedFlatterInhomogenous import NestedFlatterInhomogenous
from ListHandler import ListHandler
from DictionaryHandler import DictionaryHandler

class ElemHandler():
    class Comparator():
        @staticmethod
        def Comp(l1:(list|tuple),l2:(list|tuple)) -> int:
            if l1 is None:
                raise Exception("Can not compare a NoneType Object.")
            if l2 is None:
                raise Exception("Can not compare a NoneType Object.")
            if len(l1) != len(l2):
                raise Exception("Can not compare two lists with different length.")
            for i in range(0,len(l1),1):
                if l1[i] < l2[i] :
                    return -1
                elif l1[i] > l2[i]:
                    return 1
            return 0
        @staticmethod
        def IsBetween(src1 : (list|tuple) ,target: (list|tuple) ,src2: (list|tuple) ) -> int : 
             isInvalid = ElemHandler.Comparator.Comp(src1, src2)
             if isInvalid in [0] :
                 raise Exception("src2 can not greater than or equal to src1.")
             range1 = ElemHandler.Comparator.Comp(target, src1)
             range2 = ElemHandler.Comparator.Comp(target, src2)
             if range1 in [-1] :
                 return -1
             if range2 in [1] :
                 return 1
             return 0
    class Sorter():
        @staticmethod
        def NestedSort(src:list) -> list :
            tar = list()
            tar = ElemHandler.Sorter.Sort(src)
            print(tar)
            
             
        @staticmethod
        def Sort(src:list) -> list :
            src.sort()
            return src
            
    class Filler():
        @staticmethod
        def DefaultValueToIndex(array:(list),defaultValue:int) -> (list):
            if array is None:
                raise Exception("Can not handle a NoneType object.")
            if not isinstance(array, (list)):
                raise Exception("Can not handle a non-list object.")
                
            array.sort()
            tempIndex = 0
            tempArray = t = list()
            headElem = [elem[0] for elem in array]
            minValue = min(headElem)
            maxValue = max(headElem)
            for arrayNo in range(minValue,maxValue+1,1):
                if not arrayNo in headElem:
                    t = [arrayNo,defaultValue]
                else:
                    rest = array[tempIndex][1:]
                    t = [arrayNo]
                    for i in range(0,len(rest),1):
                        t.append(rest[i])
                    tempIndex += 1
                tempArray.append(t)
            return tempArray
"""
A class that handles elems in list.
"""
class ElemsFinder():
    """
    Intro:
        Get all elems in list with indices not in keyIndices.
    Parameter:
        1. l: given list.
        2. keyIndices: a list of integers which indices in will be removed.
    Returned Value:
        A list after removal of l with given keyIndices.     
    """
    @staticmethod
    def GetOtherElem(l : list , keyIndices : list[int] ) -> list :
        if keyIndices is None:
            raise Exception("Invalid given indices.")
        r = [ l[i] for i in range(0,len(l),1) if not i in keyIndices]
        return r
    
    """
    Intro:
        Get all elems in list with indices in keyIndices.
    Parameter:
        1. l: given list.
        2. keyIndices: a list of integers which indices in will be removed.
    Returned Value:
        A list whose elem in l is not removed with given keyIndices.     
    """
    @staticmethod
    def GetTheseElem(l : list , keyIndices : list[int] ) -> list :
        if keyIndices is None:
            raise Exception("Invalid given indices.")
        r = [ l[i] for i in range(0,len(l),1) if i in keyIndices]
        return r
    
    """
    Intro:
        Get the difference of nested list (from l1 to l2).
        Similar to the result of l1 - l2.
    Parameter:
        1. l1: a list as source.
        2. l2: a list as target.
    Returned Value:
        Get the difference of nested list (from l1 to l2).
        See intro section.
    """
    @staticmethod
    def Diff(l1 : list , l2 : list) -> (list | None):
        if l1 is None:
            raise Exception("The list is empty.")
        if len(l1) <= 0 :
            return []
        if l2 is None:
            raise Exception("The list is empty.")
        if len(l2) <= 0 :
            return l1
        
        difference = list()
        for i in range(0,len(l1),1):
            if not l1[i] in l2 :
                difference.append(l1[i])
        return difference
                    
    """
    Intro:
        Get all indices where l[index] are matched more than 1 time for all index in indices.
        Here, we define elem1 and elem2 are matched iff
        elem1[i] == elem2[i] for i in keyIndices.
    Parameter:
        1. l: a list as source.
        2. keyIndices: a list. indicates indices.
    Returned Value:
        See intro section.
    """
    @staticmethod
    def IndicesOfSameKeys(l : list , keyIndices : list[int] ) -> ( (  list[int] | None ) , bool ):
        if l is None :
            raise Exception("Invalid indices of keys to filter out the given list.")
        if len(l) <= 0:
            return list()
        if keyIndices is None:
            raise Exception("Invalid indices of keys to filter out the given list.")
        if len(keyIndices) <= 0 :
            return l
        
        if len(keyIndices) > len(l[0][0]) :
            raise Exception("Invalid indices of keys to filter out the given list.")

        if len(keyIndices) == len(l[0][0]) :
            return l      
        
        indiceList = list()
        indiceList_t1 = list()
        flag = True
        
        for i in range(0,len(l),1):
            currL = l[i]      
            indiceList_t1 = list()
            if any([elem for elem in indiceList if i in elem]) != True:
                for j in range(i+1,len(l),1):
                    compL = l[j]
                    if any([elem for elem in indiceList if j in elem]) != True:
                        flag = True
                        for k in range(0,len(keyIndices),1):
                            if currL[k] != compL[k]:
                                flag = False
                                break
                        if flag == True:
                            indiceList_t1.append(j)
            if indiceList_t1 != None and len(indiceList_t1) > 0 :
                indiceList.append( [i] + indiceList_t1 )
        isNonEmpty = not indiceList is None and len(indiceList) > 0 
        return ( indiceList , isNonEmpty )
    
    """
    Intro:
        Get all value corresponding to indices where l[index] are matched more than 1 time for all index in indices.
        Here, we define elem1 and elem2 are matched iff
        elem1[i] == elem2[i] for i in keyIndices.
        For more details, see ElemsFinder.IndicesOfSameKeys() method.
    Parameter:
        1. l: a list as source.
        2. keyIndices: a list. indicates indices.
    Returned Value:
        See intro section.
    """
    @staticmethod
    def NestedValuesOfSameKeys(l : list , keyIndices : list[int] ) -> ( ( list[int] | None ) , bool ):
        if keyIndices is None :
            raise Exception("The indices are None.")
            
        if len(keyIndices) <= 0 :
            return l
        
        if l is None:
            raise Exception("The input list are None.")
        
        if len(l) <= 0 :
            return list()
            
        keysForCheck = list()
        for i in range(0,len(keyIndices),1):
            if not isinstance(keyIndices[i], (list,tuple) ) :
                keysForCheck.append(keyIndices[i])
        
        sameKeys = keyIndices 
        
        if not keysForCheck is None and len(keysForCheck) > 0 :
            ( sameKeys , isNonEmpty ) = ElemsFinder.IndicesOfSameKeys(l, keysForCheck)
            if isNonEmpty == False:
                return ( sameKeys , isNonEmpty ) 
        
        differentKeys = ElemsFinder.Diff(keyIndices, keysForCheck)

        sameItems = list()
        for i in range(0,len(sameKeys),1):
            for j in range(0,len(sameKeys[i]),1):
                elem = l[sameKeys[i][j]]        
                sameItems.append(elem)
        
        if differentKeys is None or len(differentKeys) <= 0:
            isNonEmpty = not sameItems is None and len(sameItems) > 0 
            return ( sameItems , isNonEmpty )
        differentKeys = NestedFlatterInhomogenous.PartiallyFlat(differentKeys,1)
        return ElemsFinder.NestedValuesOfSameKeys(sameItems, differentKeys)
    
    """
    Intro:
        Get the index of specified target (named tar) in given list (named src) with arg options as options.
        For more details, see ElemsFinder.IndicesOfSameKeys() method.
    Parameter:
        1. src: source. Must be a tuple or a list.
        2. tar: target that will be found. It must be one of these:
            'nonarray'
            'array'
            'nonarray' refers that it will search for a non-tuple or non-list object
                (such as int, str, bool etc). At this case, it must be a non-tuple or non-list object.
            'array' refers that it will search for a tuple or list object. 
                At this case, it must be a tuple or list object.
                
    Returned Value:
        returns index.
        0 indicates that the target is found at leftmost and so on.
        -1 indicates that target is NOT found.
    NOTICE:
        NOTICE that in this edition, it does NOT support for dictionary:
            1. dict type (or elem with dict type) in arg target.
            2. dict type (or elem with dict type) in arg src.
            
    """
    
    @staticmethod
    def GetElemIndex( src : list , tar , options : (dict | None)) -> ( int | None ) :
        if src is None:
            raise Exception("Can not find an item from a NoneType object.")
        if tar is None:
            raise Exception("Can not find an item for a NoneType object.")
        if not isinstance(src, (tuple|list)) :
            raise Exception("Can not find an item from a non-list or non-tuple object.")
         
        defaultOptions = { 
            "targetType": "nonarray",
            "includingEmpty" : False,
        }
        
        options = DictionaryHandler.Dict.Operation.DefaultDict(options, defaultOptions)
        if not options.get("targetType") in ( "nonarray"" , array" ) :
            raise Exception("Invalid value of key 'targetType' in arg (named options).\n"+
                            "It must one of these:\n\t'nonarray'\n\t'array'\n")
        
        if options.get("targetType") == "nonarray":
            if isinstance(tar, (list|tuple) ) :
                raise Exception("Invalid arg (named tar).\n"+
                                "It is not allowed to specify a list or a tuple while the value of key 'targetType' in arg (named options) is 'nonarray'.")
            return ElemsFinder.GetIndex(src, tar, options)
        elif options.get("targetType") == "array":
            if not isinstance(tar, (tuple|list)):
                raise Exception("Invalid arg (named tar).\n"+
                            "It is not allowed to specify niether a list nor a tuple while the value of key 'targetType' in arg (named options) is 'array'.")
            for i in range(0,len(src),1):
                items = [src[i]]
                if not isinstance(items,(tuple|list)):
                    raise Exception("Unknown issues.")
                if not ( options.get("includingEmpty") == False and len(items) <= 0):
                    if items == tar:
                        return i
                    index = ElemsFinder.GetIndex(items, tar, options)
                    if index != -1:
                        return i
            return -1

    @staticmethod
    def GetIndex( src : list , tar , options : (dict | None)) -> ( int | None ) :
        if src is None:
            raise Exception("Can not find an item from a NoneType object.")
        if tar is None:
            raise Exception("Can not find an item for a NoneType object.")
        if not isinstance(src, (tuple|list)) :
            raise Exception("Can not find an item from a non-list or non-tuple object.")
        
        defaultOptions = { 
            "targetType": "nonarray",
            "includingEmpty" : False,
        }
        
        options = DictionaryHandler.Dict.Operation.DefaultDict(options, defaultOptions)
        
        
        if not options.get("targetType") in ( "nonarray"" , array" ) :
            raise Exception("Invalid value of key 'targetType' in arg (named options).\n"+
                            "It must one of these:\n\t'nonarray'\n\t'array'\n")
            
        if options.get("targetType") == "nonarray":
            if isinstance(tar, (list|tuple) ) :
                raise Exception("Invalid arg (named tar).\n"+
                                "It is not allowed to specify a list or a tuple while the value of key 'targetType' in arg (named options) is 'nonarray'.")
                
            flattenedList = NestedFlatterInhomogenous.Flat(src)
            if flattenedList is None:
                raise Exception("Invalid result after flattening the tuple or list (named src).")
                
            index = -1
            for i in range(0,len(flattenedList),1):
                item = flattenedList[i]
                if item is None:
                    raise Exception("Invalid item (NoneType item) in the flattened array.")
                if isinstance(item, (dict)):
                    raise Exception("Invalid item (item with dict type, or containing an item with dict type(or its subitem does so) in the flattened array.")
                if isinstance(item, (tuple|list)):
                    index = ElemsFinder.GetIndex(item, tar) 
                    if index != -1:
                       return index
                else:
                    if item == tar:
                        return i
            return -1
        elif options.get("targetType") == "array":
            if not isinstance(tar, (tuple|list)):
                raise Exception("Invalid arg (named tar).\n"+
                            "It is not allowed to specify niether a list nor a tuple while the value of key 'targetType' in arg (named options) is 'array'.")

            srcMaxDepth = ListHandler.Depth.MaxDepth(src)
            tarMaxDepth = ListHandler.Depth.MaxDepth(tar)
            diffMaxDepth = srcMaxDepth - tarMaxDepth
            if diffMaxDepth - 1 < 0:
                return -1
            else:
                flattenedList = NestedFlatterInhomogenous.PartiallyFlat(src, diffMaxDepth - 1)
            if flattenedList is None:
                raise Exception("Invalid result after flattening the tuple or list (named src).")
                
            for i in range(0,len(flattenedList),1):
                item = flattenedList[i]
                if item is None:
                    raise Exception("Invalid item (NoneType item) in the flattened array.")
                if not ( options.get("includingEmpty") == False and len(item) <= 0):
                    if item == tar:
                        return i
            return -1
            

"""
Driver code to test.
"""
if __name__ == '__main__':
    testDatas = [ 
        [ [1,2,3],[2,3,4] , [3,4,5] ] ,
        [ [1,2,3],[1,2,4] , [3,4,5] ] ,
        [ [1,2,3],[1,2,2] , [3,4,5] ] ,
        [ [1,2,3],[1,2,3] , [3,4,5] ] ,
        [ (7,17) ,(7,20) , (7,44) ] ,
        [ (7,47) ,(7,20) , (7,44) ] ,
        [ (1,0) ,(0,0) , (1,24) ] ,
        [ (1,0) ,(0,98) , (1,24) ] ,
        [ (2,24) ,(1,28) , (1,26) ] ,
        [ (2,27) ,(3,28) , (2,28) ] ,
        [   
            [[0, 0], [0, 98], [15, 0], [15, 27], [18, 4], [18, 95]],
            [[21, 0], [21, 27], [24, 4], [24, 30], [1, 0], [1, 24], [2, 0], [3, 0], [5, 8], [5, 32], [7, 20], [7, 44], [13, 0], [17, 0], [18, 28], [18, 92], [19, 0], [24, 0]],
            [[5, 36], [5, 60], [7, 17], [7, 47]],
        ]
    ]
    defaultValue = 10
    target = [7,17]
    options = { 
            "targetType": "array",
    }
    for ith in range(0,len(testDatas),1):
        testData = testDatas[ith]
        l1 = testData[0]
        l2 = testData[1]
        l3 = testData[2]
        
        print('-'*40)
        print("%dth test data:" %(ith))
        print("With partially search method (invoke the method with value of targetType 'nonarray' in the dict (named options),\nThe elem 2 is found at index %d from left to right (returns 0 indicates that items found at leftmost, and so on, returns -1 indicates that not found)." %( ElemsFinder.GetIndex(testData, 2,None ) ) )
        print("With fully search method (invoke the method with value of targetType 'array' in the dict (named options),\nThe elem %s is found at index %d from left to right (returns 0 indicates that items found at leftmost, and so on, returns -1 indicates that not found)." %( str(target),ElemsFinder.GetIndex(testData, target,options) ) )
        print("With fully search method (invoke the method with value of targetType 'array' in the dict (named options),\nThe elem %s is found at index %d from left to right (returns 0 indicates that items found at leftmost, and so on, returns -1 indicates that not found)." %( str(target),ElemsFinder.GetElemIndex(testData, target,options) ) )

        if ith == 10:
            
            print('*'*40)
            print("After filling the default value %d to the array %s, it becomes %s" %( defaultValue , str(l1),str(ElemHandler.Filler.DefaultValueToIndex(l1, defaultValue) ) ) )
            print('*'*40)
        print('-'*40)