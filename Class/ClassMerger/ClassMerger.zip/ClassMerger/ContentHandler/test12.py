import os
from decouple import config
if __name__ == '__main__':
    print('os.environ:')    
    print(os.environ)
    #print('os.environ.data:')
    #print(os.environ.data)
    #v = os.getenv('PYTHONHOME')
    #v = os.getenv('PATH')
    #os.environ['PYTHONBREAKPOINT'] = '4'
    v = os.getenv('PYTHONBREAKPOINT')
    print(v)
    v = config('PYTHONBREAKPOINT')
    print(v)
    
    os.environ.putenv('PYTHONBREAKPOINT','2')
    
    v = os.getenv('PYTHONBREAKPOINT')
    print(v)
    v = config('PYTHONBREAKPOINT')
    print(v)