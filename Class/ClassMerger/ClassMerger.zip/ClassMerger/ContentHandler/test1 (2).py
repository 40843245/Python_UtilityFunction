import inspect
class Class1():
    """
    Hello
    """
    # class
    @staticmethod
    def Func1():
        """
        Shit
        """
        return "Func1"
if __name__ == '__main__':
    r = inspect.getdoc(Class1())
    print('-'*40)
    print(r)
    
    r = inspect.getdoc(Class1.Func1())
    print('-'*40)
    print(r)
    
    