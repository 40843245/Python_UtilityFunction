from ElemsHandler import ElemsFinder
if __name__ == '__main__':
    items = [
                ['DemoClass', '', ['Func1', [['', None]], 'pass\n    \n']], 
                ['DemoClass', '', ['Func1', [['', None]], 'return "Method Func1 of DemoClass in demo_2.py file."']], 
                ['DemoClass', '', ['Func1', [['', None]], 'return "Method Func1 of DemoClass in demo_2.py file."']]
            ]
    keyIndices = [0,1,[0,1]]
    r = ElemsFinder.NestedValuesOfSameKeys(items, keyIndices)
    print("r:")
    print(r)