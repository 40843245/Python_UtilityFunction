import pdb
import os
def debugger(msg):
    print(msg)
    return "msg:" + str(msg) 


if __name__ == '__main__':
    msg = "Hello!!!"
    myPdb =  pdb.Pdb(completekey = 'y')
    myPdb.set_trace()

    