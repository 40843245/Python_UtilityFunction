from DictionaryHandler import DictionaryHandler

class ListHandler():
    """
    Intro:
        A class that handles about depth in a given list or tuple.
    """    
    class Depth():
        """
        Intro:
            Get the max depth of given items.
        Parameter:
            1. items: items. It should be a list or a tuple. Otherwise, an exception will be thrown.
        Returned Value:
            returns True iff all items are in length. Otherwise, returns False.
        """
        @staticmethod
        def MaxDepth(items : (list,tuple) , options : (dict|None) = None) -> int :
            if items is None:
                raise Exception("Can not get max depth for a NoneType object.")
            if not isinstance(items, (list|tuple)):
                raise Exception("Can not get max depth for a non-tuple and non-list object.\nIt can be used for a tuple or a list.")
            if len(items) <= 0 :
                return 0
            defaultOptions = { 
                "includingNone" : True,
            }
            options = DictionaryHandler.Dict.Operation.DefaultDict(options, defaultOptions)
            depth = maxDepth = 0
            for i in range(0,len(items),1):
                item = items[i]
                if not(options.get("includingNone") == False and item is None):
                    if isinstance(item, (list|tuple)) == True:
                        depth = ListHandler.Depth.MaxDepth(item)
                        if depth > maxDepth:
                            maxDepth = depth
            return maxDepth + 1
    
    """
    Intro:
        A class that handles about length in each elem in a given list or tuple.
    """
    class Length():
        """
        Intro:
            Check all elem in items (named items) are in length (named length).
        Parameter:
            1. items: items. It should be a list or a tuple. Otherwise, an exception will be thrown.
            2. length: length. It should be an positive integer. Otherwise, an exception will be thrown.
        Returned Value:
            returns True iff all items are in length. Otherwise, returns False.
        """
        @staticmethod
        def SameLength( items : (list,tuple) , length : int ) -> bool :
            if items is None:
                raise Exception("Invalid value of arg length.")
            if not isinstance(items, (list,tuple)):
                raise Exception("Invalid value of arg items.")
            if length is None:
                raise Exception("Invalid value of arg length.")
            if not isinstance(length, (int)):
                raise Exception("Invalid value of arg length.")
            if length <= 0:
                raise Exception("Invalid value of arg length.")
                
            r = all([ True if len(elem) == length else False for elem in items ]) 
            return r           

if __name__ == '__main__':
    testDatas = [
        [[1,1],[2,2],[3,3]], 
        [[1,2],[3,2,4],[3,3]], 
        [[1,1],[[2,3,2],2,3],[3,3]], 
        [[1],2],
        [(1,),2],
    ]
    for ith in range(0,len(testDatas),1):
        testData = testDatas[ith]
        r = ListHandler.Depth.MaxDepth(testData)
        
        print('-'*40)
        print("%dith test data:" %(ith))
        print("The max depth of %s:%d." %(str(testData),r) )
        print('-'*40)
        
        
    