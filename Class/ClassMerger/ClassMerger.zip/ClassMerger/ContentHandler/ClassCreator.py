import types
import inspect
from enum import Enum
import dill

from CommentsHandler import CommentsHandler
from StringHandler2 import StringHandler
from REHandler import REHandler

class RecursiveModeEnum(Enum):
    VISIT_DEPTH_1  = 1 ** 2 - 1
    NONRECURSIVE_ALL = 2 ** 2 - 1
    
class ConditionMode():
    funcFilterMap = {
        'OWNDEFINED_MEMBER' :  lambda x : not x.startswith('__') ,
        'BUILTIN_MEMBER' :  lambda x : x.startswith('__')  ,
        'ALL_MEMBER' :  lambda x : True  ,
    }
        
class ClassAccesser():
    """
        A class to inspect a class.
    """
    class Inspector():
        """
            Intro:
                   A method that the notation of obj.
            Parameter:
                   obj: target. It can be an object, function, class, or method etc in class.
                       For more details, see the docs of dill.source.getsource method.
            Returned Value:
                   Returns a string. Indicates the notation of obj.
        """ 
        @staticmethod
        def GetNotations(qualname:str) ->str:
            classObj = ClassAccesser.Inspect.GetClassByQualifiedName(qualname)
            return inspect.get_annotations(classObj)
        """
            Intro:
                   A method that the symbols of obj.
                   For more details, see Examples section.
            Parameter:
                   obj: target. It can be an object, function, class, or method etc in class.
                       For more details, see the docs of dill.source.getsource method.
            Returned Value:
                   Returns a string. Indicates the symbols of obj.
            Examples:
                Example 1:
                    Input:
                        @staticmethod
                        def GetSymbols(qualname:str) ->str:
                    Output:
                        @staticmethod
        """ 
        @staticmethod
        def GetSugarSymbols(qualname:str) ->str:
            sourceCode = ClassAccesser.Source.GetSource(qualname)
            if sourceCode is None: 
                return None
            if len(sourceCode) <= 0 :
                return None
            
            whitespace = ' '
            tab = '\t'
            newLine = '\n'
            wtn = whitespace + tab + newLine
            
            sugarTextList = list()
            
            sourceCode = CommentsHandler.Comment.String.Operation.Remove.RemoveComment(sourceCode)
            
            newText = sourceCode[:]
            newText = newText.lstrip(wtn)
            dummy = None
            while len(newText) > 0 :
                startsWithSugar = newText[0] in ['@']
                if startsWithSugar == False:
                    break
                firstWord = REHandler.FirstWord(newText)
                firstSugarText = '@' + firstWord
                sugarTextList.append(firstSugarText)
                newText = newText.removeprefix(firstSugarText)
                newText = newText.lstrip(wtn)
                dummy = None
            return sugarTextList 
            
            
        """
            Intro:
                   A method that get class by given name (named className)
                   For more details, see NOTICE section.
            Parameter:
                   className: name of class.
            Returned Value:
                   Returns a string. Indicates the reference to class corresponding to className.
        """ 
        @staticmethod
        def GetClassByQualifiedName(qualname:str):
            if qualname is None:
                raise Exception("The paths must not be a NoneType object.")
            if isinstance(qualname, (str)):
                paths = ClassAccesser.Relatives.Ancestor.GetQualifiedPath(qualname)
                rootClass = ClassAccesser.Relatives.Ancestor.GetRoot(qualname)
                nonfirstPaths = paths[1:]
                if rootClass.__name__ == qualname:
                    return rootClass
                return ClassAccesser.Relatives.Descendant.GetDescendant(rootClass, nonfirstPaths)
            else:
                return qualname
        

    """
        A class to get source of a class.
    """    
    class Source():
        """
            Intro:
                   A method that the source info of obj.
                   For more details, see NOTICE section.
            Parameter:
                   obj: target. It can be an object, function, class, or method etc in class.
                       For more details, see the docs of dill.source.getsource method.
            Returned Value:
                   Returns a string. Indicates the source info of obj.
        """ 
        @staticmethod
        def GetSource(className) ->str:
            return dill.source.getsource(className)
        

    """
        A class to handles relatives of obj.
    """
    class Relatives():
        """
          A class to handles descendant or children of obj.
        """
        class Descendant():
            """
                Intro:
                    A method that get all children (directly children) of obj.
                    For more details, see NOTICE section.
                Parameter:
                    obj: target. It can be an object, function, class, or method in class.
                    searchMode: mode to search for. It must be a string with one of these in list(ConditionMode.funcFilterMap.keys())
                                It is not in or it is None, it uses the default value 'OWNDEFINED_MEMBER'.
                                list(ConditionMode.funcFilterMap.keys()) is ["OWNDEFINED_MEMBER","BUILTIN_MEMBER","ALL_MEMBER"]
                                "OWNDEFINED_MEMBER" refers it will only return for children which is user-defined.
                                "BUILTIN_MEMBER" refers it will only return for children which is builtin.
                                "ALL_MEMBER" refers it will return all children.
                Returned Value:
                    Returns a list. Indicates all references for all children.
                NOTICE:
                    NOTICE it returns an empty list when there are no any directly children.
            """            
            @staticmethod
            def GetChildren(obj , searchMode : ( str | None) = None ) -> list:
                if searchMode is None:
                    searchMode = 'OWNDEFINED_MEMBER'
                if not searchMode in list(ConditionMode.funcFilterMap.keys()):
                    searchMode = 'OWNDEFINED_MEMBER'
                    
                conditions = ConditionMode.funcFilterMap.get(searchMode)
                childrenName = [func for func in dir(obj) if callable(getattr(obj, func)) and conditions(func)]
                members = inspect.getmembers(obj)
                childrenClass = list()
                for member in members:
                    if member[0] in childrenName:
                        childrenClass.append(member)
                return childrenClass
            """
                Intro:
                    A method that get all descendants of obj.
                    For more details, see NOTICE section.
                Parameter:
                    obj: target. It can be an object, function, class, or method in class.
                    searchMode: mode to search for. For more details, see the doc of GetChildren method.
                Returned Value:
                    Returns a dict. It contains all descendant.
                    Key of item indicates class of the item, while values of elems indicates children of the item.
                    When the item has no children, it contains a tuple (itemName,itemObj) 
                    where 
                    itemName refers the name (not fully qualified name ) of item and 
                    itemObj refers the references to the item.
                NOTICE:
                    NOTICE it returns an empty dict when there are no any descendants.
            """
            @staticmethod
            def GetDescendants(obj,searchMode : (str | None) = None  )  -> list:
                if searchMode is None:
                    searchMode = 'OWNDEFINED_MEMBER'
                if not searchMode in list(ConditionMode.funcFilterMap.keys()):
                    searchMode = 'OWNDEFINED_MEMBER'
                children = ClassAccesser.Relatives.Descendant.GetChildren(obj,searchMode=searchMode)
                childrenClasses = [elem[1] for elem in children]
                newDict = dict()
                prevD = None
                d = dict() 
                
                stacks = childrenClasses[:]
                while len(stacks) > 0 :
                    lastElem = stacks[-1]
                    tempChildren = ClassAccesser.Relatives.Descendant.GetChildren(lastElem,searchMode=searchMode)
                    tempClasses = [elem[1] for elem in tempChildren]
                    if not tempClasses is None and len(tempClasses) > 0 :
                        prevD = d       
                        d.clear()
                        d.update( {
                                lastElem : tempChildren[:] , 
                            }
                        )
                        newDict.update({
                                list(prevD.keys())[0] : d ,
                            }
                        )
                    del stacks[-1]
                return newDict

            """
                Intro:
                    A method that the speficied child of obj.
                Parameter:
                   obj: src. It can be an object, function, class, or method etc in class.
                   name: name of target to be found for.
                Returned Value:
                   Returns a object.
            """             
            @staticmethod
            def GetChild(obj,name:str):
                if name is None:
                    raise Exception("The name must not be a NoneType object.")
                if not isinstance(name, (str)):
                    raise Exception("The paths must be a string.")
                    
                members = inspect.getmembers(obj)
                for member in members:
                    if member[0] == name:
                        return member[1]
                return None
            
            """
                    Intro:
                        A method that the speficied descendant of obj.
                    Parameter:
                       obj: src. It can be an object, function, class, or method etc in class.
                       paths: a list of path name to be found for.
                   Returned Value:
                       Returns a object.
            """  
            @staticmethod
            def GetDescendant(obj,paths:list):
                if paths is None:
                    raise Exception("The paths must not be a NoneType object.")
                if not isinstance(paths, (list)):
                    raise Exception("The paths must be a list.")
                
                tar = obj
                while len(paths) > 0 :
                    firstElem = paths[0]
                    member = ClassAccesser.Relatives.Descendant.GetChild(tar,firstElem)
                    if member is None:
                        return None
                    tar = member 
                    del paths[0]
                return tar
        """
            A class to handles ancestor or parent of obj.
        """
        class Ancestor():            
            """
                    Intro:
                        A method that split given qualified name into paths by delimiter - dot (i.e. '.')
                    Parameter:
                       obj: src. It can be an object, function, class, or method etc in class.
                   Returned Value:
                       Returns a list. Indicates a path.
            """             
            @staticmethod
            def GetQualifiedPath(obj:(str|object))->list:
                if obj is None:
                    raise Exception("The paths must not be a NoneType object.") 
                if isinstance(obj, (str)) == True:
                    qualname = obj
                else:
                    qualname = obj.__qualname__
                paths = qualname.split('.')
                return paths
            """
                Intro:
                    A method that get root of obj. 
                    (i.e. find top-level object, or class that defined either object or class where obj is instantiated to.)
                    For more details, see NOTICE section.
                Parameter:
                    obj: target to be searched.
                Returned Value:
                    Returns the root of obj.
                NOTICE:
                    NOTICE it returns None when it has no root. (such as on top-level)
            """
            @staticmethod
            def GetRoot(obj) :
                paths = ClassAccesser.Relatives.Ancestor.GetQualifiedPath(obj)
                rootClassName = paths[0]
                rootClass = globals()[rootClassName]
                return rootClass
            """
                Intro:
                    A method that get the parent of obj.
                    For more details, see NOTICE section.
                Parameter:
                    obj: target.
                Returned Value:
                    Returns the parent of obj.
                NOTICE:
                    NOTICE it returns None when it has no parent. (such as on top-level)
            """
            @staticmethod
            def GetParent(obj):
                paths = ClassAccesser.Relatives.Ancestor.GetQualifiedPath(obj)
                rootClass = ClassAccesser.Relatives.Ancestor.GetRoot(obj)
                nonfirstPaths = paths[1:-1]
                
                children = ClassAccesser.Relatives.Descendant.GetChildren(rootClass)
                
                # The rootClass is the directly parent of obj.
                if children is None or len(children) <= 0 :
                    return rootClass
                # Otherwise. (i.e. The rootClass is the directly parent of obj.)
                return ClassAccesser.Relatives.Descendant.GetDescendant(rootClass, nonfirstPaths)
            
        
"""
     A class that handles a class.
"""
class ClassCreator(object):
    """
        Intro:
            Create a new class named className.
        Parameter:
            className: name of class that is instantiated.
        Returned Value:
            Returns self.classObj. Refers the new class that is instantiated just now.
    """
    def Create(self,className:str) -> None:
        self.classObj = types.new_class(className)      
        return self.classObj
    """
        Intro:
            Add the method to the class.
        Parameter:
            methodName: name of method.
            methodContent: main body of method. 
            argvsName: a list containing name of arguments.
            argvsValue: a list containing value of arguments corresponding to argvsName.
        Returned Value:
            Returns self.classObj. Refers the class just after changed.
    """
    def AddMethod(self,methodName:str,methodContent:str,argvsName:list,argvsValue:list) -> None:
        funcMethod = ClassCreator.Method.CreateMethod(methodName, argvsName, argvsValue, methodContent)
        setattr(self.classObj, methodName, funcMethod)
        return self.classObj
    """
        Intro:
            Add the attribute to the class.
        Parameter:
            attrName: name of attribute.
            attrValue: value of attribute corresponding to attrName.
        Returned Value:
            Returns self.classObj. Refers the class just after changed.
    """
    def AddAttr(self,attrName:str,attrValue:str)->None:
        setattr(self.classObj,attrName,attrValue)
        return self.classObj
    """
        Intro:
            Add the document to the class.
        Parameter:
            doc: body of document.
        Returned Value:
            Returns self.classObj. Refers the class just after changed.
    """
    def AddDoc(self,doc:str) -> None:
        self.classObj.__doc__ = doc
        return self.classObj
    """
        A class that handles methods in class.
    """
    class Method():  
        """
            Intro:
                A subutility method to combine them to define a function for use of ClassCreator.AddMethod method.
            Parameter:
                methodName: function name.
                argvsName: name of arguments.
                argvsValue: values of arguments.
                methodContent: body of function.
            Returned Value:
                Returns a string.
        """
        @staticmethod
        def CreateMethod(methodName : str, argvsName : list , argvsValue : list , methodContent : str) -> None:
             def Func1():
                 pass
             argvsName_s = ','.join(argvsName)
             argvsValue_s = ','.join(argvsValue)           
             funcTemplate = "def "+ methodName + "("+argvsName_s+"): "+ methodContent 
             return funcTemplate
         
        """
             Intro:
                 A subutility method to combine them to define a function and invocation of the function for use of ClassCreator.AddMethod method.
             Parameter:
                 methodName: function name.
                 argvsName: name of arguments.
                 argvsValue: values of arguments.
                 methodContent: body of function.
             Returned Value:
                 Returns a string.
             NOTICE:
                 It uses ClassCreator.Method.CreateMethod method.
        """
        @staticmethod
        def CreateCmd(methodName:str,argvsName:list,argvsValue:list,methodContent:str):
            argvs = [ argvsName[i]+'='+argvsValue[i] for i in range(0,len(argvsName),1)]
            argvs_s = ','.join(argvs)  
            funcTemplate = ClassCreator.Method.CreateMethod(methodName, argvsName, argvsValue, methodContent)
            funcCmd = funcTemplate + "\n"+ methodName + "("+argvs_s+")" 
            return funcCmd
        """
             Intro:
                 A subutility method exec the command with given string.
             Parameter:
                 methodName: function name.
                 argvsName: name of arguments.
                 argvsValue: values of arguments.
                 methodContent: body of function.
             Returned Value:
                 Returns None.
             NOTICE:
                 It uses ClassCreator.Method.CreateCmd method.
        """
        @staticmethod
        def Exec(methodName:str,argvsName:list,argvsValue:list,methodContent:str):
            funcCmd = ClassCreator.Method.CreateCmd(methodName, argvsName, argvsValue, methodContent)
            exec(funcCmd)
            
"""
Driver code
"""
if __name__ == '__main__':
    className = "DemoClass"
    attrName = "AttrName"
    attrValue = "AttrValue"
    methodName = "MethodName"
    argvsName = ['argv1','argv2','argv3','sep']
    argvsValue = ['20','40','60','\',\'']
    methodContent = "print(argv1,argv2,argv3,sep=sep)"
    doc = """A simple class."""
    classCreator = ClassCreator()
    classObj = classCreator.Create(className)
    classObj = classCreator.AddMethod(methodName, methodContent, argvsName, argvsValue)
    classObj = classCreator.AddAttr(attrName, attrValue)
    classObj = classCreator.AddDoc(doc)
    
    obj = ClassAccesser.Relatives.Ancestor.GetQualifiedPath
    qualname = "ClassAccesser.Relatives.Ancestor.GetQualifiedPath"

    #ClassAccesser.Relatives.Ancestor.GetQualifiedPath = staticmethod(ClassAccesser.Relatives.Ancestor.GetQualifiedPath)
    
    r = ClassAccesser.Inspector.GetSugarSymbols(obj)
    print("r:")
    print(r)
    """
    r = ClassAccesser.Relatives.Ancestor.GetParent(obj)
    print("r:")
    print(r)
    """
    
    