import io
import tokenize

def separate_code_from_comments(text):
    reader = io.StringIO(text).readline
    comment_tokens = (t for t in tokenize.generate_tokens(reader) if t.type == tokenize.COMMENT)
    comment = next(comment_tokens, None)
    print(comment.start if comment else None)
    print(type(comment.start) if comment else None)
    return [text[0: comment.start[1]], text[comment.start[1]:]] if comment else [text, '']


testDatas = [
    """\
print('hello') # this is a comment # 2th comment.
""",
"""\
# this is a comment
""",
"""\
loc_2 = for char in \"(*#& eht #\": # pylint: disable=one,two # something
""",
"""\
loc_2 = for char in \"(*#& eht #\": 
""",
]

for i in range(0,len(testDatas),1):
    testData = testDatas[i] 
    r = separate_code_from_comments(testData)
    print("r:")
    print(r)
    