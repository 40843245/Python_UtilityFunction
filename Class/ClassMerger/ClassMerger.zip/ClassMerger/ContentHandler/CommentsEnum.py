from NestedFlatterInhomogenous import NestedFlatterInhomogenous
from enum import Enum

class SingleLine(Enum):
    SINGLE_LINE = '#'
    
class MultiLine(Enum):
    SINGLE_QOUTATION = "'''"
    DOUBLE_QOUTATION = '"""'
    
class CommentsEnum():
    def __init__(self):
        enums = list()
        
        self.singlelineEnum = [elem.value for elem in SingleLine ]
        self.multilineEnum = [elem.value for elem in MultiLine ]
        
        enums.append( self.singlelineEnum )
        enums.append( self.multilineEnum )
        
        self.enums = NestedFlatterInhomogenous.Flat(enums)

        
if __name__ == '__main__':
    commentsEnum = CommentsEnum()
    r = commentsEnum.multilineEnum
    print(r)
    
        
        
    
    