class DictionaryHandler():
    class Dict():
        class Operation():
            @staticmethod
            def DefaultDict(originalDict : (dict|None) , defaultDict : (dict|None)) -> dict :
                if originalDict is None and defaultDict is None:
                    raise Exception("Can not set the dict to default dict.")
                if originalDict is None:
                    originalDict = defaultDict
                else :
                    originalDictKeys = list(originalDict.keys())
                    defaultDictItems = list(defaultDict.items())
                    for (k,v) in defaultDictItems:
                        if not k in originalDictKeys:
                            originalDict.update( { k : v } )
                return originalDict
            
    class List():
        class Sort():
            @staticmethod
            def Sort(indentation:dict,keyword:str):
                def Sort1(l : list, keyword : str) -> list :
                    currIndex = 0
                    startPosList_t1 = list()
                    orderedList = list()
                    for i in range(0,len(l[0]),1):
                        elem = l[0][i]                       
                        valuesList = list(elem.values())
                        for j in range(0,len(valuesList),1):
                            values = valuesList[j]
                            currStartPos = values.get(keyword)
                            if currStartPos != None:
                                if isinstance(currStartPos, int) == False:
                                    raise Exception("Error")
                                if len(startPosList_t1) > 0 :
                                    flag = False
                                    currValue = -1
                                    nextValue = startPosList_t1[0]
                                    for index in range(0,len(startPosList_t1)-1,1):
                                        currValue = startPosList_t1[index]
                                        nextValue = startPosList_t1[index + 1]
                                        if  currValue < currStartPos and \
                                            currStartPos < nextValue :
                                               currIndex = index + 1
                                               flag = True                       
                                               break                                       
                                    if flag == False:
                                        if currStartPos < startPosList_t1[0] :
                                            currIndex = 0
                                        else :
                                            currIndex = len(startPosList_t1) 
                                orderedList.insert(currIndex , values)
                                startPosList_t1.insert(currIndex  , currStartPos)
                    return (orderedList, startPosList_t1)
                
                orderedObj = list()
                orderedPos = list()
                lineNos = list()
                
                for i in range(0,len(indentation),1):
                    
                    keys = list(indentation[i].keys())
                    if keys == None or len(keys) != 1:
                        raise Exception("Too less or more keys in the dict (which should contain exactly 1 key.)")
                    lineNo = keys[0]
                    l = list(indentation[i].values())
                    ( e , sp ) = Sort1(l,keyword)
                    lineNos.append(lineNo)
                    orderedObj.append(e)
                    orderedPos.append(sp)
                return ( lineNos , orderedObj,orderedPos)
if __name__ == '__main__':
    testDatas = [
                    {1: 'singleLineComment' }, 
                    {2: 'singleLineComment' }, 
                    {3: 'singleLineComment' }, 
                    {4: 'singleLineComment' }, 
                    {5: 'singleLineComment' }, 
                    {6: 'singleLineComment' }, 
                    
                ]
    defaultDict = {6: 'x' } 

    
    for ith in range(0,len(testDatas),1):
        testData = testDatas[ith]
        originalDict = testData
        r = DictionaryHandler.Dict.Operation.DefaultDict(originalDict, defaultDict)
        
        print('-'*40)
        
        print("%dth test data:" %(ith))
        
        print("At first, the dictionary originalDict has these keys:%s." %(str(list(originalDict.keys()))) )
        print("At first, the dictionary originalDict is:%s." %(str(originalDict)) )
        print("At first, the dictionary defaultDict has these keys:%s." %(str(list(defaultDict.keys()))) )
        print("At first, the dictionary defaultDict is:%s." %(str(defaultDict)) )
        print("After invoking the method: DictionaryHandler.Dict.Operation.DefaultDict,")
        print("Now, the dictionary originalDict has these keys:%s."  %(str(list(originalDict.keys()))) )
        print("Now, the dictionary originalDict is:%s." %(str(originalDict)) )
        
        print('-'*40)
    