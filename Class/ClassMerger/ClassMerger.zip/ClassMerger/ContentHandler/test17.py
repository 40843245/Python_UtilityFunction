import bdb
if __name__ == '__main__':
    x = 2
    breakpoint1 = bdb.Breakpoint(__file__, 3 , temporary=False, cond=None, funcname=None)
    breakpoint1.enable()
    print(breakpoint1.bpformat())