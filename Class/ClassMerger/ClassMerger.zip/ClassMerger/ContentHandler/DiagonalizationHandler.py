import sympy

if __name__ == '__main__':
    
    n = 10
    corrMatrices = list()
    corrMatrix = list()
    for rowIndex in range(0,n,1):
        corrMatrix = list()
        for colIndex in range(0,n,1):
            if rowIndex == colIndex :
                c = 'c'+'_'+str(rowIndex)+'^'+'2'
                sb = sympy.symbols(c)
                corrMatrix.append(sb)
            else:
                c = 'c'+'_'+str(rowIndex)+'_'+str(colIndex)
                sb = sympy.symbols(c)
                corrMatrix.append(sb)
        corrMatrices.append(corrMatrix)        
    print(corrMatrices)
    
    corrMatrices = sympy.Matrix(corrMatrices)
    
    print('')
    
    print(corrMatrices)


    [ p , d ] = corrMatrices.diagonalize()

    print()
    
    print(p)
    
    print()
    
    print(d)

    