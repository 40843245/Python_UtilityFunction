import bdb
import keyboard
def AddBreakpoint(self):
    print("AddBreakpoint method was called.")
    breakpoint1 = bdb.Breakpoint(__file__,13,temporary = True)
    breakpoint1.enable()
def OnRemovedCallback():
    print("OnRemovedCallback method was called.")
if __name__ == '__main__':
    print(__file__)
    keyboard.add_hotkey("g",AddBreakpoint,False)
    dummy = None
    keyboard.press('F12')
    print("1th!!!")
    print("2th!!!")
    keyboard.release('F12')
    dummy = None
    
    