class DemoClass( x ) : 
	def Func1 () :

		return "Method Func1 of DemoClass in demo_2.py file."
class DemoClass( x ) : 
	def Func1 () :

		return "Method Func1 of DemoClass in demo_2.py file."
