"""
DemoClass in demo_1.py
"""
class DemoClass():
    def Func1():
        pass
    