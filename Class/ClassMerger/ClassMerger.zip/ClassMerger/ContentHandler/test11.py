import pynput.keyboard
import bdb

def AddBreakpoint():
    print("AddBreakpoint method was called.")
    breakpoint1 = bdb.Breakpoint(__file__,36,temporary = True)
    breakpoint1.enable()
    print("breakpoint1:%s" %(str(breakpoint1)))
    print("breakpoint1.enabled:%s" %(str(breakpoint1.enabled)))
    
def on_press(key):
    if key == pynput.keyboard.Key.esc:
        return False  # stop listener
    try:
        k = key.char  # single-char keys1
    except:
        k = key.name  # other keys
    if k in ['1', '2']:  # keys of interest
        # self.keys.append(k)  # store it in global-like variable
        print('Key pressed: ' + k)
        AddBreakpoint()
        print('End of key pressed.')

        
        
        

if __name__ == '__main__':
    listener = pynput.keyboard.Listener(on_press=on_press)
    listener.start()  # start to listen on a separate thread
    listener.join()  # remove if main thread is polling self.keys
    
    print('end of listener')
    print('NO')
    print('NOPE.')
    print('YA')
    print('YAPE')
    