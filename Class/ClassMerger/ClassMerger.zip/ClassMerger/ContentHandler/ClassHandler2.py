from FuncHandler import FuncHandler
from StringHandler2 import StringHandler
from CommentsHandler import CommentsHandler
from DemoClass import DemoClass


class ClassHandler():
    class Class():
        class String():
            @staticmethod
            def GetClassContent(s:str) -> list[str]:
                keyword = 'class'
                whitespace = ' '
                tab = '\t'
                newLine = '\n'
                leftBracket = '('
                rightBracket = ')'
                semicolon = ':'           
                wn = whitespace + tab 
                
                poses = StringHandler.Single.Keyword.GetPoses(s, keyword)
                
                s = s.lstrip(wn)
                s = s.removeprefix(keyword)
                s = s.lstrip(wn)
                
                leftBracketIndex = s.find(leftBracket)
                if leftBracketIndex == -1 :
                    raise Exception("No left bracket in class definition")
                
                className = s[:leftBracketIndex]
                className = className.strip(wn)

                rightBracketIndex = s.find(rightBracket)
                if rightBracketIndex == -1 :
                    raise Exception("No closed bracket in class definition")
                    
                inheritedClassString = s[leftBracketIndex+1:rightBracketIndex]
                inheritedClassString = inheritedClassString.strip(wn)
                               
                leaveString = s[rightBracketIndex+1:]
                leaveString = leaveString.lstrip(wn)
                leaveString = leaveString.removeprefix(semicolon)
                leaveString = leaveString.lstrip(wn)            
                leaveString = leaveString.removeprefix(newLine)
                
                return [className,inheritedClassString,leaveString , poses ]
                
            """
            Intro:
                A method that returns info for all class definitions with given string.
                (Bunches of classes)
            Parameter:
                s: given string
            Returned Value:
                All infos that contains info for all classes.
            """
            @staticmethod
            def GetInfos(s:str):
                stringList = ClassHandler.Class.String.Split(s)
                classes = list()
                for string in stringList :    
                    cla = ClassHandler.Class.String.GetClassContent(string)
                    classes.append(cla)
                classesList = classes[:]
                print("In the GetInfos method,")
                print("classesList:")
                print(classesList)
                print("classes:")
                print(classes)
                for i in range(0,len(classes),1):
                    cla = classesList[i]
                    c = FuncHandler.Func.String.GetInfos(cla[2])
                    classesList[i][2] = c[0]
                    
                indentationList = CommentsHandler.Comment.String.Infos.GetIndentationsInfo(s)
                
                classesInfos = list()
                
                for classesListNo in range(0,len(classesList),1):
                    classes = classesList[classesListNo]
                    classesInfo = dict()
                    classesInfo.update( { "class":classes } )
                    classesInfos.append(classesInfo)
                    
                indentationsInfos = list()
                for indentationInfosNo in range(0,len(indentationList),1):
                    indentations = indentationList[classesListNo]
                    indentationInfo = dict()
                    indentationInfo.update( { "indentations":indentations } )
                    indentationsInfos.append(indentationInfo)
                
                infos = list()
                infos.append(classesInfos)
                infos.append(indentationsInfos)
                print("infos:")
                print(infos)
                return infos
    
            """
            Intro:
                A method that returns info for the class definition with given string.
                (Single class)
            Parameter:
                s: given string.
            Returned Value:
                All info that contains info for the class.
            """
            @staticmethod
            def GetInfo(s : str):
                keyword = "class"
                newline = '\n'
                tab = '\t'
                whitespace = ' '     
                wn = whitespace + newline + tab
                
                s = s.lstrip(wn)
                s = s.lstrip(keyword)
                s = s.lstrip(wn)
                
                cla = FuncHandler.Func.String.GetInfos(s)
                return cla
            
            """
            Intro:
                A method that splits the string into class definitions.
            Parameter:
                s: given string.
            Returned Value:
                A list that contains all class definitions.
            """
            @staticmethod
            def Split(s:str) -> list[str] :
                keyword = 'class'
                stringList = StringHandler.Single.Split(s, keyword)
                return stringList              
if __name__ == '__main__':
    demoClass = DemoClass()
    
    s = StringHandler.Single.Whitespacize(demoClass.s)
    print("s:")
    print(s)
    infos = ClassHandler.Class.String.GetInfos(s)

    