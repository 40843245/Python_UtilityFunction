class DemoClass():
    def __init__(self):
            self.s = """\
#1st singleline comment # NOT an another singleline comment since it is in 1st singleline comment.
\t'''1st multiline comment''' 
\t\t'''2nd multiline comment
'''
        
class DemoClass(x):
\t\t'''3rd multiline comment''' \"\"\"4th multiline comment\"\"\"
\tdef Func1():
\t\t\"\"\"'''5th multiline comment'''\"\"\"
class DemoClass():
\tdef Func2():
\t\tpass
\tdef Func1():
\t\treturn "Method Func1 of DemoClass in demo_2.py file."
'''
6th multiline comment
# NOT a singleline comment.
end of 6th multiline comment
'''
\t#2nd singleline comment '''NOT a multiline comment since it is in 2nd singleline comment'''
'''
7th multiline comment
# NOT a singleline comment.
end of 7th multiline comment
\t
''' # Is a singleline comment.

''' hello REWSSZZ\"\"\" world ''' what \"\"\" the \"\"\" fuck? 
\"\"\"
'''
This is NOT a multiline comment which surrounded by double quotatation since it is quotated by double quotation.
'''
\"\"\"
        
Another texts which NOT comments.
        
\"\"\"
# This is NOT a singleline comment.
'''
# This is also NOT a singleline comment.
This is also NOT a multiline comment which surrounded by double quotatation since it is also quotated by double quotation.
'''
# This is also NOT a singleline comment.
        
\"\"\"
        
\t\t# This is a singleline comment.
        
"""