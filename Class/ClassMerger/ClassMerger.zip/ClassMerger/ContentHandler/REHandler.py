import re

class REHandler():
    """
    Intro:
        A method that finds first word.
    Parameter:
        s: given string.
    Returned Value:
        returns a string that indicates first word (if exists). Otherwise, returns empty string.
    """
    @staticmethod
    def FirstWord(s:str):
        m = REHandler.AllWord(s)
        r = None if m == None or len(m) == 0 else m[0]
        return r
    
    @staticmethod
    def AllWord(s:str)->(list[str] | None ):
        expr = r'\W*(\w*)'
        pattern = re.compile(expr,re.NOFLAG)
        m = pattern.findall(s)
        return m
    @staticmethod
    def WordRest(delim : str , s : str , rests : str ,ends : str ):        
        expr = r'(?<=('+delim+'))('+rests+'+'+ends+'*)'
        m = re.split(expr, s ,flags = re.DOTALL)
        whitespace = ' '
        r = [ elem.removesuffix(whitespace) for elem in m if elem.endswith(delim) == False  ]
        nolast = r[:-1]
        return ( expr, m , r , nolast)
    
    @staticmethod
    def NextWord(s : str , keyword:str):
        expr = r'(?>('+keyword+'))'+'('+'\s*\w*'+')'
        print(expr)
        pattern = re.compile(expr,re.DOTALL)
        m = pattern.search(s,0)
        
        nextword = list()
        while m != None:
            group = m.groups(0)
            span = m.span(0)
            whitespace = ' '
            w = group[-1].strip(whitespace)
            nextword.append(w)
            m = pattern.search(s,span[1])
        return nextword
    
    @staticmethod
    def SplitParagraph(s:str,keyword:str):
        delim = '\s*\w*'
        r = REHandler.Split(s, keyword , delim )
        return r
    
    @staticmethod
    def Split(s : str , keyword: str , delim : str):
        expr = r'.*('+keyword+')'+'('+delim+')*'
        print("expr:")
        print(expr)
        pattern = re.compile(expr,re.NOFLAG)
        indexList = list()
        nextphrase = list()
        currIndex = 0
    
        m = pattern.search(s,0)
        while m != None:
            span = m.span(0)            
            indexList.append(span[0])
            currIndex = span[0]
            m = pattern.search(s,span[1])
            
        for i in range(0,len(indexList),1):
            currIndex = indexList[i]
            if i != len(indexList) - 1  :
                nextIndex = indexList[i+1]
            else:
                nextIndex = len(s)
            w = s[currIndex:nextIndex]
            if w != None and len(w) > 0 :
                w = w.lstrip(keyword)
                nextphrase.append( ( w , currIndex ) )
        return nextphrase
            
if __name__ == '__main__':    
    s = """\
\tde,f Func1(argv1,argv2:int)->tuple:
        pass
        def Func2(argv1,argv2,)->list:
            pass
    """
    
    keyword = "( |\t)"
    r = REHandler.FirstWord(s)
    
    print(r)
