from StringHandler2 import StringHandler
from CommentsEnum import CommentsEnum
from DictionaryHandler import DictionaryHandler
from ClassHandler2 import ClassHandler
from ElemsHandler import ElemHandler

class IndentationHandler():
    class Indentation():
        class String():
            """
            Intro:
                A method that get number of indentation for each line in given string.
            Parameter:
                s: given string.
            Returned Value:
                A dict that indicates :
                    1. which line is None or empty string.
                    2. If the line neither None or empty string, the number of indentation.
            """
            @staticmethod
            def GetComments(s: (str|None) ) -> list :
                if s is None:
                    raise Exception("The string is None.")
                if len(s) <= 0 :
                    return ''
                
                newline = '\n'
                lines = s.split(newline)
                numOfLines = len(lines)
                singleLineComment = CommentsEnum().singlelineEnum
                multiLineComment = CommentsEnum().multilineEnum
                infos = list()
                subtable = dict()
                table = list()
                
                for currLineNo in range(0,numOfLines,1):        
                    subtable = dict()
                    table = list()
                    currLine = lines[currLineNo]
                    if currLine == None or len(currLine) <= 0 :
                        continue
                    for i in range(0,len(singleLineComment),1):
                        keyword = singleLineComment[i]
                        indices = StringHandler.Single.FindAll(currLine, keyword)
                        if indices != None and len(indices) > 0 :
                            subtable = { 'singleLineComment' : {'commentType':keyword , 'startPos' : indices[0] } }
                            table.append(subtable)
                                
                    for i in range(0,len(multiLineComment),1):
                        keyword = multiLineComment[i]
                        indices = StringHandler.Single.FindAll(currLine, keyword)
                        if indices != None and len(indices) > 0 :
                            for j in range(0,len(indices),1):
                                index = indices[j]
                                subtable = { 'multiLineComment' : { 'commentType' : keyword , 'startPos' :index } }
                                table.append(subtable)
                    if table != None and len(table) > 0:
                        infos.append( { currLineNo : table } )
                return infos
            
            @staticmethod
            def CheckIndentations(s:(list|None)) -> list :
                if s is None:
                    raise Exception("Invalid list to check indentations.")
                if len(s) <= 0 :
                    return ''
                singleLineComment = CommentsEnum().singlelineEnum
                multiLineComment = CommentsEnum().multilineEnum
                keyword = "startPos"
                
                comments = list()
                prevComment = None
                prevCommentType = None
                currComment = None
                currCommentType = None
                prevLineNo = None
                commentStateFlag = False
                breakFlag = False
                
                indentation = IndentationHandler.Indentation.String.GetComments(s)
                if indentation is None :
                    raise Exception("Unknown issues.")
                if len(indentation) <= 0 :
                    return indentation
                    
                ( lineNos , indentation , startPosList ) = DictionaryHandler.List.Sort.Sort(indentation, keyword)
                
                for i in range(0,len(indentation),1):
                    for j in range(0,len(indentation[i]),1):
                        lineNo = lineNos[i]
                        elem = indentation[i][j]
                        currComment = elem
                        currStartPos = elem.get("startPos")
                        currCommentType = currComment.get("commentType")
                        if currStartPos != None :
                            if currComment == None or commentStateFlag == False:
                                if currCommentType in singleLineComment:
                                    startPos = currComment.get("startPos")
                                    endPos = None
                                    posList = [startPos,endPos]
                                    currComment.update({'startPos':posList})
                                    d = {lineNos[i] :  currComment }
                                    comments.append(d)
                                    commentStateFlag = False
                                    breakFlag = True
                                    currComment = None
                                elif currCommentType in multiLineComment:
                                    d = {lineNos[i] : currComment }
                                    comments.append(d)
                                    prevLineNo = lineNo
                                    commentStateFlag = True
                                    breakFlag = False
                                else:
                                    raise Exception("Invalid type of comment.")
                                prevComment = currComment
                                prevCommentType = None if prevComment == None else prevComment.get("commentType")                                   
                                if breakFlag == True:
                                    break
                            else:
                                if currCommentType == prevCommentType :
                                    startPos = prevComment.get("startPos")
                                    endPos = currComment.get("startPos")
                                    posList = [startPos,( lineNo , endPos )]
                                    prevComment.update({"startPos" : posList})
                                    d = {prevLineNo:prevComment}
                                    prevComment = currComment
                                    prevCommentType = None if prevComment == None else prevComment.get("commentType")
                                    commentStateFlag = False
                return comments
            class Comments():
                @staticmethod
                def MoveInner(s:str) -> str:
                    
                    originalComments = IndentationHandler.Indentation.String.CheckIndentations(s)
                    print("originalComments:")
                    print(originalComments)
                    
                    originalClasses = ClassHandler.Class.String.GetInfos(s)
                    print("originalClasses:")
                    print(originalClasses)
                    
                    newLine = '\n'
                    lines = s.split(newLine)
                    commentPoses = list()
                    for i in range(0,len(originalComments),1):
                        currComment = originalComments[i]
                        if not currComment is None:
                            currLineNo = list(currComment.keys())[0]
                            values = list(currComment.values())
                            pos = values[0].get("startPos")
                            startPos = [currLineNo, pos[0]]
                            if len(pos) > 1 and not pos[1] is None:
                                endPos = [pos[1]]
                            else:
                                endPos = [currLineNo,len(lines[currLineNo])]
                            elem = [startPos,endPos]
                            commentPoses.append(elem)
                        isClass = True
                    newComments = originalComments[:]
                    indices = list()
                    for i in range(0,len(classes[3]),1):
                        currCommentPos = commentPoses[i]
                        prevClassPos = classes[3][i-1] if i >= 1 else [0,0]
                        currClassPos = classes[3][i]
                        currCommentStartPos= currCommentPos[0]
                        currCommentEndPos = currCommentPos[1][0]
                        
                        currComment = newComments[i]
                        if ElemHandler.List.Comp(prevClassPos, currCommentStartPos) in (-1, 0) and \
                           ElemHandler.List.Comp(currCommentEndPos , currClassPos) in (-1, 0):
                               indices.append(i)
                        
                    
                        
                        
                    print("indices:")
                    print(indices)
                    
                    for i in range(0,len(indices),1):
                        pass
                    return newComments
if __name__ == '__main__':
    s = """\
''' '''
\tclass DemoClass(x):
\t\t''' 1st multiline comment'''
\t\tdef Func1():
\t\t\tpass
\tclass DemoClass():
\t\tdef Func2():
\t\t\tpass
\t\tdef Func1():
\t\t\treturn "Method Func1 of DemoClass in demo_2.py file."
"""
    print("s:")
    print(s)
    print('^'*40)
    s = StringHandler.Single.Whitespacize(s)
    classes = ClassHandler.Class.String.GetClassContent(s)
    print("classes:")
    print(classes)
    r = IndentationHandler.Indentation.String.Comments.MoveInner(s)
    print("r:")
    print(r)            