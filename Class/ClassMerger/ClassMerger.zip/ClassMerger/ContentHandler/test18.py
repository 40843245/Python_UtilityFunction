import configparser
import re
if __name__ == '__main__':
    path = 'C:\\Users\\40843\\.spyder-py3\\config\\spyder.ini'
    #path = 'spyder.ini'
    print(path)
    
    config = configparser.ConfigParser()
    config.read(path,encoding = 'utf-8')
    
    sections = config.sections()
    print(sections)
    
    items = config.items()
    print(dict(items))
    
    
    
    