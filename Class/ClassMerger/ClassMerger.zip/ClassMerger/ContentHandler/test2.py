import textwrap
if __name__ == '__main__':
    s = """\
Hello!
"""
    print("s:")
    print(s)
    
    r = repr(s)
    print("r:")
    print(r)
    