from ArgvsHandler import ArgvsHandler
from StringHandler2 import StringHandler
from CommentsHandler import CommentsHandler
from DemoClass import DemoClass

class FuncHandler():
    class Func():
        class String():                
            @staticmethod
            def GetInfos(s:str):
                funcs = FuncHandler.Func.String.Split(s)
                funcInfos = list()
                for func in funcs:
                    funcInfo = FuncHandler.Func.String.GetInfo(func)
                    funcName = funcInfo[0]
                    argvs = funcInfo[1]
                    funcContent = funcInfo[2]
                    startsWithComments = CommentsHandler.Comment.String.Operation.Check.IsStartWithComments(funcContent)
                    doc = None
                    if startsWithComments == True:
                        doc = CommentsHandler.Comment.String.Infos.GetIndentationsInfo(funcContent)
                        doc = doc[0]
                        doc = doc.get("text")
                    d = dict()
                    d.update( {
                            "name":funcName,
                            "argvs":argvs,
                            "content":funcContent,
                        }
                    )
                    if not doc is None:
                        d.update( {
                            "doc":doc,
                            }
                        )
                    funcInfos.append(d)
                    dummy = None
                return funcInfos           
            @staticmethod
            def GetInfo(s:str):
                keyword = "def"
                newline = '\n'
                whitespace = ' '
                leftBracket = '('
                rightBracket = ')'
                semicolon = ':'
                wn = whitespace + newline
                minus = '-'
                gt = '>'
                
                poses = StringHandler.Single.Keyword.GetPoses(s, keyword)
                
                s = s.lstrip(wn)
                s = s.lstrip(keyword)
                s = s.lstrip(wn)
                leftBracketIndex = s.index(leftBracket)
                rightBracketIndex = s.index(rightBracket)
                funcName = s[0:leftBracketIndex]
                argvs = s[leftBracketIndex+1:rightBracketIndex]
                content = s[rightBracketIndex+1:]
                content = content.lstrip(whitespace)
                semicolonIndex = content.index(semicolon)
                returnedType= content[0:semicolonIndex]
                returnedType = returnedType.lstrip(whitespace)
                returnedType = returnedType.lstrip(minus)
                returnedType = returnedType.lstrip(gt)
                
                content = content[semicolonIndex+1:]
                content = content.lstrip(wn)
                
                argvsList = ArgvsHandler.Argv.String.GetInfo(argvs)
                
                return [funcName , argvsList , content , poses]
        
            
            """
            Intro:
                A method that split it into many function definitions with given string 
                (through splitting it by def keyword)
            Parameter:
                s: given string.
            Returned Value:
                A list that contains many function definitions.
            """
            @staticmethod
            def Split(s:str) -> list[str] :
                keyword = "def"
                stringList = StringHandler.Single.Split(s, keyword)
                return stringList
                   
if __name__ == '__main__':
    demoClass = DemoClass()
    s = demoClass.s
    s = StringHandler.Single.Whitespacize(s)
    r = FuncHandler.Func.String.GetInfos(s)
    print(r)
    classObj = globals()[self.__class__.__name__]
    