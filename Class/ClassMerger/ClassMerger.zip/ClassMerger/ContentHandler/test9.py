import types
if __name__ == '__main__':
    className = 'DemoClass'
    classDef = types.new_class(className)
    setattr(classDef, "x", 2)
    print(classDef.x)
    