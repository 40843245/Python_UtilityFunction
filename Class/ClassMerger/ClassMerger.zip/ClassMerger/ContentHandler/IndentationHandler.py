from StringHandler import StringHandler
from REHandler import REHandler
from CommentsEnum import CommentsEnum

class IndentationHandler():
    class Indentation():
        class String():
            """
            Intro:
                A method that get number of indentation for each line in given string.
            Parameter:
                s: given string.
            Returned Value:
                A dict that indicates :
                    1. which line is None or empty string.
                    2. If the line neither None or empty string, the number of indentation.
            """
            @staticmethod
            def GetIndentations(s:str):
                newline = '\n'
                tab = '\t'
                whitespace = ' '
                
                multilineEnum = CommentsEnum().multilineEnum
                
                indentation = dict()
                lines = s.split(newline)
                numOfLines = len(lines)
                isComment = False
                isCommentInSameLine = False
                commentType = None
                commentPos = tuple()
                prevCommentObject = dict()
                currTable = dict()
                prevTable = dict()
                
                for i in range(0,numOfLines,1):
                    line = lines[i]
                    
                    if line != None and len(line) > 0 :
                        
                        currCnt = 0
                        whitespaceMap = list()
                        tabMap = list()
                        text = line[:]
                        
                        while len(text) > 0 :
                            if text[0] == whitespace :
                                prefixCount = StringHandler.GetPrefixCount(text, whitespace)
                                whitespaceMap.append([currCnt,currCnt+prefixCount])
                                currCnt += prefixCount
                                text = text[prefixCount+1:]
                            elif text[0] == tab:
                                prefixCount = StringHandler.GetPrefixCount(text, tab)
                                tabMap.append([currCnt,currCnt+prefixCount])
                                currCnt += prefixCount
                                text = text[prefixCount+1:]
                            else :
                                break

                        ( isCommentInSameLine , commentPos , commentType ) = StringHandler.IsComment(line)
                        
                        if isCommentInSameLine == True :
                            isComment = True
                            
                        
                        
                        prevTable = currTable
                        
                        currTable = dict()
                        currTable.update( {"isCommentInSameLine": isCommentInSameLine} )
                        currTable.update( {"commentPos": commentPos[1]} )
                        currTable.update( {"commentType": commentType} )
                        currTable.update( {"whitespace": whitespaceMap} )
                        currTable.update( {"tab": tabMap} )
                        
                        indentation.update( { i : currTable} )
                    else :
                        prevTable = currTable
                        currTable = None 
                        indentation.update( { i : currTable} )
                return indentation
            @staticmethod
            def CheckIndentations(s:str) -> bool:
                
                # When s is None or empty string, always returns True.
                if s == None or len(s) > 0 :
                    return True
                
                newline = '\n'
                lines = s.split(newline)
                numOfLine = len(lines)
                indentation = IndentationHandler.Indentation.String.GetIndentations(s)
                keys = list(indentation.keys())
                lastIndentedCount = -1
                currIndentedCount = -1
                
                for currLine in range(0,len(keys),1):
                    line = lines[currLine]
                    key = keys[currLine]
                    val = indentation.get(key)
                    if line == None or len(line) <= 0 :
                        continue
                    if val == None:
                        continue
                    whitespaceMap = val.get("whitespace")
                    tabMap = val.get("tab")
                    isComment = val.get("isComment")
                    commentType = val.get("commentType")
                    
                    
                    # indentation with mixed of whitespace and tab. (consider to be invalid since it may be invalid for Python interpreter.)
                    if len(whitespaceMap) > 0 and len(tabMap) > 0 :
                        raise Exception("Invalid Indentation.\nSince it is not allowed for indentation that have tab and whitespace at same line.")
                        
                    # indentation with whitespace
                    if len(whitespaceMap) > 0 :
                        currIndentedCount = whitespaceMap[0]
                        if (0<=currLine and currLine<numOfLine) == False:
                            raise Exception("OutOfRangeError:\ncurrLine is out of number of lines in s.")
                        commentPos = val.get("whitespace")[1]
                        
                        
                        
                    # indentation with tab
                    elif len(tabMap) > 0 :
                        if (0<=currLine and currLine<numOfLine) == False:
                            raise Exception("OutOfRangeError:\ncurrLine is out of number of lines in s.")
                        commentPos = val.get("tab")[1]
                        
                        
                
                    # no indentation (i.e. starts with letter other than whitespace and tab.)
                    else :
                        pass
                
                
if __name__ == '__main__':
    s = """
    class DemoClass():
        def Func1():
            pass
        '''
        '''
    

    class DemoClass():
        class InnerClass():
            pass
        def Func2():
            pass
    
        def Func1():
            return "Method Func1 of DemoClass in demo_2.py file."
    """
    r = IndentationHandler.Indentation.String.GetIndentations(s)
    print(s)
    print(r)
    

                