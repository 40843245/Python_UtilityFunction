from CommentsEnum import CommentsEnum
from REHandler import REHandler
class StringHandler():
    """
    Intro:
        Get the how many occurences of prefix (which is given in ) in given string (which given in s).
    Parameter:
        s: given string as target.
        keyword: keyword for counting the occurences.
    Returned Value:
        Returns a nonnegative integer that indicates how many occurences of prefix (which is given in ) in given string (which given in s).
    """
    @staticmethod
    def GetPrefixCount(s:str,keyword:str) -> int :
        removedS = s.lstrip(keyword)
        count = ( len(s) - len(removedS) ) // len(keyword)
        return count
    
    """
    Intro:
        Get the how many occurences of suffix (which is given in ) in given string (which given in s).
    Parameter:
        s: given string as target.
        keyword: keyword for counting the occurences.
    Returned Value:
        Returns a nonnegative integer that indicates how many occurences of suffix (which is given in ) in given string (which given in s).
    """
    @staticmethod
    def GetSuffixCount(s:str,keyword:str) -> int :
        removedS = s.rstrip(keyword)
        count = ( len(s) - len(removedS) ) // len(keyword)
        return count
    
    @staticmethod
    def LStrip(s:str,keyword:str,weight : int) -> ( str | None ):
        if s == None and len(s) <= 0 :
            return ( None , -1 )
        x = s.lstrip(keyword)
        length = len(s) - len(x) 
        return ( x , length * weight)
    
    @staticmethod
    def RStrip(s:str,keyword:str,weight : int) -> ( str | None ):
        if s == None and len(s) <= 0 :
            return ( None , -1 )
        x = s.rstrip(keyword)
        length = len(s) - len(x)
        return ( x , length * weight)
    #
    @staticmethod
    def LStrips(s:str,keywordList : list[str] , weights : list[int] ) -> ( str | None ):
        if s == None and len(s) <= 0 :
            return None
        totalLength = 0
        flag = True
        x = s
        while flag == True:
            flag = False
            for i in range(0,len(keywordList),1):
                ( x ,length ) = StringHandler.LStrip(x, keywordList[i],weights[i])
                if not length in [-1,0]  and len(x) > 0 :
                    totalLength += length
                    flag = True
        return ( x , totalLength )
    #
    @staticmethod
    def RStrips(s:str,keywordList : list[str] , weights : list[int]) -> ( str | None ):
        if s == None and len(s) <= 0 :
            return None
        totalLength = 0
        flag = True
        x = s
        while flag == True:
            flag = False
            for i in range(0,len(keywordList),1):
                ( x ,length ) = StringHandler.RStrip(x, keywordList[i],weights[i])
                if not length in [-1,0]  and len(x) > 0 :
                    totalLength += length
                    flag = True
        return ( x , totalLength )
    
    def LineComment(s:str,keywordList:list[str],weights:list[int]) -> ( tuple | None ):
        whitespace = ' '
        tab = '\t'
        keywordList = [whitespace,tab]
        weights = [1,4]
        
        comments = "\'\'\'|\"\"\"|#"
        delim = '[^ \\s\\t]'
        r = REHandler.Split(s, comments,delim)
        return r
        
    @staticmethod
    def IsComment(s:str) -> bool :
        ( firstWord , span ) = REHandler.FirstWord(s)
        commentType = StringHandler.GetCommentType(firstWord) 
        isComment = True if commentType != None else False
        return ( isComment , span , commentType )
    @staticmethod
    def GetCommentType(s:str) -> ( str | None ):
        enums = CommentsEnum().enums
        for i in range(0,len(enums),1):
            if s.startswith(enums[i]) == True:
                return enums[i]
        return None
    
            
if __name__ == '__main__':

    whitespace = ' '
    tab = '\t'
    keywordList = [whitespace,tab]
    weights = [1,4]
    
    #r = "        ''' ''' "
    r = "\t\t''' ''' "
    
    ( r , totalLength ) = StringHandler.LStrips(r, keywordList,weights)
    
    s = r
    keywordList = []
    weights = []
    r = StringHandler.LineComment(s, keywordList, weights)
    print(r)