import inspect

class DemoClass():
    """
    BullShit!!!
"""
# SingleLine
    def Func1():
        pass
    
r = DemoClass.__doc__ 
print("r:")
print(r)

r = inspect.getcomments(DemoClass)
print("r:")
print(r)

