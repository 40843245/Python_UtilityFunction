d = {1:1,2:2}

r = d.values()
print(type(r))
print(dir(r))
print(r.mapping)
print(list(r))