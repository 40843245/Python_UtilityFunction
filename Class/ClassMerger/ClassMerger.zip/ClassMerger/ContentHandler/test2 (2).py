import re

class REHandler():
    @staticmethod
    def FindAll(s : str , keyword: str , delim : str):
        expr = r'(.*('+keyword+'))+(.*)'
        print("expr:")
        print(expr)
        pattern = re.compile(expr,re.DOTALL)
        m = pattern.findall(s)
        print("m:")
        print(m)
    @staticmethod
    def Split(s : str , keyword: str , delim : str):
        expr = r'(.*('+keyword+'))+(.*)'
        print("expr:")
        print(expr)
        pattern = re.compile(expr,re.DOTALL)
        indexList = list()
        nextphrase = list()
        currIndex = 0
    
        m = pattern.search(s,0)
        print("m:")
        print(m)
        while m != None:
            span = m.span(0)
            indexList.append(span)
            currIndex = span[0]
            m = pattern.search(s,span[1])
            
        for i in range(0,len(indexList),1):
            if i != len(indexList) - 1  :
                nextIndex = indexList[i+1][0]
            else:
                nextIndex = len(s)
            w = s[indexList[i][0]:nextIndex]
            if w != None and len(w) > 0 :
                #w = w.lstrip(keyword)
                nextphrase.append( ( w , indexList[i] ) )
        return nextphrase
if __name__ == '__main__':
    s = "\
        ''' '''\
    "
    comments = "\'\'\'|\"\"\""
    delim = '[^ \\s\\t]'
    r = REHandler.FindAll(s, comments,delim)
    print(r)
    
    
    