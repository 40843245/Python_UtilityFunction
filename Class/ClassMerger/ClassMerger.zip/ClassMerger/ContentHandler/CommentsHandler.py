from CommentsEnum import CommentsEnum
from StringHandler2 import StringHandler
from ElemsHandler import ElemHandler,ElemsFinder
from NestedFlatterInhomogenous import NestedFlatterInhomogenous
from TextHandler import TextHandler
from REHandler import REHandler
from DemoClass import DemoClass
class CommentsHandler():
    """
    Intro:
        A class that handles comments.
    """
    class Comment():
        """
        Intro:
            A class that handles input with only string type.
            That is, if input is NOT with string type, don't use this class.
        """
        class String():  
            """
            Intro:
                A class that handles infos about comments.
            """
            class Infos():
                """
                Intro:
                    A  method that get pos of singleline comment and multiline comments. 
                    For more details, see NOTICE section.
                Parameter:
                    s: given string.
                Returned Value:
                    A tuple (commentsPosInfos,commentsInfos)
                    1. commentsPosInfos is a list that indicates the pos of comments.
                    2. commentsInfos is a list of dicts whose keys is:
                        1. type: type of comment.
                        2. pos: pos of comment (including start pos and end pos of comments).
                        3. text: text of comment.
                NOTICE:
                    NOTICE that the start pos refers pos after the comment symbol appears. (NOT before)
                """
                @staticmethod
                def GetCommentsInfos(s: (str|None) ) -> list :
                    if s is None:
                        raise Exception("The string is None.")
                    if len(s) <= 0 :
                        return None
                    
                    allComment = CommentsEnum().enums
                    
                    [ singleLineCommentPosInfos , multiLineCommentPosInfos ] = CommentsHandler.Comment.String.Infos.GetCommentsInfoTuple(s)
                    singleLineCommentPosInfos = [ singleLineCommentPosInfos ]
                    
                    
                    allCommentPosInfos = list()               
                    for singleLineCommentPosInfo in singleLineCommentPosInfos:
                        allCommentPosInfos.append(singleLineCommentPosInfo)
                    for multiLineCommentPosInfo in multiLineCommentPosInfos:
                        allCommentPosInfos.append(multiLineCommentPosInfo)
                    
                    originalCommentPosInfos2D = list() 
                    for singleLineCommentPosInfo in singleLineCommentPosInfos:
                        originalCommentPosInfos2D.append(singleLineCommentPosInfo)
                    for multiLineCommentPosInfo in  multiLineCommentPosInfos:
                        originalCommentPosInfos2D.append(multiLineCommentPosInfo)
                    
                    # flat the nested list from originalCommentPosInfos2D.
                    originalCommentPosInfos2D_t2 = NestedFlatterInhomogenous.PartiallyFlat(originalCommentPosInfos2D[:], 2)
                    
                    # deepcopy the list.
                    originalCommentPosInfos2D_t3 = originalCommentPosInfos2D_t2[:]
                    # sort the list from originalCommentPosInfos2D_t3.
                    originalCommentPosInfos2D_t3.sort()
                    # flat the nested list from originalCommentPosInfos2D_t3.
                    originalCommentPosInfos2D_t3 = NestedFlatterInhomogenous.PartiallyFlat(originalCommentPosInfos2D_t3, 1)
                    # sort the list from originalCommentPosInfos2D_t3.
                    originalCommentPosInfos2D_t3.sort()
                    
                    commentsPosInfos = list()
                    commentsInfos = list()
                    posIndices = list()
                    tempPosList = list()
                    
                    options = {
                        "targetType":"array" ,
                    }
                    canMatch = False
                    originalCommentPosInfosNo = 0
                    
                    # requirement of matching comments in given info of pos (stored in tempPosList).
                    # 1. At least two elems, (i.e. matching length of tempPosList >= 2 is True)
                    # 2. The comments type are same so that they are can be parsed.
                    while originalCommentPosInfosNo < len(originalCommentPosInfos2D_t3):
                        originalCommentPosInfo1 = originalCommentPosInfos2D_t3[0]
                        tempPosList.append(originalCommentPosInfo1[:])
                        
                        # meet the 1th requirement.
                        if len(tempPosList) >= 2:
                            posIndices.clear()
                            for tempPosListNo in range(0,len(tempPosList),1):
                                tempPos = tempPosList[tempPosListNo]
                                index = ElemsFinder.GetElemIndex(allCommentPosInfos, tempPos, options)
                                if index != -1 :
                                    posIndices.append(index)
                                
                            # determines that comments are completely matched or not.
                            # they are only matched iff the comment types are same.
                            # meet the 2th requirement.
                            if allComment[posIndices[0]] == allComment[posIndices[-1]]:
                                # indicates that comments are completely matched.
                                canMatch = True
                                
                        # comments are completely matched. One can add the match to resultant.
                        if canMatch == True:
                            keyword = allComment[posIndices[0]]
                            posPair = [ [ tempPosList[0][0] , tempPosList[0][1] + len(keyword) ], tempPosList[-1]]
                            
                            # select the text of comment in given pos.
                            text = TextHandler.Text.Range(s, tuple( posPair[0] ), tuple(posPair[1]))
                            d = {'type':keyword,'pos':posPair,'text':text}
                            commentsPosInfos.append(  posPair )
                            commentsInfos.append(d)
                            # reset. clear all items for all temporary lists.
                            tempPosList.clear()
                            posIndices.clear()
                            # reset. clear for all flags.
                            canMatch = False
                            
                        # remove the item.
                        del originalCommentPosInfos2D_t3[0]
                        
                    return (commentsPosInfos,commentsInfos)
                
                """
                Intro:
                    A method that get about indentations.
                    For more details, see NOTICE section.
                Parameter:
                    s: given string.
                Returned Value:
                    A dict that indicates :
                        1. which line is None or empty string.
                        2. If the line neither None or empty string, the number of indentation.
                NOTICE:
                    NOTICE that it uses CommentsHandler.Comment.String.Infos.GetCommentsInfos method.
                    
                """
                @staticmethod
                def GetIndentationsInfo(s:str) -> list:
                    newLine = '\n'
                    whitespace = ' '
                    tab = '\t'
                    wt = [ whitespace , tab ]
                    
                    lines = s.split(newLine)
                    [ commentsPosInfos , commentsInfos] = CommentsHandler.Comment.String.Infos.GetCommentsInfos(s)
                    
                    commentsLineInfos = list()
                    for commentsPosInfosNo in range(0,len(commentsPosInfos),1):
                        commentsPosInfo = commentsPosInfos[commentsPosInfosNo]
                        startPos = commentsPosInfo[0]
                        commentsLineInfos.append(startPos)
                
                    prefixesInfos = list()
                    for startPosNo in range(0,len(commentsLineInfos),1):
                        startPos = commentsLineInfos[startPosNo]
                        line = lines[startPos[0]]
                        src = line[:startPos[1]]
                        prefixes = StringHandler.Single.Prefix.GetPrefixesIndex(src, wt)
                        prefixesInfos.append(prefixes)
                        
                        if len(prefixes) > 0:
                            prefixes = prefixes[0]
                            if len(prefixes) >= 2 :
                                if prefixes[1] == 0 :
                                    indentation = prefixes[2]
                                    if indentation > 0 :
                                        commentsInfos[startPosNo].update( { "indentation": indentation } )
                    return commentsInfos
                """
                Intro:
                    A subutility method that simply get occurence of singleline comment and multiline comments. 
                    For more details, see NOTICE section.
                Parameter:
                    s: given string.
                Returned Value:
                    A dict that indicates :
                        1. which line is None or empty string.
                        2. If the line neither None or empty string, the number of indentation.
                NOTICE:
                    NOTICE that it is simply get occurence of singleline comment and multiline comments. 
                    NOT considered the comments in real world. 
                    (such as case 1: a pair of symbol ''' <text> '''  appears in the line the after # symbol.)
                    (i.e. # <text> ''' <text> ''' )
                     For more examples, see the following test data.
                """
                @staticmethod
                def GetCommentsInfoTuple(s: (str|None) ) -> list :
                    if s is None:
                        raise Exception("The string is None.")
                    if len(s) <= 0 :
                        return None
                    newLine = '\n'
                    singleLineComment = CommentsEnum().singlelineEnum
                    multiLineComment = CommentsEnum().multilineEnum
                    lines = s.split(newLine)
                    singleLineCommentPosInfos = list()
                    for i in range(0,len(singleLineComment),1):
                        posList = list()
                        for currLineNo in range(0,len(lines),1):
                            currLine = lines[currLineNo]
                            keyword = singleLineComment[i]
                            indices = StringHandler.Single.FindAll(currLine, keyword)
                            poses = list()
                            if not indices is None and len(indices) > 0 :
                                poses = [ [currLineNo , indices[0] ] , [currLineNo , len(currLine) ] ]                               
                            if not poses is None and len(poses) > 0 :
                                posList.append(poses)
                            del poses
                        if not posList is None and len(posList) > 0 :
                            singleLineCommentPosInfos.append(posList)
                        del posList
                        del currLine                 
                    
                    multiLineCommentPosInfos = list()
                    for i in range(0,len(multiLineComment),1):
                        indicesInfo = list()
                        keyword = multiLineComment[i]
                        for currLineNo in range(0,len(lines),1):
                            currLine = lines[currLineNo]                     
                            indices = StringHandler.Single.FindAll(currLine, keyword)
                            if not indices is None and len(indices) > 0 :
                                posList = list()
                                for j in range(0,len(indices),2):
                                   if j + 1 < len(indices) :
                                       tu = [indices[j],indices [ j + 1 ] ]
                                       pos = [ [currLineNo,tu[0]],[currLineNo,tu[1]] ] 
                                   else:
                                       tu = [indices[j]]
                                       pos = [ [currLineNo,tu[0] ] ]
                                   posList.append(pos)                                   
                                   del tu
                                   del pos
                                if not posList is None and len(posList) > 0 :
                                    indicesInfo.append( posList )
                            del currLine
                            del indices
                        if not indicesInfo is None and len(indicesInfo) > 0 :                    
                            multiLineCommentPosInfos.append(indicesInfo)
                        del indicesInfo
                        del keyword     
                        
                    commentsPoses = list()    
                    for mcNo in range(0,len(multiLineCommentPosInfos),1):                    
                        multiLineCommentPosInfo = multiLineCommentPosInfos[mcNo]
                        for multiLineCommentPosInfoNo in range(0,len(multiLineCommentPosInfo),1):
                            poses = multiLineCommentPosInfo[multiLineCommentPosInfoNo]
                            for posNo in range(0,len(poses),1):
                                pos = poses[posNo]
                                commentsPoses.append(pos)
                                del pos
                            del poses
                    prevCommentPos = currCommentPos = None  
                    multilineCommentsPosInfos = list()

                    for commentsPosesNo in range(0,len(commentsPoses),1):
                        commentsPos = commentsPoses[commentsPosesNo]
                        for itemsNo in range(0,len(commentsPos),1):
                            currCommentPos = commentsPos[itemsNo]
                            if not prevCommentPos is None:
                                pos = [prevCommentPos,currCommentPos]
                                isBetween = False
                                isExclusive = False
                                exclusiveIndex = list()
                                for i in range(0,len(multilineCommentsPosInfos),1):
                                    commentsPosInfo = multilineCommentsPosInfos[i]
                                    poses = commentsPosInfo
                                    startPos = poses[0]
                                    endPos = poses[1]
                                    isBetween1 = ElemHandler.Comparator.IsBetween(startPos,pos[0],endPos)
                                    isBetween2 = ElemHandler.Comparator.IsBetween(startPos,pos[1],endPos)
                                    if isBetween1 in [0] and isBetween2 in [0]:
                                        isBetween = True
                                        break
                                    if isBetween1 in [-1] and isBetween2 in [1]: 
                                         exclusiveIndex.append(i)
                                         isExclusive = True
                                if isExclusive == True:            
                                    for i in range(0,len(exclusiveIndex),1):
                                        del multilineCommentsPosInfos[exclusiveIndex[i]]
                                if isBetween == False:
                                    multilineCommentsPosInfos.append(pos)
                                prevCommentPos = None
                            else: 
                                prevCommentPos = currCommentPos
                    del prevCommentPos 
                    del currCommentPos
                    
                    return [ singleLineCommentPosInfos,multiLineCommentPosInfos ]

            """
            Intro:
                A class that operates about comments.
            """                    
            class Operation():
                class Check():
                    @staticmethod
                    def IsStartWithComments(originalText:str) -> bool:
                        if originalText is None:
                            raise Exception("Can not check for a NoneType object.")
                        if not isinstance(originalText,(str)) :
                            raise Exception("Can not check for a non-string object.")
                        newLine = '\n'
                        whitespace = ' '
                        tab = '\t'
                        
                        wtn = newLine + whitespace + tab
                        
                        allComments = CommentsEnum().enums
                        firstWord = REHandler.FirstWord(originalText)
                        firstWordIndex = originalText.find(firstWord)
                        prefixes = originalText[:firstWordIndex]
                        prefixes = prefixes.strip(wtn)
                        if len(prefixes) <= 0:
                            return False
                        retVal = any([ prefixes.startswith(elem) for elem in allComments])
                        return retVal
                        
                        
                """
                Intro:
                    A class for moving comments.
                """
                class Move():
                    class Class():
                        """
                        Intro:
                            A method that move comments that just on top of class down into the class.
                        Parameter:
                            1. originalText: original text
                        Returned Value:
                            Returns a string after comments are moved.
                        """
                        @staticmethod
                        def MoveInner(originalText:(str|None)) -> str:
                            commentsInfos = CommentsHandler.Comment.String.Infos.GetIndentationsInfo(s)
                            return commentsInfos
                """
                Intro:
                    A class that get pos with comments in given list (named array).
                """
                class Get():
                    """
                    Intro:
                        A method that get the max pos for each with given list (named array)
                        The purpose of doing so is:
                            1. can insert comments with empty string. For more details, see the following test data and run this code with it.
                            etc. 
                    Parameter:
                        1. array: a list that contains infos about comments. (each elem of the array must be a dict and whose have key (named pos) ) 
                    Returned Value:
                        Returns a tuple (maxX,maxY). 
                        maxX refers that which line has max pos (corresponding to maxY).
                        maxY refers that the max pos.
                    """
                    @staticmethod
                    def MaxPos(array:list) -> tuple[int]:
                        maxX = maxY = 0
                        for arrayNo in range(0,len(array),1):
                             item = array[arrayNo]
                             poses = item.get("pos")
                             endPosLine = poses[1][0]
                             endPosCol = poses[1][1]
                             if endPosLine > maxX:
                                 maxX = endPosLine
                             if endPosCol > maxY:
                                 maxY = endPosCol
                        return (maxX,maxY)
                """
                Intro:
                    A class for prefill data for another use.
                    For more details, see Fill method.
                """
                class Fill():
                    """
                    Intro:
                        A method that prefill several newline and whietspace from original text (named originalText) with given list (named array)
                        The purpose of doing so is:
                            1. can insert comments with empty string. For more details, see the following test data and run this code with it.
                            etc. 
                    Parameter:
                        1. array: a list that contains infos about comments. (each elem of the array must be a dict and whose have key (named pos) ) 
                        2. originalText: original text.
                    Returned Value:
                        Returns a str. Returns the text after prefilled.
                    """
                    @staticmethod
                    def Fill(array:list , originalText:str) -> str:
                        newLine = '\n'
                        lines = originalText.split(newLine)
                        ( maxX , maxY ) = CommentsHandler.Comment.String.Operation.Get.MaxPos(array)
                        for i in range(0,maxX - len(lines)  , 1):
                            lines.append(newLine)
                        text = newLine.join(lines)
                        return text
                """
                Intro:
                    A class for insert data.
                    For more details, see InsertComments method.
                """                    
                class Insert():
                    """
                    Intro:
                        A main method that inserts the comments.
                    Parameter:
                        1. array: a list that contains infos about comments. (each elem of the array must be a dict and whose have keys (pos,type,text) (the basic elements of comments.)) 
                        2. originalText: original text.
                    Returned Value:
                        Returns a str. Returns the text after prefilled.
                    """
                    @staticmethod
                    def InsertComments(array:list,originalText:str) -> str:
                        newLine = '\n'
                        whitespace = ' '
                        multiLineComment = CommentsEnum().multilineEnum
                        singleLineComment = CommentsEnum().singlelineEnum                       
                        originalText = CommentsHandler.Comment.String.Operation.Fill.Fill(array, originalText)
                        lines = originalText.split(newLine)                                  
                        for arrayNo in range(0,len(array),1):
                            item = array[arrayNo]
                            commentType = item.get("type") 
                            if commentType in singleLineComment :
                                poses = item.get("pos") 
                                text = item.get("text")
                                if poses is None:
                                    raise Exception("Invalid pos.")
                                if text is None:
                                    raise Exception("Invalid text to insert.")
                                startPos = poses[0]
                                timesToFill = max(startPos[1] - len(lines[startPos[0]]) , 0 )
                                textToFilled = whitespace * timesToFill
                                if len(textToFilled) > 0:
                                    lines[startPos[0]] = TextHandler.Text.InsertText(lines[startPos[0]], len(lines[startPos[0]]), textToFilled)
                                lines[startPos[0]] = TextHandler.Text.InsertText(lines[startPos[0]], startPos[1], commentType)
                                lines[startPos[0]] = TextHandler.Text.InsertText(lines[startPos[0]], startPos[1] + len(lines[startPos[0]]) , text)            
                                del poses
                                del text
                                del startPos
                            elif commentType in multiLineComment:
                                poses = item.get("pos") 
                                text = item.get("text")
                                if poses is None:
                                    raise Exception("Invalid pos.")
                                if text is None:
                                    raise Exception("Invalid text to insert.")
                                startPos = poses[0]
                                timesToFill = max(startPos[1] - len(lines[startPos[0]]) , 0 )
                                textToFilled = whitespace * timesToFill
                                if len(textToFilled) > 0:
                                    lines[startPos[0]] = TextHandler.Text.InsertText(lines[startPos[0]], len(lines[startPos[0]]), textToFilled)
                                lines[startPos[0]] = TextHandler.Text.InsertText(lines[startPos[0]], startPos[1], commentType)
                                lines[startPos[0]] = TextHandler.Text.InsertText(lines[startPos[0]], startPos[1] + len(lines[startPos[0]]) , text)                                
                                lines[startPos[0]] = TextHandler.Text.InsertText(lines[startPos[0]], startPos[1] +  len(lines[startPos[0]]) , commentType)
                        newText = newLine.join(lines)
                        return newText
                class Remove():
                    @staticmethod
                    def RemoveComment(originalText:str)->str:
                        if originalText is None:
                            raise Exception("Can not handle a non-string object.")
                            
                        whietspace = ' '
                        tab = '\t'
                        newLine = '\n'
                        wtn = whietspace + tab + newLine 
                        
                        allComment = CommentsEnum().enums
                        singleComment = CommentsEnum().singlelineEnum
                        multiComment = CommentsEnum().multilineEnum
                        newText = originalText[:]
                        while len(newText) > 0 :
                            startsWithComments = CommentsHandler.Comment.String.Operation.Check.IsStartWithComments(newText)
                            if startsWithComments == False:
                                break
                            [ commentsPosInfos , commentsInfos ]  = CommentsHandler.Comment.String.Infos.GetCommentsInfos(newText)
                            # Has no comments in originalText.
                            if len(commentsPosInfos) <= 0:
                                break
                            firstCommentPosInfo = commentsPosInfos[0]
                            firstCommentType = commentsInfos[0].get('type')
                            if firstCommentType in singleComment:
                                firstCommentText =  TextHandler.Text.Range(newText, (0,0), tuple(firstCommentPosInfo[1]) )                             
                            elif firstCommentType in multiComment:
                                firstCommentText =  TextHandler.Text.Range(newText, (0,0), ( firstCommentPosInfo[1][0] , firstCommentPosInfo[1][1] + len(firstCommentType) ) )                             
                            newText = newText.removeprefix(firstCommentText)
                            dummy = None
                            
                        newText = newText.lstrip(wtn)
                        return newText
                        
                        
                        
                    
if __name__ == '__main__':
    demoClass = DemoClass()
    s = demoClass.s
    s2 = """"""
    s3 = """"""
    starts = (0,5)
    ends = (0,100)
    newLine = '\n'
    options = None
    
    s = StringHandler.Single.Whitespacize(s)

    
    r = CommentsHandler.Comment.String.Operation.Remove.RemoveComment(s)
    print("r:")
    print(r)
    print('^'*40)
    
    """
    lines = s.split(newLine)
    
    for lineNo in range(0,len(lines),1):
        line = lines[lineNo]
        startWithComments = CommentsHandler.Comment.String.Operation.Check.IsStartWithComments(line)
        print("Does the string '%s' start with comments?" %(str(line)))
        print(startWithComments)
        print('^'*40)

    #
    startWithComments = CommentsHandler.Comment.String.Operation.Check.IsStartWithComments(s)
    print("Does the string '%s' start with comments?" %(str(s)))
    print(startWithComments)
    print('^'*40)        
    """
    