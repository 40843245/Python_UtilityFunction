class Counter():
        class Keyword():
            @staticmethod
            def GetPoses(s:str,keyword:str) -> list :
                newLine = '\n'
                lines = s.split(newLine)
                infos = list()
                for i in range(0,len(lines),1):
                    line = lines[i]
                totalLength = 0
                startIndex = 0
                for i in range(0,len(lines),1):
                    line = lines[i]
                    if line.count(keyword) > 0:
                        sIndex = s.find(keyword,startIndex)
                        tu = (i,sIndex - totalLength, sIndex , totalLength)
                        infos.append(tu)
                    
                    startIndex = totalLength + 1
                    totalLength += ( len(line) + 1 )
                return infos
        @staticmethod
        def Whitespacize(s:str):
            return s.replace('\t',' '*4)
        
            
if __name__ == '__main__':
    s = """\
\tclass DemoClass():
        def Func1(argv1,argv2:int)->tuple:
pass
\tclass DemoClass():
        def Func2(argv1,argv2,)->list:
            pass
    """
    keyword = 'class'
    s = Counter.Whitespacize(s)
    print("s:")
    print(s)
    r = Counter.Keyword.GetPoses(s, keyword)
    print("r:")
    print(r)
    
    