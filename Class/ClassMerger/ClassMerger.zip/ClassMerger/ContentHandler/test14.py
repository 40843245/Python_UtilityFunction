import pyautogui

if __name__ == '__main__':
    screenWidth, screenHeight = pyautogui.size()
    print(screenWidth,screenHeight,sep=' ')
    pyautogui.moveTo(100, 150)
    pyautogui.click()