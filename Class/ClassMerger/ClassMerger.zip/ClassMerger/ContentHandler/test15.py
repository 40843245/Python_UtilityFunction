import sys
import inspect

class Meta(type):
    def __repr__(self):
        # Inspiration: https://stackoverflow.com/a/6811020
        callerframerecord = inspect.stack()[1]  # 0 represents this line
        # 1 represents line at caller
        frame = callerframerecord[0]
        info = inspect.getframeinfo(frame)
        # print(info.filename)  # __FILE__     -> Test.py
        # print(info.function)  # __FUNCTION__ -> Main
        # print(info.lineno)  # __LINE__     -> 13
        print(info)
        print(type(info))
        print(dir(info))
        print(info.positions)
        return str(info.lineno)

class __LINE__(metaclass=Meta):
    pass

if __name__ == '__main__':
    print(__LINE__)