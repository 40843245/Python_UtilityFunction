import re
s = """\
    keyword1 keyword2
    """
    
expr = r"\W*(\w*)"

pattern = re.compile(expr,re.DOTALL)

m = pattern.findall(s)
print(m)
