class DemoClass():
    def Func1():
        pass
    class DemoClass():
    def Func2():
        pass
    
