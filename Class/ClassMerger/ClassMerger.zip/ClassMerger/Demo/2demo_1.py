# -*- coding: utf-8 -*-
"""
Created on Thu Oct 19 11:41:21 2023

@author: 40843
"""

