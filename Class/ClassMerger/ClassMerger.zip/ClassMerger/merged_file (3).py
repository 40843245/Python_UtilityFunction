class DemoClass():
    def Func1():
        pass
    