import psutil
class PIDHandler():
    class Process():
        @staticmethod
        def GetPIDS(processName:str):
            procs = list()
            for proc in psutil.process_iter():
                if processName in proc.name():
                    procs.append(proc)
            return procs      
            
if __name__ == '__main__':
    processName = 'msedge.exe'
    r = PIDHandler.Process.GetPIDS(processName)
    print(r)
