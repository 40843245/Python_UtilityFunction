import psutil
import asyncio
import threading

class PIDHandler():
    class Process():
        @staticmethod
        def GetPIDS(processName:str):
            procs = list()
            for proc in psutil.process_iter():
                if processName in proc.name():
                    procs.append(proc)
            return procs      
        
async def get_task(task):
    await asyncio.sleep(1)
    return task.pid

async def set_after(fut, delay, value):
    # Sleep for *delay* seconds.
    await asyncio.sleep(delay)
    # Set *value* as a result of *fut* Future.
    fut.set_result(value)
    
async def main():
    try:
        result = list()
        processName = 'msedge.exe'
        proc = PIDHandler.Process.GetPIDS(processName)
        async with asyncio.TaskGroup() as tg:
            task1 = tg.create_task(get_task(proc[0]))
            result.append(task1.result())
        return result
        
    
    except RuntimeWarning as ex:
        print("RuntimeWarning occur.")
        print(ex)
        return ex
        
        
    
if __name__ == '__main__':
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:  # 'RuntimeError: There is no current event loop...'
        loop = None
    
    if loop and loop.is_running():
        print('Async event loop already running. Adding coroutine to the event loop.')
        task = loop.create_task(main())
        task.add_done_callback(
            lambda t: print(f'Task done with result={t}  << return val of main()')
        )
    else:
        print('Starting new event loop')
        result = asyncio.run(main())
