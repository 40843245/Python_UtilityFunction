import psutil 
import asyncio
import threading

class PIDHandler():
    class Process():
        @staticmethod
        def GetPIDS(processName:str):
            procs = list()
            for proc in psutil.process_iter():
                if processName in proc.name():
                    procs.append(proc)
            return procs      
        
async def get_task(task):
    await asyncio.sleep(1)
    return task.pid

async def set_after(fut, delay, value):
    # Sleep for *delay* seconds.
    await asyncio.sleep(delay)
    # Set *value* as a result of *fut* Future.
    fut.set_result(value)
    
async def main():
    try:
        processName = 'msedge.exe'
        #thread1 = threading.Timer(3)
        proc = PIDHandler.Process.GetPIDS(processName)
        loop = asyncio.get_running_loop()
        task = loop.create_future()
        
        print(task)
        print(type(task))
        #thread1.start()
        loop.create_task(set_after(task, 4, get_task(proc[0]) ) )
        
        
        # Wait until *fut* has a result (1 second) and print it.
        result = await task
        return result
        
    
    except RuntimeWarning as ex:
        print(ex)

def print_info(t):
    print(t)
    print(type(t))
    print(dir(t))
def print_task(t):
    print("t:")
    print_info(t)
    print("t.result():")
    print_info(t.result())
    
    # close
    # t.result.close()
    # t.result().close()
    # t.done()
    
if __name__ == '__main__':

    result = asyncio.run(main())
