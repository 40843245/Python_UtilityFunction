import psutil
import win32com.client

# Replace 'your_process_name' with the name of the process you want to check
process_name = 'msedge.exe'

# Get a list of running processes
wmi = win32com.client.GetObject("winmgmts:")

print("wmi:")
print(wmi)
print(type(wmi))
print(dir(wmi))

processes = wmi.InstancesOf("Win32_Process")

print("processes:")
print(processes)
print(type(processes))
print(dir(processes))

foregroundProcs = list()
backgroundProcs = list()

procs = list()

for process in processes:
    if process.Name == process_name:
        procs.append(process)        
        if process.Status == "Running":
            foregroundProcs.append(process)
        else:
            backgroundProcs.append(process)

print("procs:")
print( procs )

print("procs[0]:")
print(procs[0])
print(type(procs[0]))
print(dir(procs[0]))

print("procs[0].Status:")
print(procs[0].Status)
print(type(procs[0].Status))
print(dir(procs[0].Status))


print("foregroundProcs:")
print(foregroundProcs)

print("backgroundProcs:")
print(backgroundProcs)