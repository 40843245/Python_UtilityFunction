import wmi

f = wmi.WMI()

processes = f.Win32_Process()

for process in processes:
    print(process)