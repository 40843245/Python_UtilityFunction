import psutil
import asyncio
from LoopHandler import LoopHandler
"""
A class that handles process in OS.
"""
class OSProcessHandler():
    """
    A class that achieve the goal by psutil module.
    """
    class Psutil():
        """
            Intro:
                Get all processes whose name is processName.
            Parameter:
                1. processName: name of process.
            Returned Value:
                Returns a list. Indicates all processes whose  process name is matched with processName.
        """
        @staticmethod
        def GetProcesses(processName:(str|list[str])) -> list :
            if processName is None:
                raise Exception("The processName must not be a NoneType object.")
            if not isinstance(processName, (str|list)):
                raise Exception("The processName must be a string or a list.")
            if len(processName) <= 0:
                raise Exception("The processName must not be empty (such as an empty string, empty list.")
        
            if isinstance(processName, (str)) == True:
                procs = list()
                # iterate all processes.
                for proc in psutil.process_iter():
                    # match processName and the proc.name.
                    if processName in proc.name():
                        procs.append(proc)
                return procs   
            if isinstance(processName, (list)) == True:
                for i in range(0,len(processName),1):
                    t = processName[i]
                    if not isinstance(t, (str)):
                        raise Exception("All elems of processName must be a string or a list.")   
                
                procs = list()
                for i in range(0,len(processName),1):
                    t = processName[i]
                    r = OSProcessHandler.Psutil.GetProcesses(t)
                    if len(r) > 0 :
                        procs.append(r)
                return procs
        
        @staticmethod
        def HasNoProcess(processName:(str|list) ) -> bool:
            procs = OSProcessHandler.Psutil.GetProcesses(processName)
            print("processName:")
            print(processName) 
            print("procs:")
            print(procs)
            return procs is None or len(procs) <= 0 
        
        @staticmethod
        def GetRunningProcess():
            pass

        
if __name__ == '__main__':
    async def main():
        processName = 'msedge.exe'
        counter = 0 
        while True:
            procs = OSProcessHandler.Psutil.GetProcesses(processName)
            if OSProcessHandler.Psutil.HasNoProcess(processName) :
                break
            print("counter:")
            print(counter) 
            counter += 1
            
            await asyncio.sleep(1)
    LoopHandler.GetRunningLoop(lambda x : print("x"),main)
        
    