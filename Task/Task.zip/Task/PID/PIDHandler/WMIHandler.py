import wmi
class WMIHandler():
    class Process():
        @staticmethod
        def GetName(processName:str):
            f = wmi.WMI()
            processes = f.Win32_Process()
            for process in processes:
                if process.Name == processName:
                    return process
            return None

import psutil

process_name = "python.exe"
pid = list()
for proc in psutil.process_iter():
    if process_name in proc.name():
       pid.append(proc.pid)
       

print("Pid:", pid)
            
if __name__ == '__main__':
    processName = 'python.exe'
    r = WMIHandler.Process.GetName(processName)
    print(r)
