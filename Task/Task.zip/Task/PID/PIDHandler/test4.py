import asyncio

import time


async def late_response(task, flag, timeout, callback):
    done, pending = await asyncio.wait([task], timeout=timeout)
    callback(done.pop().result() if done else None)  # will raise an exception if some_serious_job failed
    flag[0] = True  # signal some_serious_job to stop
    return await task


async def launch_job(loop, some_serious_job, arguments, finished_callback,
                     timeout_1=3, timeout_2=5):
    flag = [False]
    task = loop.run_in_executor(None, some_serious_job, flag, *arguments)
    done, pending = await asyncio.wait([task], timeout=timeout_1)
    if done:
        return done.pop().result()  # will raise an exception if some_serious_job failed
    asyncio.ensure_future(
        late_response(task, flag, timeout_2, finished_callback))
    return None


def f(flag, n):
    for i in range(n):
        print("serious", i, flag)
        if flag[0]:
            return "CANCELLED"
        time.sleep(1)
    return "OK"

def finished(loop,*argv,**kwargv):
    print("FINISHED", loop,argv,kwargv)
    print(loop.is_closed())

aws = (done,pending) = await asyncio.wait(aws)