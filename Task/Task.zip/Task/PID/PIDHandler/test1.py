import py_setenv
import subprocess
import shlex


cmd="Get-CimInstance -Query \"SELECT * from Win32_Process WHERE name = 'python.exe'\""

print(cmd)

args = shlex.split(cmd)

print(args)
output =subprocess.run(args,shell = True,stdout = subprocess.PIPE)
print(output)
print(type(output))
print(dir(output))
s = output.stdout.decode('utf-8')
print(s)
print(len(s))

print(output.args)
print(output.check_returncode)
print(output.returncode)
