import threading

def cancel_task(task,*argv,**kwargv):
    print("cancel_task:")
    task.cancel()
def callback():
    print("callback.")
if __name__ == '__main__':
    try:
        threading.TIMEOUT_MAX = 3
        # lock1 = threading.Lock()
        
        # lock1.acquire(True,threading.TIMEOUT_MAX)
        
        
        
        thread1 = threading.Timer(8, callback)
        thread1.start()
        
        # event = threading.Event()
        # event.wait(timeout = threading.TIMEOUT_MAX)
        
        # lock1.release()
        thread2 = threading.Timer(1, cancel_task,[thread1],None)
        thread2.start()
        
        print("Bye!")
    except Exception as ex:
        print("Error")
        print(ex)