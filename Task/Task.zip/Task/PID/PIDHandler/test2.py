import os
import sys
import shlex
import subprocess

cmd="Get-CimInstance -Query \"SELECT * from Win32_Process WHERE name = 'python.exe'\""

print(cmd)

output = subprocess.call(cmd,shell = True)

print(output)
print(type(output))
print(dir(output))

