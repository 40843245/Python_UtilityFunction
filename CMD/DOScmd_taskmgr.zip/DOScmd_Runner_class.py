
import os;

class DOScmd_Runner():
    def __init__(self):
        self.cmd=""
    def SetCmd(self,s:str):
        self.cmd=s
    def RunCmd(self):
        os.system(self.cmd)

def test():
    inst=DOScmd_Runner()
    inst.SetCmd("cmd /c taskmgr")
    inst.RunCmd()
if __name__=='__main__':
    test()

        

