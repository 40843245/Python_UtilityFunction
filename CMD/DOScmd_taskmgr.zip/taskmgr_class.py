
from DOScmd_Runner_class import DOScmd_Runner

class Taskmgr():
    def __init__(self):
        self.call_taskmgr()
    def call_taskmgr(self):
        inst=DOScmd_Runner()
        inst.SetCmd("cmd /c taskmgr")
        inst.RunCmd()
def test():
    inst=Taskmgr()
if __name__=='__main__':
    test()