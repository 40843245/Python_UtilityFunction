from pydrive.auth import GoogleAuth
from pydrive.drive import GoogleDrive
import pydrive
import pydrive.drive
import pydrive.files

class GoogleDriveHandler():
	def __init__(self):
		self.gauth = GoogleAuth()
		self.gauth.LocalWebserverAuth() # Creates local webserver and auto handles authentication.
		self.drive = GoogleDrive(self.gauth)

	"""
		Description:
			List children of root folder.
		Parameter:
			None
		Returned Value:
			Children of root folder.
		NOTICE:
			It simply calls list_children method as follows.
				GoogleDriveHandler.list_children({'q': "'root' in parents and trashed=false"})
	"""
	def list_root_children(self):
		return GoogleDriveHandler.list_children({'q': "'root' in parents and trashed=false"})

	"""
		Description:
			List children of specific folder that meet the queries (as parameter param).
		Parameter:
			param: parameter to query.
		Returned Value:
			Children of specific folder that meet the queries (as parameter param).
	"""
	def list_children(self,param):
		file_list = self.drive.ListFile(param=param).GetList()
		files = []
		for file1 in file_list:
			files.append((file1['title'], file1['id']))
		return files

	"""
		Description:
			Utility function that iterate each elem with something call 
			where elems satisfies the query (in parameter param).
		Parameter:
			param: parameter to query.
		Returned Value:
			None
	"""
	def do_many_files(self,param,something):
		file_list = self.drive.ListFile(param=param).GetList()
		for file1 in file_list:
			file1.something()

	"""
		Description:
			Delete many elem
			where elems satisfies the query (in parameter param).
		Parameter:
			param: parameter to query.
		Returned Value:
			None
		NOTICE:
			it simply calls do_many_files method as follows.
				self.do_many_files(param,pydrive.files.GoogleDriveFile.Delete)
	"""
	def delete_many_files(self,param):
		self.do_many_files(param,pydrive.files.GoogleDriveFile.Delete)

	"""
		Description:
			Move many elem into trash
			where elems satisfies the query (in parameter param).
		Parameter:
			param: parameter to query.
		Returned Value:
			None
		NOTICE:
			it simply calls do_many_files method as follows.
				self.do_many_files(param,pydrive.files.GoogleDriveFile.Trash)
	"""
	def trash_many_files(self,param):
		self.do_many_files(param,pydrive.files.GoogleDriveFile.Trash)

	"""
		Description:
			Restore many elem from trash bin
			where elems satisfies the query (in parameter param).
		Parameter:
			param: parameter to query.
		Returned Value:
			None
		NOTICE:
			it simply calls do_many_files method as follows.
				self.do_many_files(param,pydrive.files.GoogleDriveFile.UnTrash)
	"""
	def untrash_many_files(self,param):
		self.do_many_files(param,pydrive.files.GoogleDriveFile.UnTrash)
		
if __name__ == '__main__':
	my_GoogleDriveHandler = GoogleDriveHandler()
	files = my_GoogleDriveHandler.do_many_files({'q': "'root' in parents and trashed=false"},pydrive.files.GoogleDriveFile.Delete)
	print(files)

