from pydrive.auth import GoogleAuth
from pydrive.drive import GoogleDrive
import pydrive
import pydrive.drive
import pydrive.files

class GoogleDriveHandler():
	def __init__(self):
		self.gauth = GoogleAuth()
		self.gauth.LocalWebserverAuth() # Creates local webserver and auto handles authentication.
		self.drive = GoogleDrive(self.gauth)

	def list_root_children(self):
		return GoogleDriveHandler.list_children({'q': "'root' in parents and trashed=false"})

	def list_children(self,param):
		file_list = self.drive.ListFile(param=param).GetList()
		files = []
		for file1 in file_list:
			files.append((file1['title'], file1['id']))
		return files

	def do_many_files(self,param,something):
		file_list = self.drive.ListFile(param=param).GetList()
		for file1 in file_list:
			file1.something()
	def delete_many_files(self,param):
		self.do_many_files(param,pydrive.files.GoogleDriveFile.Delete)
	def trash_many_files(self,param):
		self.do_many_files(param,pydrive.files.GoogleDriveFile.Trash)
	def untrash_many_files(self,param):
		self.do_many_files(param,pydrive.files.GoogleDriveFile.UnTrash)
		
if __name__ == '__main__':
	my_GoogleDriveHandler = GoogleDriveHandler()
	files = my_GoogleDriveHandler.do_many_files({'q': "'root' in parents and trashed=false"},pydrive.files.GoogleDriveFile.Delete)
	print(files)

