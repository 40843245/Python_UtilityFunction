from __future__ import print_function
import pickle
import os.path
import os
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
import googleapiclient.discovery
import googleapiclient.http

from tabulate import tabulate
import pandas

from file_size_handler import FileSizeHandler
CLIENT_ID = '868787898506-0k9cb14me2ipjh08oljm4mod5i2rsb77.apps.googleusercontent.com'

SCOPES = ['https://www.googleapis.com/auth/drive.metadata.readonly', # prepare to grant permission for readonly of google drive metafile 
          'https://www.googleapis.com/auth/drive.file', # prepare to grant permission of google drive.
          'https://www.googleapis.com/auth/drive'
         ]

class GoogleDriveHandler():
  """
    Description:
		Get google drive serivce
  	Parameter:
		None
    Returned Value:
		Returns Google Drive API service
  """
  @staticmethod
  def get_gdrive_service() :
    creds = None
    # The file token.pickle stores the user's access and refresh tokens, and is
    # created automatically when the authorization flow completes for the first
    # time.
    if os.path.exists('token.pickle'):
        with open('token.pickle', 'rb') as token:
            creds = pickle.load(token)
    # If there are no (valid) credentials available, let the user log in.
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(
                'credentials.json', SCOPES)
            creds = flow.run_local_server(port=0)
        # Save the credentials for the next run
        with open('token.pickle', 'wb') as token:
            pickle.dump(creds, token)
    return googleapiclient.discovery.build('drive', 'v3', credentials=creds)

  """
    Description:
		Get a list of files in the specified drive (in the parameter items).
  	Parameter:
		items: drive in Google Drive API.
    Returned Value:
   		Returns files by Google Drive API in the given parameter items (if items exists and there are files in items), 
        None (if items exists but there are NO any files in items), or
        a string 'No files found.' (if items does NOT exist).
  """
  @staticmethod
  def list_files(items) -> list | str | None :
    if not items:
    # empty drive
     return 'No files found.'
    else:
      rows = []
      for item in items:
        # get the File ID
        id = item["id"]
        # get the name of file
        name = item["name"]
        # We can simply use .get method instead
        parents = item.get('parents','N/A')
        
        try:
        # get the size in nice bytes format (KB, MB, etc.)
          size = FileSizeHandler.Format.format(int(item["size"]))
        except:
        # not a file, may be a folder
          size = "N/A"
        # get the Google Drive type of file
        mime_type = item["mimeType"]
        # get last modified date time
        modified_time = item["modifiedTime"]
        # append everything to the list
        rows.append((id, name, parents, size, mime_type, modified_time))
    # convert to a human readable table
    # table = tabulate(rows, headers=["ID", "Name", "Parents", "Size", "Type", "Modified Time"])
    table = pandas.DataFrame(rows,index=None,columns=["ID", "Name", "Parents", "Size", "Type", "Modified Time"])
    # print the table
    return table


  """
	Description:
		Get folder id of `folder_name`
    Parameter: 
		folder_name:folder name.
	Returned Value:
		folder id
  """
  @staticmethod
  def get_folder_id(folder_name:str):
    # authenticate account
    service = GoogleDriveHandler.get_gdrive_service()
    # folder details we want to make
    folder_metadata = {
        "name": folder_name,
        "mimeType": "application/vnd.google-apps.folder"
    }
    
    tempFolderId = service.files().create(body=folder_metadata, fields='id').execute()["id"] # Create temporary folder
    myDriveId = service.files().get(fileId=tempFolderId, fields='parents').execute()["parents"][0] # Get parent ID
    service.files().delete(fileId=tempFolderId).execute() # Delete temporary folder
    return myDriveId
  
  """
	Description:
		Create a folder name named `folder_name`
    Parameter: 
		folder_name:folder name that will be created.
	Returned Value:
		folder id
  """
  @staticmethod
  def create_folder(folder_name:str):
    # authenticate account
    service = GoogleDriveHandler.get_gdrive_service()
    # folder details we want to make
    folder_metadata = {
        "name": folder_name,
        "mimeType": "application/vnd.google-apps.folder"
    }
    # create the folder
    folder = service.files().create(body=folder_metadata, fields="id").execute()
    return folder.get('id')
    
def main():
  folder_id = GoogleDriveHandler.create_file(parent_folder='TestFolder',filename='123.txt')
  print(folder_id)

if __name__ == '__main__':
  main()