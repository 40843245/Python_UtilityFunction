class FoundMacro():
    FOUND = -1
    NOTFOUND = None