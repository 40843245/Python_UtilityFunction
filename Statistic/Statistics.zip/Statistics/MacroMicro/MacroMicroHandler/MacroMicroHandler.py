import requests

from DictionaryHandler import DictionaryHandler

class MacroMicroHandler():
    def __init__(self):
        self.options = dict()
        self._collectionsDict = dict()
        self.collectionsDict = {
            'gdp' + 'relative' :2,
            'consumption' + 'relative':3,
            'employement' + 'relative':4,
            'prices' + 'relative':5,
            'trade' + 'relative' :6,
            'house' + 'relative' :7,
            'industry' + 'relative':8,
            'market' + '-' + 'relative' :9,
            'federal':4238,
        }
        
    def SetOptions(self,options: (dict | None) = None ) :
        defaultOptions = {
            'country':'us',
            'baseUrl':'https://www.macromicro.me/',
            'collections':'collections',
            'collectionsBaseType':'gdp',
            'collectionsDict':dict(),
            'countryBaseUrl':None,
            'collectionsBaseTypeUrl':None,            
        }
        
        options = DictionaryHandler.Dict.Operation.DefaultDict(options, defaultOptions)
        """
        for (k,v) in defaultOptions.items():
            if options.get(k) is None:
                options.update({k:options.get(k,v)})
         """  
        self.options = options
        
        self.Update()
        
    def Update(self):
        self.options.update({'countryBaseUrl':self.options.get('baseUrl','') +'/'+self.options.get('country','')})
        self.options.update({'collectionsBaseUrl':self.options.get('baseUrl','') +'/'+self.options.get('collections','')})        
        self.options.update({'collectionsDict':self.collectionsDict})
        self.options.update({
            'collectionsBaseTypeUrl':
            str(self.options.get('collectionsBaseUrl','')) + '/' +
            str(self.collectionsDict.get(self.options.get('collectionsBaseType'),'')) + '/' + 
            self.options.get('country') + '-' + str(self.options.get('collectionsBaseType'))
        })
        
    @property
    def collectionsDict(self):
        return self._collectionsDict
    
    @collectionsDict.setter
    def collectionsDict(self,value):
        self._collectionsDict = value
        
    @collectionsDict.getter
    def collectionsDict(self):
        return self._collectionsDict 
    
    def GetResponse(self) :
        rsp = self.options.get('collectionsBaseTypeUrl')
        return requests.get(rsp)

if __name__ == '__main__':
    options = {
        'country':'us',
        'collectionsBaseType' :'federal',
    }
    MacroMicroHandlerObj = MacroMicroHandler()
    MacroMicroHandlerObj.SetOptions(options)
    options = MacroMicroHandlerObj.options
    
    print("options:")
    print(options)
    
    rsp = MacroMicroHandlerObj.GetResponse()
    
    print("response:")
    print(rsp)

    if not rsp.status_code in [403]:
        print("response.json():")
        print(rsp.json())
    
    
    
    