import requests

from DictionaryHandler import DictionaryHandler

class WantgooHandler():
    def __init__(self):
        self.options = dict()
        
    def SetOptions(self,options: (dict | None) = None ) :
        defaultOptions = {
            'baseUrl':'https://www.twse.com.tw',
            'language':'zh',
            'collectionsBaseType':'trading',
            'tradingType':'historical',
            'targetType':'mi-index',            
            'url' : '',
            'websiteType' : '.html' ,
        }
        
        options = DictionaryHandler.Dict.Operation.DefaultDict(options, defaultOptions)
        self.options = options
        
        self.Update()
        
    def Update(self):
        self.options.update({
            'url':
                self.options.get('baseUrl','') +'/' +
                self.options.get('language') + '/' +
                self.options.get('collectionsBaseType') + '/' +
                self.options.get('tradingType') + '/' +
                self.options.get('targetType') + self.options.get('websiteType')
                
        })
    
    def GetResponse(self) :
        rsp = self.options.get('baseUrl')
        return requests.get(rsp)

if __name__ == '__main__':
    options = None
    WantgooHandlerObj = WantgooHandler()
    WantgooHandlerObj.SetOptions(options)
    options = WantgooHandlerObj.options
    
    print("options:")
    print(options)
    
    rsp = WantgooHandlerObj.GetResponse()
    
    print("response:")
    print(rsp)

    if not rsp.status_code in [403]:
        print("response.json():")
        print(rsp.json())
    
    
    
    