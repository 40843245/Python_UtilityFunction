import webbrowser
from YTUrl_Enum_class import YTUrl_Enum

class YTUrl():

    @staticmethod
    def GetYTHomepageUrl():
        result=YTUrl_Enum.homepage_baseUrl
        return result
    @staticmethod
    def OpenYTHomepageUrl():
        result=YTUrl.GetYTHomepageUrl()
        webbrowser.open(result)

    @staticmethod
    def GetYTSubscriptionsUrl():
        result=YTUrl_Enum.subscriptions_baseUrl
        return result
    @staticmethod
    def OpenYTSubscriptionsUrl():
        result=YTUrl.GetYTSubscriptionsUrl()
        webbrowser.open(result)

    @staticmethod
    def GetYTLibraryUrl():
        result=YTUrl_Enum.library_baseUrl
        return result
    @staticmethod
    def OpenYTLibraryUrl():
        result=YTUrl.GetYTLibraryUrl()
        webbrowser.open(result)

    @staticmethod
    def GetYTHistoryUrl():
        result=YTUrl_Enum.history_baseUrl
        return result
    @staticmethod
    def OpenYTHistoryUrl():
        result=YTUrl.GetYTHistoryUrl()
        webbrowser.open(result)
    
    @staticmethod
    def GetYTPlaylistUrl():
        result=YTUrl_Enum.playlist_baseUrl
        return result
    @staticmethod
    def OpenYTPlaylistUrl():
        result=YTUrl.GetYTPlaylistUrl()
        webbrowser.open(result)
    
    @staticmethod
    def GetYTPlaylistWatchingLaterUrl():
        result=YTUrl_Enum.playlistWatchingLater_baseUrl
        return result
    @staticmethod
    def OpenYTPlaylistWatchingLaterUrl():
        result=YTUrl.GetYTPlaylistWatchingLaterUrl()
        webbrowser.open(result)

    @staticmethod
    def GetYTTrendingUrl():
        result=YTUrl_Enum.trending_baseUrl
        return result
    @staticmethod
    def OpenYTTrendingUrl():
        result=YTUrl.GetYTTrendingUrl()
        webbrowser.open(result)

    @staticmethod
    def GetYTPremiumUrl():
        result=YTUrl_Enum.premium_baseUrl
        return result
    @staticmethod
    def OpenYTPremiumUrl():
        result=YTUrl.GetYTPremiumUrl()
        webbrowser.open(result)

    @staticmethod
    def GetYTStudioUrl():
        result=YTUrl_Enum.studio_baseUrl
        return result
    @staticmethod
    def OpenYTStudioUrl():
        result=YTUrl.GetYTStudioUrl()
        webbrowser.open(result)

    @staticmethod
    def GetYTMusicUrl():
        result=YTUrl_Enum.music_baseUrl
        return result
    @staticmethod
    def OpenYTMusicUrl():
        result=YTUrl.GetYTMusicUrl()
        webbrowser.open(result)

    @staticmethod
    def GetYTYoutubekidsUrl():
        result=YTUrl_Enum.youtubekids_baseUrl
        return result
    @staticmethod
    def OpenYTYoutubekidsUrl():
        result=YTUrl.GetYTYoutubekidsUrl()
        webbrowser.open(result)

    @staticmethod
    def GetYTReporthistoryUrl():
        result=YTUrl_Enum.reporthistory_baseUrl
        return result
    @staticmethod
    def OpenYTReporthistoryUrl():
        result=YTUrl.GetYTReporthistoryUrl()
        webbrowser.open(result)

    @staticmethod
    def GetYTPlaylistLikeLaterUrl():
        result=YTUrl_Enum.playlistLikeLater_baseUrl
        return result
    @staticmethod
    def OpenYTPlaylistLikeLaterUrl():
        result=YTUrl.GetYTPlaylistLikeLaterUrl()
        webbrowser.open(result)

    @staticmethod
    def GetYTGuideBuilderUrl():
        result=YTUrl_Enum.guideBuilder_baseUrl
        return result
    @staticmethod
    def OpenYTGuideBuilderUrl():
        result=YTUrl.GetYTGuideBuilderUrl()
        webbrowser.open(result)
        


    
def test(): 
    YTUrl.OpenYTReporthistoryUrl()


if __name__=='__main__':
    test()