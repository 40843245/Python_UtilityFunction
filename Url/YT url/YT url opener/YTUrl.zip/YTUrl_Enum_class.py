class YTUrl_Enum():

    homepage_baseUrl="https://www.youtube.com/"

    subscriptions_baseUrl="https://www.youtube.com/feed/subscriptions"

    library_baseUrl="https://www.youtube.com/feed/library"

    history_baseUrl="https://www.youtube.com/feed/history"

    playlist_baseUrl="https://www.youtube.com/playlist"

    playlistWatchingLater_baseUrl="https://www.youtube.com/playlist?list=WL"

    trending="https://www.youtube.com/feed/trending"

    accountSetting_baseUrl="https://www.youtube.com/account"

    reporthistory_baseUrl="https://www.youtube.com/reporthistory"

    premium_baseUrl="https://www.youtube.com/premium"

    studio_baseUrl="https://studio.youtube.com/"

    music_baseUrl="https://music.youtube.com/"

    youtubekids_baseUrl="https://www.youtubekids.com/"
    
